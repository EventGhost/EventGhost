# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright © 2005-2016 EventGhost Project <http://www.eventghost.org/>
#
# EventGhost is free software: you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 2 of the License, or (at your option)
# any later version.
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along
# with EventGhost. If not, see <http://www.gnu.org/licenses/>.


USBCONTROLLER = u'''<md>
# USB Controller
***

The *Win32_USBController* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
Offline
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, this property allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the USB controller.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information about any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Manufacturer of the controller.


## MaxNumberControlled
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ProtocolSupported
***

- Data type: *uint16*
- Access type: Read-only

Protocol used by the controller to access "controlled" devices.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *EISA* (3)
4.    *ISA* (4)
5.    *PCI* (5)
6.    *ATA/ATAPI* (6)
ATA or ATAPI
7.    *Flexible Diskette* (7)
8.    *1496* (8)
9.    *SCSI Parallel Interface* (9)
10.    *SCSI Fibre Channel Protocol* (10)
11.    *SCSI Serial Bus Protocol* (11)
12.    *SCSI Serial Bus Protocol-2 (1394)* (12)
13.    *SCSI Serial Storage Architecture* (13)
14.    *VESA* (14)
15.    *PCMCIA* (15)
16.    *Universal Serial Bus* (16)
17.    *Parallel Protocol* (17)
18.    *ESCON* (18)
19.    *Diagnostic* (19)
20.    *I2C* (20)
21.    *Power* (21)
22.    *HIPPI* (22)
23.    *MultiBus* (23)
24.    *VME* (24)
25.    *IPI* (25)
26.    *IEEE-488* (26)
27.    *RS232* (27)
28.    *IEEE 802.3 10BASE5* (28)
29.    *IEEE 802.3 10BASE2* (29)
30.    *IEEE 802.3 1BASE5* (30)
31.    *IEEE 802.3 10BROAD36* (31)
32.    *IEEE 802.3 100BASEVG* (32)
33.    *IEEE 802.5 Token-Ring* (33)
34.    *ANSI X3T9.5 FDDI* (34)
35.    *MCA* (35)
36.    *ESDI* (36)
37.    *IDE* (37)
38.    *CMD* (38)
39.    *ST506* (39)
40.    *DSSI* (40)
41.    *QIC2* (41)
42.    *Enhanced ATA/IDE* (42)
43.    *AGP* (43)
44.    *TWIRP (two-way infrared)* (44)
45.    *FIR (fast infrared)* (45)
46.    *SIR (serial infrared)* (46)
47.    *IrBus* (47)

## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value for the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time the controller was last reset. This could mean the controller was powered down or reinitialized.

</md>
'''

CONTROLLERDEVICE1394 = u'''<md>
# 1394  Controller Device
***

The *Win32_1394ControllerDevice* class has these properties.


## AccessState
***

- Data type: *uint16*
- Access type: Read-only

Indicates whether the controller is actively commanding or accessing the device.  This information is necessary when a logical device can be commanded by, or accessed through, multiple controllers.

0.    *Unknown* (0)
1.    *Active* (1)
2.    *Inactive* (2)

## Antecedent
***

- Data type: *Win32_1394Controller*
- Access type: Read-only

The Win32_1394Controller antecedent reference represents the 1394 controller associated with this device.


## Dependent
***

- Data type: *CIM_LogicalDevice*
- Access type: Read-only

The CIM_LogicalDevice dependent reference represents the CIM_LogicalDevice connected to the 1394 controller.


## NegotiatedDataWidth
***

- Data type: *uint32*
- Access type: Read-only

When several bus or connection-data widths are possible, this  property defines the one in use between the devices.  Data width is specified in bits.  If data width is not negotiated, or if this information is not available or important to device management, the property should be set to 0 (zero).


## NegotiatedSpeed
***

- Data type: *uint64*
- Access type: Read-only

When several bus or connection speeds are possible, this  property defines the one being  used between the devices.  Speed is specified in bits-per-second.  If connection or bus speeds are not negotiated, or if this information is not available or important to device management, the property should be set to 0 (zero).


## NumberOfHardResets
***

- Data type: *uint32*
- Access type: Read-only

Number of hard resets issued by the controller. A hard reset returns the device to its initialization or boot-up state. All internal device state information and data are lost.


## NumberOfSoftResets
***

- Data type: *uint32*
- Access type: Read-only

Number of soft resets issued by the controller. A soft reset does not completely clear current device state and data. Exact semantics are dependent on the device and on the protocols and mechanisms used to communicate to it.

</md>
'''

HEATPIPE = u'''<md>
# Heat Pipe
***

The *Win32_HeatPipe* class has these properties.


## ActiveCooling
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the cooling device provides active  coolingnot passive.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the heat pipe.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error that is recorded in *LastErrorCode*, and information about any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
Power-related capacities are not supported for this device.
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managedput into suspend mode, and so on. The property does not indicate that power management features are  enabled currently, only that the logical device is capable of power management.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value for the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.

</md>
'''

PORTABLEBATTERY = u'''<md>
# Portable Battery
***

The *Win32_PortableBattery* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## BatteryStatus
***

- Data type: *uint16*
- Access type: Read-only

Description of the battery's charge status. The value 10 (Undefined) is not valid in the Common Information Model (CIM) schema because in Desktop Management Interface (DMI) it indicates that no battery is installed. In this case, this object should not be instantiated.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Fully Charged* (3)
4.    *Low* (4)
5.    *Critical* (5)
6.    *Charging* (6)
7.    *Charging and High* (7)
8.    *Charging and Low* (8)
9.    *Charging and Critical* (9)
10.    *Undefined* (10)
11.    *Partially Charged* (11)

## CapacityMultiplier
***

- Data type: *uint16*
- Access type: Read-only

Multiplication factor of the *DesignCapacity* value to ensure that the milliwatt hour value does not overflow for Smart Battery Data Specification (SBDS) implementations.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of the objecta one-line string.


## Chemistry
***

- Data type: *uint16*
- Access type: Read-only

Chemistry of the battery.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Lead Acid* (3)
4.    *Nickel Cadmium* (4)
5.    *Nickel Metal Hydride* (5)
6.    *Lithium-ion* (6)
7.    *Zinc air* (7)
8.    *Lithium Polymer* (8)

## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DesignCapacity
***

- Data type: *uint32*
- Access type: Read-only

Design capacity of the battery in milliwatt-hours. If this property is not supported, enter 0 (zero).


## DesignVoltage
***

- Data type: *uint64*
- Access type: Read-only

Design voltage of the battery in millivolts. If this attribute is not supported, enter 0 (zero).


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Battery identifier.

Example: "Internal Battery"


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and any corrective actions that may be taken.


## EstimatedChargeRemaining
***

- Data type: *uint16*
- Access type: Read-only

Estimate of the percentage of full charge remaining.


## EstimatedRunTime
***

- Data type: *uint32*
- Access type: Read-only

Estimate in minutes of the time to battery charge depletion under the present load conditions if the utility power is off, or lost and remains off, or a laptop is disconnected from a power source.


## ExpectedBatteryLife
***

- Data type: *uint32*
- Access type: Read-only

Not supported.


## ExpectedLife
***

- Data type: *uint32*
- Access type: Read-only

Battery's expected lifetime in minutes, assuming that the battery is fully charged. This property represents the total expected life of the battery, not its current remaining life, which is indicated by the *EstimatedRunTime* property.


## FullChargeCapacity
***

- Data type: *uint32*
- Access type: Read-only

Full charge capacity of the battery in milliwatt-hours. Comparison of this value to the *DesignCapacity* property determines when the battery requires replacement. A battery's end of life is typically when the *FullChargeCapacity* property falls below 80% of the *DesignCapacity* property. If this property is not supported, enter 0 (zero).


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Location
***

- Data type: *string*
- Access type: Read-only

Physical location of the battery. This property is filled by the computer manufacturer.

Example: "In the back, on the left"


## ManufactureDate
***

- Data type: *string*
- Access type: Read-only

Date when the battery was manufactured.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Manufacturer of the battery.


## MaxBatteryError
***

- Data type: *uint16*
- Access type: Read-only

Difference between the highest estimated amount of energy left in the battery and the current amount reported by the battery.


## MaxRechargeTime
***

- Data type: *uint32*
- Access type: Read-only

Maximum time, in minutes, to fully charge the battery. This property represents the time to recharge a fully depleted battery, not the current remaining charge time, which is indicated in the *TimeToFullCharge* property.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## SmartBatteryVersion
***

- Data type: *string*
- Access type: Read-only

Smart Battery Data Specification version number supported by this battery. If the battery does not support this function, the value should be left blank.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOnBattery
***

- Data type: *uint32*
- Access type: Read-only

Elapsed time in seconds since the computer system's UPS last switched to battery power, or the time since the system or UPS was last restarted, whichever is less. If the battery is online, 0 (zero) is returned.


## TimeToFullCharge
***

- Data type: *uint32*
- Access type: Read-only

Remaining time in minutes to charge the battery fully at the current charge rate and usage.

</md>
'''

TEMPERATUREPROBE = u'''<md>
# Temperature Probe
***

The *Win32_TemperatureProbe* class has these properties.


## Accuracy
***

- Data type: *sint32*
- Access type: Read-only

Accuracy of the sensor for the measured property. Its value is recorded as plus or minus hundredths of a percent. Accuracy,  resolution, and tolerance are used to calculate the actual value of the measured physical property. Accuracy may vary and depends on whether or not the device is linear over its dynamic range.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
Offline
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of an objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of a class, this property allows all instances of the class and its subclasses to be  identified uniquely.


## CurrentReading
***

- Data type: *sint32*
- Access type: Read-only

Current value indicated by the sensor.

Current implementations of WMI do not populate the *CurrentReading* property. The *CurrentReading* property's presence is reserved for future use.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the current probe.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information about any corrective actions that you can take.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object is installed. This property does not need a value to indicate that the object is installed.


## IsLinear
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the sensor is linear over its dynamic range.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## LowerThresholdCritical
***

- Data type: *sint32*
- Access type: Read-only

Sensor threshold value to specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If *CurrentReading* is between *LowerThresholdCritical* and *LowerThresholdFatal*, the current state is critical.


## LowerThresholdFatal
***

- Data type: *sint32*
- Access type: Read-only

Sensor threshold value to specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If *CurrentReading* is below *LowerThresholdFatal*, the current state is fatal.


## LowerThresholdNonCritical
***

- Data type: *sint32*
- Access type: Read-only

Sensor threshold value to specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If *CurrentReading* is between *LowerThresholdNonCritical* and *UpperThresholdNonCritical*, the sensor is reporting a normal value. If *CurrentReading* is between *LowerThresholdNonCritical* and *LowerThresholdCritical*, the current state is noncritical.


## MaxReadable
***

- Data type: *sint32*
- Access type: Read-only

Largest value of the measured property that can be read by the numeric sensor.


## MinReadable
***

- Data type: *sint32*
- Access type: Read-only

Smallest value of the measured property that can be read by the numeric sensor.


## Name
***

- Data type: *string*
- Access type: Read-only

Label for the object. When subclassed, the property can be overridden to be a key property.


## NominalReading
***

- Data type: *sint32*
- Access type: Read-only

Normal or expected value for the numeric sensor.


## NormalMax
***

- Data type: *sint32*
- Access type: Read-only

Normal or expected value for the numeric sensor.


## NormalMin
***

- Data type: *sint32*
- Access type: Read-only

Guidance for the user as to the normal minimum range for the numeric sensor.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState</em> parameter set to 5 (Power Cycle) and <em>Time</em> set to a specific date and time, or interval, for power-on.

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## Resolution
***

- Data type: *uint32*
- Access type: Read-only

Ability of the sensor to resolve differences in the measured property. This value may vary depending on whether the device is linear over its dynamic range.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value for the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## Tolerance
***

- Data type: *sint32*
- Access type: Read-only

Tolerance of the sensor for the measured property. Tolerance, along with resolution and accuracy, is used to calculate the actual value of the measured physical property. Tolerance may vary depending on whether the device is linear over its dynamic range.


## UpperThresholdCritical
***

- Data type: *sint32*
- Access type: Read-only

Sensor's threshold values specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If *CurrentReading* is between *UpperThresholdCritical* and *UpperThresholdFatal*, the current state is critical.


## UpperThresholdFatal
***

- Data type: *sint32*
- Access type: Read-only

Sensor's threshold values specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If *CurrentReading* is above *UpperThresholdFatal*, the current state is fatal.


## UpperThresholdNonCritical
***

- Data type: *sint32*
- Access type: Read-only

Sensor's threshold values specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If *CurrentReading* is between *LowerThresholdNonCritical* and *UpperThresholdNonCritical*, the sensor is reporting a normal value. If *CurrentReading* is between *UpperThresholdNonCritical* and *UpperThresholdCritical*, the current state is noncritical.

</md>
'''

PHYSICALMEMORY = u'''<md>
# Physical Memory
***

The *Win32_PhysicalMemory* class has these properties.


## Attributes
***

- Data type: *uint32*
- Access type: Read-only

SMBIOS - Type 17 - Attributes. Represents the RANK.

This value comes from the *Attributes* member of the
       *Memory Device* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## BankLabel
***

- Data type: *string*
- Access type: Read-only

Physically labeled bank where the memory is located.

Examples: "Bank 0", "Bank A"

This value comes from the *Bank Locator* member of the
       *Memory Device* structure in the SMBIOS information.


## Capacity
***

- Data type: *uint64*
- Access type: Read-only

Total capacity of the physical memoryin bytes.

This value comes from the *Memory Device* structure in the SMBIOS version
       information. For SMBIOS versions 2.1 thru 2.6 the value comes from the *Size* member.
       For SMBIOS version 2.7+ the value comes from the *Extended Size* member.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of the objecta one-line string.


## ConfiguredClockSpeed
***

- Data type: *uint32*
- Access type: Read-only

The configured clock speed of the memory device, in megahertz (MHz), or 0, if the speed is unknown.

This value comes from the *Configured Memory Clock Speed* member of the
       *Memory Device* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## ConfiguredVoltage
***

- Data type: *uint32*
- Access type: Read-only

Configured voltage for this device, in millivolts, or 0, if the voltage is unknown.

This value comes from the *Configured voltage* member of the
       *Memory Device* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that  appears in the inheritance chain used in the creation of an instance.
       When used with the other key properties of the class, the property allows all instances of this class and its
       subclasses to be  identified uniquely.


## DataWidth
***

- Data type: *uint16*
- Access type: Read-only

Data width of the physical memoryin bits. A data width of 0 (zero) and a total width of
       8 (eight) indicates that the memory is  used solely to provide error correction bits.

This value comes from the *Data Width* member of the
       *Memory Device* structure in the SMBIOS information.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of an object.


## DeviceLocator
***

- Data type: *string*
- Access type: Read-only

Label of the socket or circuit board that holds the memory.

Example: "SIMM 3"

This value comes from the *Device Locator* member of the
       *Memory Device* structure in the SMBIOS information.


## FormFactor
***

- Data type: *uint16*
- Access type: Read-only

Implementation form factor for the chip.

This value comes from the *Form Factor* member of the
       *Memory Device* structure in the SMBIOS information.

0.    ** (0)
Unknown
1.    ** (1)
Other
2.    ** (2)
SIP
3.    ** (3)
DIP
4.    ** (4)
ZIP
5.    ** (5)
SOJ
6.    ** (6)
Proprietary
7.    ** (7)
SIMM
8.    ** (8)
DIMM
9.    ** (9)
TSOP
10.    ** (10)
PGA
11.    ** (11)
RIMM
12.    ** (12)
SODIMM
13.    ** (13)
SRIMM
14.    ** (14)
SMD
15.    ** (15)
SSMP
16.    ** (16)
QFP
17.    ** (17)
TQFP
18.    ** (18)
SOIC
19.    ** (19)
LCC
20.    ** (20)
PLCC
21.    ** (21)
BGA
22.    ** (22)
FPBGA
23.    ** (23)
LGA

## HotSwappable
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, this physical media component can be replaced with a physically different
       but equivalent one while the containing package has the power applied. For example, a fan component may be
       designed to be hot-swapped. All components that can be hot-swapped are inherently removable and replaceable.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object is installed. This property does not need a value to indicate that the object is
       installed.


## InterleaveDataDepth
***

- Data type: *uint16*
- Access type: Read-only

Unsigned 16-bit integer maximum number of consecutive rows of data that are accessed in a single interleaved
       transfer from the memory device. If the value is 0 (zero), the memory is not interleaved.


## InterleavePosition
***

- Data type: *uint32*
- Access type: Read-only

Position of the physical memory in an interleave. For example, in a 2:1 interleave, a value of "1"  indicates
       that the memory is in the "even" position.

- 0
Noninterleaved
- 1
First position
- 2
Second position

## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the organization responsible for producing the physical element.

This value comes from the *Manufacturer* member of the
       *Memory Device* structure in the SMBIOS information.


## MaxVoltage
***

- Data type: *uint32*
- Access type: Read-only

The maximum operating voltage for this device, in millivolts, or 0, if the voltage is unknown.

This value comes from the *Maximum voltage* member of the
       *Memory Device* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## MemoryType
***

- Data type: *uint16*
- Access type: Read-only

Type of physical memory. This is a CIM value that is mapped to the SMBIOS value. The
       *SMBIOSMemoryType* property contains the raw SMBIOS memory type.

This value comes from the *Memory Type* member of the
       *Memory Device* structure in the SMBIOS information.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *DRAM* (2)
3.    *Synchronous DRAM* (3)
4.    *Cache DRAM* (4)
5.    *EDO* (5)
6.    *EDRAM* (6)
7.    *VRAM* (7)
8.    *SRAM* (8)
9.    *RAM* (9)
10.    *ROM* (10)
11.    *Flash* (11)
12.    *EEPROM* (12)
13.    *FEPROM* (13)
14.    *EPROM* (14)
15.    *CDRAM* (15)
16.    *3DRAM* (16)
17.    *SDRAM* (17)
18.    *SGRAM* (18)
19.    *RDRAM* (19)
20.    *DDR* (20)
21.    *DDR2* (21)
DDR2May not be available; see note above.
22.    *DDR2 FB-DIMM* (22)
DDR2FB-DIMM,May not be available; see note above.
- 24
DDR3May not be available; see note above.
- 25
FBD2

## MinVoltage
***

- Data type: *uint32*
- Access type: Read-only

The minimum operating voltage for this device, in millivolts, or 0, if the voltage is unknown.

This value comes from the *Minimum voltage* member of the
       *Memory Device* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## Model
***

- Data type: *string*
- Access type: Read-only

Name for the physical element.


## Name
***

- Data type: *string*
- Access type: Read-only

Label for the object. When subclassed, the property can be overridden to be a key property.


## OtherIdentifyingInfo
***

- Data type: *string*
- Access type: Read-only

Additional data, beyond asset tag information, that can be used to identify a physical element. One example
       is bar code data associated with an element that also has an asset tag. If only bar code data is available and
       unique or able to be used as an element key, this property is be *NULL* and the bar
       code data is used as the class key in the tag property.


## PartNumber
***

- Data type: *string*
- Access type: Read-only

Part number assigned by the organization responsible for producing or manufacturing the physical element.

This value comes from the *Part Number* member of the
       *Memory Device* structure in the SMBIOS information.


## PositionInRow
***

- Data type: *uint32*
- Access type: Read-only

Position of the physical memory in a row. For example, if it takes two 8-bit memory devices to form a 16-bit
       row, then a value of 2 (two) means that this memory is the second device0 (zero) is an
       invalid value for this property.


## PoweredOn
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the physical element is powered on.


## Removable
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, a physical component is removable (if it is designed to be taken in and
       out of the physical container in which it is normally found, without impairing the function of the overall
       packaging). A component can still be removable if power must be "off" to perform the removal. If power can be
       "on" and the component removed, then the element is removable and can be hot-swapped. For example, an
       upgradable processor chip is removable.


## Replaceable
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, this physical media component can be replaced  with a physically different
       one. For example, some computer systems allow the main processor chip to be upgraded to one of a higher clock
       rating. In this case, the processor is said to be replaceable. All removable components are inherently
       replaceable.


## SerialNumber
***

- Data type: *string*
- Access type: Read-only

Manufacturer-allocated number  to identify the physical element.

This value comes from the *Serial Number* member of the
       *Memory Device* structure in the SMBIOS information.


## SKU
***

- Data type: *string*
- Access type: Read-only

Stock keeping unit number for the physical element.


## SMBIOSMemoryType
***

- Data type: *uint32*
- Access type: Read-only

The raw SMBIOS memory type. The value of the *MemoryType* property is a CIM
       value that is mapped to the SMBIOS value.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## Speed
***

- Data type: *uint32*
- Access type: Read-only

Speed of the physical memoryin nanoseconds.

This value comes from the *Speed* member of the
       *Memory Device* structure in the SMBIOS information.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational
       statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may
       be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error",
       "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk,
       reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed
       element is neither "OK" nor in one of the other states.


The possible values are.

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## Tag
***

- Data type: *string*
- Access type: Read-only

Unique identifier for the physical memory device that is represented by an instance of
       *Win32_PhysicalMemory*. This property is
Example: "Physical Memory 1"


## TotalWidth
***

- Data type: *uint16*
- Access type: Read-only

Total width, in bits, of the physical memory, including check or error correction bits. If there are no error
       correction bits, the value in this property should match what is specified for the
       *DataWidth* property.

This value comes from the *Total Width* member of the
       *Memory Device* structure in the SMBIOS information.


## TypeDetail
***

- Data type: *uint16*
- Access type: Read-only

Type of physical memory represented.

This value comes from the *Type Detail* member of the
       *Memory Device* structure in the SMBIOS information.

1.    *Reserved* (1)
2.    *Other* (2)
4.    *Unknown* (4)
8.    *Fast-paged* (8)
16.    *Static column* (16)
32.    *Pseudo-static* (32)
64.    *RAMBUS* (64)
128.    *Synchronous* (128)
256.    *CMOS* (256)
512.    *EDO* (512)
1024.    *Window DRAM* (1024)
2048.    *Cache DRAM* (2048)
4096.    *Non-volatile* (4096)
Nonvolatile

## Version
***

- Data type: *string*
- Access type: Read-only

Version of the physical element.

</md>
'''

POTSMODEM = u'''<md>
# POTS Modem
***

The *Win32_POTSModem* class has these properties.


## AnswerMode
***

- Data type: *uint16*
- Access type: Read-only

Current auto-answer or callback setting for the modem.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Disabled* (2)
3.    *Manual Answer* (3)
4.    *Auto Answer* (4)
5.    *Auto Answer with Call-Back* (5)

## AttachedTo
***

- Data type: *string*
- Access type: Read-only

Port to which the POTS modem is attached.

Example: "COM1"


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## BlindOff
***

- Data type: *string*
- Access type: Read-only

Command string used to detect a dial tone before dialing.

Example: "X4"


## BlindOn
***

- Data type: *string*
- Access type: Read-only

Command string used to dial whether or not there is a dial tone.

Example: "X3"


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## CompatibilityFlags
***

- Data type: *string*
- Access type: Read-only

All modem connection protocols with which this modem device is compatible.


## CompressionInfo
***

- Data type: *uint16*
- Access type: Read-only

Data compression characteristics of the modem.

0.    *Unknown* (0)
1.    *Other* (1)
Unknown
2.    *No Compression* (2)
Other
3.    *MNP 5* (3)
No Compression
4.    *V.42bis* (4)
MNP 5
- *5*
V.42bis

## CompressionOff
***

- Data type: *string*
- Access type: Read-only

Command string used to disable hardware data compression.

Example: "S46=136"


## CompressionOn
***

- Data type: *string*
- Access type: Read-only

Command string used to enable hardware data compression.

Example: "S46=138"


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## ConfigurationDialog
***

- Data type: *string*
- Access type: Read-only

Modem initialization string. This property is made up of command strings from other properties of this class.


## CountriesSupported
***

- Data type: *string* array
- Access type: Read-only

Array of countries/regions in which the modem can operate.


## CountrySelected
***

- Data type: *string*
- Access type: Read-only

Country/region for which the modem is currently programmed. When multiple countries/regions are supported, this property defines which one is currently selected for use.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## CurrentPasswords
***

- Data type: *string* array
- Access type: Read-only

List of currently defined passwords for the modem. This array may be left blank for security reasons.


## DCB
***

- Data type: *uint8* array
- Access type: Read-only

Control settings for a serial communications device, in this case, the modem device.


## Default
***

- Data type: *uint8* array
- Access type: Read-only

If *TRUE*, this POTS modem is the default modem on the  computer system running Windows.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of this POTS modem from other devices on the system.


## DeviceLoader
***

- Data type: *string*
- Access type: Read-only

Name of the device loader for the modem. A device loader loads and manages device drivers and enumerators for a given device.


## DeviceType
***

- Data type: *string*
- Access type: Read-only

Physical type of the modem.

The values are:

<dd>"Null Modem"

<dd>"Internal Modem"

<dd>"External Modem"

<dd>"PCMCIA Modem"

<dd>"Unknown"

- *Null Modem* ("Null Modem")
- *Internal Modem* ("Internal Modem")
- *External Modem* ("External Modem")
- *PCMCIA Modem* ("PCMCIA Modem")
- *Unknown* ("Unknown")

## DialType
***

- Data type: *uint16*
- Access type: Read-only

Type of dialing method used.

0.    *Unknown* (0)
1.    *Tone* (1)
2.    *Pulse* (2)

## DriverDate
***

- Data type: *datetime*
- Access type: Read-only

Date of the modem driver.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorControlForced
***

- Data type: *string*
- Access type: Read-only

Command string used to enable error correction control when establishing a connection. This increases the reliability of the connection.

Example: "+Q5S36=4S48=7"


## ErrorControlInfo
***

- Data type: *uint16*
- Access type: Read-only

Error correction characteristics of the modem.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *No Error Correction* (2)
3.    *MNP 4* (3)
4.    *LAPM* (4)

## ErrorControlOff
***

- Data type: *string*
- Access type: Read-only

Command string used to disable error control.

Example: "+Q6S36=3S48=128"


## ErrorControlOn
***

- Data type: *string*
- Access type: Read-only

Command string used to enable error control.

Example: "+Q5S36=7S48=7"


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information on any corrective actions that may be taken.


## FlowControlHard
***

- Data type: *string*
- Access type: Read-only

Command string used to enable hardware flow control. Flow control consists of signals sent between computers that verify that both computers are ready to transmit or receive data.

Example: "&amp;K1"


## FlowControlOff
***

- Data type: *string*
- Access type: Read-only

Command string used to disable flow control. Flow control consists of signals sent between computers that verify that both computers are ready to transmit or receive data.

Example: "&amp;K0"


## FlowControlSoft
***

- Data type: *string*
- Access type: Read-only

Command string used to enable software flow control. Flow control consists of signals sent between computers that verify that both computers are ready to transmit or receive data.

Example: "&amp;K2"


## InactivityScale
***

- Data type: *string*
- Access type: Read-only

Multiplier used with the *InactivityTimeout* property to calculate the timeout period of a connection.


## InactivityTimeout
***

- Data type: *uint32*
- Access type: Read-only

Time limit (in seconds) for automatic disconnection of the phone line, if no data is exchanged. A value of 0 (zero) indicates that this feature is present but not enabled.


## Index
***

- Data type: *uint32*
- Access type: Read-only

Index number for this POTS modem.

Example: 0


## IndexEx
***

- Data type: *string*
- Access type: Read-only

The device instance ID for this POTS modem.

Example: "1&amp;08"

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is available beginning with Windows Server2016 Technical Preview and Windows10.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## MaxBaudRateToPhone
***

- Data type: *uint32*
- Access type: Read-only

Maximum settable communication speed for accessing the phone system.


## MaxBaudRateToSerialPort
***

- Data type: *uint32*
- Access type: Read-only

Maximum settable communication speed to the COM port for an external modem. Enter 0 (zero) if not applicable.


## MaxNumberOfPasswords
***

- Data type: *uint16*
- Access type: Read-only

Number of passwords definable in the modem itself. If this feature is not supported, enter 0 (zero).


## Model
***

- Data type: *string*
- Access type: Read-only

Model of this POTS modem.

Example: "Sportster 56K External"


## ModemInfPath
***

- Data type: *string*
- Access type: Read-only

Path to this modem's .inf file. This file contains initialization information for the modem and its driver.

Example: "C:\Windows\INF"


## ModemInfSection
***

- Data type: *string*
- Access type: Read-only

Name of the section in the modem's .inf file that contains information about the modem.


## ModulationBell
***

- Data type: *string*
- Access type: Read-only

Command string used to instruct the modem to use Bell modulations for 300 and 1200 bps.

Example: "B1"


## ModulationCCITT
***

- Data type: *string*
- Access type: Read-only

Command string used to instruct the modem to use CCITT modulations for 300 and 1200 bps.

Example: "B0"


## ModulationScheme
***

- Data type: *uint16*
- Access type: Read-only

Modulation scheme of the modem.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Not Supported* (2)
3.    *Bell 103* (3)
4.    *Bell 212A* (4)
5.    *V.22bis* (5)
6.    *V.32* (6)
7.    *V.32bis* (7)
8.    *V.turbo* (8)
9.    *V.FC* (9)
10.    *V.34* (10)
11.    *V.34bis* (11)

## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PortSubClass
***

- Data type: *string*
- Access type: Read-only

Definition of the port used for this modem.

- ** ("00")
Parallel Port
- ** ("01")
Serial Port
- ** ("02")
Modem

## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## Prefix
***

- Data type: *string*
- Access type: Read-only

Dialing prefix used to access an outside line.


## Properties
***

- Data type: *uint8* array
- Access type: Read-only

List of all the properties (and their values) for this modem.


## ProviderName
***

- Data type: *string*
- Access type: Read-only

Network path to the computer that provides the modem services.


## Pulse
***

- Data type: *string*
- Access type: Read-only

Command string used to instruct the modem to use pulse mode for dialing. Pulse dialing is necessary for phone lines that are unable to handle tone dialing.

Example: "P"


## Reset
***

- Data type: *string*
- Access type: Read-only

Command string used to reset the modem for the next call.

Example: "AT&amp;F"


## ResponsesKeyName
***

- Data type: *string*
- Access type: Read-only

Response this modem might report to the operating system during the connection process. The first two characters specify the type of response. The second two characters specify information about the connection being made. The second two characters are used only for Negotiation Progress or Connect response codes. The next eight characters specify the modem-to-modem line speed negotiated in bits per second (bps). The characters represent a 32-bit unsigned long integer format (byte and word reversed). The last eight characters indicate that the modem is changing to a different port or Data Terminal Equipment (DTE) speed. Usually this field is not used because modems make connections at a locked port speed regardless of the modem-to-modem or Data Communications Equipment (DCE) speed.


## RingsBeforeAnswer
***

- Data type: *uint8*
- Access type: Read-only

Number of rings before the modem answers an incoming call.


## SpeakerModeDial
***

- Data type: *string*
- Access type: Read-only

Command string used to turn the modem speaker on after dialing a number, and turning the speaker off when a connection has been established.

Example: "M1"


## SpeakerModeOff
***

- Data type: *string*
- Access type: Read-only

Command string used to turn the modem speaker off.

Example: "M0"


## SpeakerModeOn
***

- Data type: *string*
- Access type: Read-only

Command string used to turn the modem speaker on.

Example: "M2"


## SpeakerModeSetup
***

- Data type: *string*
- Access type: Read-only

Command string used to instruct the modem to turn the speaker on (until a connection is established).

Example: "M3"


## SpeakerVolumeHigh
***

- Data type: *string*
- Access type: Read-only

Command string used to set the modem speaker to the highest volume.

Example: "L3"


## SpeakerVolumeInfo
***

- Data type: *uint16*
- Access type: Read-only

Describes the volume level of the audible tones from the modem.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Not Supported* (2)
3.    *High* (3)
4.    *Medium* (4)
5.    *Low* (5)
6.    *Off* (6)
7.    *Auto* (7)

## SpeakerVolumeLow
***

- Data type: *string*
- Access type: Read-only

Command string used to set the modem speaker to the lowest volume.

Example: "L1"


## SpeakerVolumeMed
***

- Data type: *string*
- Access type: Read-only

Command string used to set the modem speaker to a medium volume.

Example: "L2"


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## StringFormat
***

- Data type: *string*
- Access type: Read-only

Type of characters used for text passed through the modem.

The values are:

<dd>"ASCII string format"

<dd>"DBCS string format"

<dd>"UNICODE string format"

- *ASCII string format* ("ASCII string format")
- *DBCS string format* ("DBCS string format")
- *UNICODE string format* ("UNICODE string format")

## SupportsCallback
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the modem supports callback.


## SupportsSynchronousConnect
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, synchronous, as well as asynchronous, communication is supported.


## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## Terminator
***

- Data type: *string*
- Access type: Read-only

String that marks the end of a command string.

Example: "&lt;cr"


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time the modem was last reset.


## Tone
***

- Data type: *string*
- Access type: Read-only

Command string that instructs the modem to use tone mode for dialing. The phone line must support tone dialing.

Example: "T"


## VoiceSwitchFeature
***

- Data type: *string*
- Access type: Read-only

Command strings used to activate the voice capabilities of a voice modem.

Example: "AT+V"

</md>
'''

USBHUB = u'''<md>
# USB Hub
***

The *Win32_USBHub* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

- 1 (0x1)
Other
- 2 (0x2)
Unknown
- 3 (0x3)
Running or Full Power
- 4 (0x4)
Warning
- 5 (0x5)
In Test
- 6 (0x6)
Not Applicable
- 7 (0x7)
Power Off
- 8 (0x8)
Off Line
- 9 (0x9)
Off Duty
- 10 (0xA)
Degraded
- 11 (0xB)
Not Installed
- 12 (0xC)
Install Error
- 13 (0xD)
Power Save - Unknown

The device is known to be in a power save mode, but its exact status is unknown.
- 14 (0xE)
Power Save - Low Power Mode

The device is in a power save state but still functioning, and may exhibit degraded performance.
- 15 (0xF)
Power Save - Standby

The device is not functioning, but could be brought to full power quickly.
- 16 (0x10)
Power Cycle
- 17 (0x11)
Power Save - Warning

The device is in a warning state, though also in a power save mode.

## Caption
***

- Data type: *string*
- Access type: Read-only

## ClassCode
***

- Data type: *uint8*
- Access type: Read-only

## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

## CreationClassName
***

- Data type: *string*
- Access type: Read-only

## CurrentAlternateSettings
***

- Data type: *uint8* array
- Access type: Read-only

## CurrentConfigValue
***

- Data type: *uint8*
- Access type: Read-only

## Description
***

- Data type: *string*
- Access type: Read-only

## DeviceID
***

- Data type: *string*
- Access type: Read-only

An address or other identifying information which uniquely identifies the USBHub.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

## GangSwitched
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, power is switched to all ports on the hub simultaneously. If *FALSE*, power is switched individually for each port.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Name
***

- Data type: *string*
- Access type: Read-only

Indicates the name of the USB Hub.


## NumberOfConfigs
***

- Data type: *uint8*
- Access type: Read-only

Number of device configurations that are defined for the device.


## NumberOfPorts
***

- Data type: *uint8*
- Access type: Read-only

Number of downstream ports on the hub, including those embedded in the hub's silicon.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Win32 Plug and Play device identifier  of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from *CIM_LogicalDevice*.

- 0 (0x0)
Unknown
- 1 (0x1)
Not Supported
- 2 (0x2)
Disabled
- 3 (0x3)
Enabled

The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
- 4 (0x4)
Power Saving Modes Entered Automatically

The device can change its power state based on usage or other criteria.
- 5 (0x5)
Power State Settable
- 6 (0x6)
Power Cycling Supported
- 7 (0x7)
Timed Power On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power managed, that is, put into a power-save state. If *FALSE*, the integer value 1 ("Not Supported") should be the only entry in the *PowerManagementCapabilities* array.


## ProtocolCode
***

- Data type: *uint8*
- Access type: Read-only

## Status
***

- Data type: *string*
- Access type: Read-only

Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only
- 1 (0x1)
Other
- 2 (0x2)
Unknown
- 3 (0x3)
Enabled
- 4 (0x4)
Disabled
- 5 (0x5)
Not Applicable

## SubclassCode
***

- Data type: *uint8*
- Access type: Read-only

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

## SystemName
***

- Data type: *string*
- Access type: Read-only

## USBVersion
***

- Data type: *uint16*
- Access type: Read-only
<h2>Requirements</h2>
<table summary="table">
<tr><th scope="row">
Minimum supported client

</th><td>
WindowsVista

</td></tr>
<tr><th scope="row">
Minimum supported server

</th><td>
Windows Server2008

</td></tr>
<tr><th scope="row">
Namespace

</th><td>
Root\CIMV2

</td></tr>
<tr><th scope="row">
MOF

</th><td>
- Wmipcima.mof
</td></tr>
<tr><th scope="row">
DLL

</th><td>
- Wmipcima.dll
</td></tr>
</table>
<h2>See also</h2>
-
-
</div>
</div>
<div class="libraryMemberFilter">
    <div class="filterContainer">
        <span>Show:</span>
        <label>
            <input type="checkbox" class="libraryFilterInherited" checked="checked" value="Inherit" />Inherited
        </label>
        <label>
            <input type="checkbox" class="libraryFilterProtected" checked="checked" value="Protected" />Protected
        </label>
    </div>
</div>
<input type="hidden" id="libraryMemberFilterEmptyWarning" value="There are no members available with your current filter settings." />
    </div>
<div id="rightNavigationMenu" ms.cmpgrp="right nav">
    <div id="mobileButtons">
        <div id="navigationButtons">
            <a id="isd_printABook" href="/en-us/library/export/help/?returnurl=%2fen-us%2flibrary%2faa394506(v%3dvs.85).aspx">
                <ins class="export"></ins>Export (<span class="count">0</span>)
            </a>
        </div>
    </div>
    <div id="navMain">
        <div id="closeNavigation">
            <a class="tocCloseSmall" id="closeButton"></a>
        </div>
        <div id="navigationButtons">
            <a id="isd_printABook2" href="/en-us/library/export/help/?returnurl=%2fen-us%2flibrary%2faa394506(v%3dvs.85).aspx">
                <ins class="export"></ins>Export (<span class="count">0</span>)
            </a>
            <a id="isdShare" href="#" role="button" aria-expanded="false">
                <ins class="share"></ins>Share
            </a>
            <div id="socials" style="display: none">
                <a class="isdFacebook" href="#" aria-label="Share on Facebook">
                    <ins class="facebook"></ins>
                </a>
                <a class="isdTwitter" href="#" aria-label="Share on Twitter">
                    <ins class="twitter"></ins>
                </a>
                <a class="isdGooglePlus" href="#" aria-label="Share on Google+">
                    <ins class="googlePlus"></ins>
                </a>
            </div>
        </div>
        <div id="indoc_toc" style="display: none" ms.cmpgrp="indoc toc">
            <div id="indoc_title">IN THIS ARTICLE</div>
            <ul id="indoc_toclist"></ul>
        </div>
    </div>
</div>
<div id="rightNavigationMenuThumbnail" class="rightNavigationMenuThumbnail">
</div>
        </div>
        <div class="clear"></div>
<input name="__RequestVerificationToken" type="hidden" value="pWfOEuWxHcVZS43Wa7mfiMNoxvRMR7YlEAYNpybi2Osvwk1iADsB9MK1aRZbSnYGlIahr_yRMo_ddH-i8AzWQpciDDU1" />
<input id="ratingValueSubmitUrl" type="hidden" value="https://msdn.microsoft.com/en-us/library/feedback/rate/aa394506(v=vs.85).aspx" />
<input id="ratingAdditionalSubmitUrl" type="hidden" value="https://msdn.microsoft.com/en-us/library/feedback/additional/aa394506(v=vs.85).aspx" />
<input id="isTopicRated" type="hidden" value="false" />
    <div id="lib-footer">
    <link type="text/css" rel="stylesheet" />
    <div id="ux-footer" class="" style="" dir="ltr" ms.pgarea="footer">
    <div id="standardRatingBefore" class="clear stdr-container-before"></div>
    <div id="standardRating" class="stdr-container" ms.pgarea="body">
        <div class="stdr-close"></div>
        <div class="stdr-vote stdr-content">
            <div class="stdr-content">
                <span class="stdr-votetitle">Is this page helpful?</span>
                <button class="stdr-yes" aria-label="Yes, this page was helpful">Yes</button>
                <button class="stdr-no" aria-label="No, this page was not helpful">No</button>
                <input id="s_ratingValue" type="hidden" value="" />
            </div>
        </div>
        <div class="stdr-feedback" style="display: none">
            <div class="stdr-form">
                <div class="stdr-fieldtitle">Additional feedback?</div>
                <textarea class="stdr-detail" rows="6" maxlength="1500"></textarea>
                <div>
                    <span class="stdr-count"><span class="stdr-charcnt">1500</span> characters remaining</span>
                    <div class="stdr-buttons">
                        <button class="stdr-provide" aria-label="Submit my additional feedback">Submit</button>
                        <button class="stdr-skip" aria-label="Skip additional feedback">Skip this</button>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="stdr-thanks" style="display: none">
            <div class="stdr-content">
                <span class="stdr-thankyou">Thank you!</span>
                <span class="stdr-appreciate">We appreciate your feedback.</span>
            </div>
        </div>
        <div id="contentFeedbackQAContainer" style="display: none;"></div>
    </div>
    <div id="standardRatingPlaceholder" style="display: none"></div>
        <footer class="top" role="navigation" aria-label="footer">
            <div data-fragmentName="LeftLinks" id="Fragment_LeftLinks" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <h4 class="linkListTitle">Dev centers</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            <div id="rightLinks">
                <div data-fragmentName="CenterLinks1" id="Fragment_CenterLinks1" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <h4 class="linkListTitle">Learning resources</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks2" id="Fragment_CenterLinks2" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <h4 class="linkListTitle">Community</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks3" id="Fragment_CenterLinks3" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <h4 class="linkListTitle">Support</h4>
    <ul class="links">
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks4" id="Fragment_CenterLinks4" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <h4 class="linkListTitle">Programs</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            </div>
        </footer>
        <footer class="bottom" role="contentinfo">
            <span class="localeContainer">
    <form class="selectLocale" id="selectLocaleForm" action="https://msdn.microsoft.com/en-us/selectlocale-dmc">
        <input type="hidden" name="fromPage" value="https%3a%2f%2fmsdn.microsoft.com%2fen-us%2flibrary%2faa394506(v%3dvs.85).aspx" />
    </form>
            </span>
            <div data-fragmentName="BottomLinks" id="Fragment_BottomLinks" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <ul class="links horizontal">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            <span class="logoLegal">
                <span class="logoSpan clip67x13" role="img" tabindex="0" aria-label="microsoft logo">
                    <img alt="logo" class="logo" src="https://i-msdn.sec.s-msft.com/Areas/Centers/Themes/StandardDevCenter/Content/HeaderFooterSprite.png?v=636221982560760644" />
                </span>
                <span class="copyright"> 2017 Microsoft</span>
            </span>
        </footer>
    </div>
    </div>
        <div class="footerPrintView">
            <div class="footerCopyrightPrintView"> 2017 Microsoft</div>
        </div>
    <input id="tocPaddingPerLevel" type="hidden" value="17" />
        <input id="MtpsDevice" type="hidden" value="Default" />
<![CDATA[ Third party scripts and code linked to or referenced from this website are licensed to you by the parties that own such code, not by Microsoft.  See ASP.NET Ajax CDN Terms of Use  http://www.asp.net/ajaxlibrary/CDN.ashx. ]]>
<![CDATA[ WebTrends view model not available or IncludeLegacyWebTrendsScriptInGlobal feature flag is off]]>
<div id="globalRequestVerification">
    <input name="__RequestVerificationToken" type="hidden" value="enJNMf_530QG45Kz6EFGaKRfufJpoBWYJYRX-eSGueoiZeansmqVNo_ADc8rM8eykTRGv8UPzOZB2571F-btJjwikr81" />
</div>
    </div>
<script type="text/javascript" class="mtps-injected">
/*<![CDATA[*/
(function(window,document){"use strict";function preload(scripts){for(var result=[],script,e,i=0;i<scripts.length;i++)script=scripts[i],script.hasOwnProperty("url")&&(e=document.createElement("script"),e.src=script.url,script.throwaway=e),result.push(script);return result}function inject(scripts,index){var script,elem;if(index>=scripts.length){delete mtps.injectScripts;return}script=scripts[index];elem=document.createElement("script");elem.className="mtps-injected";elem.async=!1;var isLoaded=!1,timeoutId=0,injectNextFnName="",injectNext=elem.onerror=function(){isLoaded||(isLoaded=!0,inject(scripts,index+1),window.clearTimeout(timeoutId),elem.onload=elem.onerror=elem.onreadystatechange=null,injectNextFnName&&delete mtps[injectNextFnName],elem.removeEventListener&&elem.removeEventListener("load",injectNext,!1))};elem.addEventListener?elem.addEventListener("load",injectNext,!1):elem.readyState==="uninitialized"?elem.onreadystatechange=function(){(this.readyState==="loaded"||this.readyState==="complete")&&injectNext()}:elem.onload=injectNext;script.hasOwnProperty("url")?(timeoutId=window.setTimeout(injectNext,12e4),elem.src=script.url):(injectNextFnName="_injectNextScript_"+index,mtps[injectNextFnName]=injectNext,timeoutId=window.setTimeout(injectNext,2e3),elem.text="try {
"+script.txt+"
} finally { MTPS."+injectNextFnName+" && MTPS."+injectNextFnName+"(); }");parent.appendChild(elem)}var mtps=window.MTPS||(window.MTPS={}),parent=document.getElementsByTagName("head")[0];mtps.injectScripts=function(scripts){inject(preload(scripts),0)}})(window,document);
MTPS.injectScripts([
{ txt: "/**/
(window.MTPS || (window.MTPS = {})).cdnDomains || (window.MTPS.cdnDomains = {
"image": "https://i-msdn.sec.s-msft.com",
"js": "https://i2-msdn.sec.s-msft.com",
"css": "https://i-msdn.sec.s-msft.com",
"ttf": "https://i-msdn.sec.s-msft.com"
});
/**/" },
{ txt: "//
        window.appInsightsId = '5eb1b2eb-c47a-497a-a7ac-a1c230b2882f';
        //" },
{ url: "https://i2-msdn.sec.s-msft.com/Combined.js?resources=0:Utilities,1:Layout,2:Header,3:Breadcrumbs,4:LibraryRightNavigationMenu,4:PrintExportButton,5:StandardRating,2:Footer,0:Topic,3:ResponsiveSupport,0:AppInsightsPerf,3:ResponsiveToc,0:ABTestControl,4:WEDCS,3:CmpgrpForHeader,1:SearchBox;/Areas/Epx/Content/Scripts:0,/Areas/Epx/Themes/Base/Content:1,/Areas/Centers/Themes/StandardDevCenter/Content:2,/Areas/Library/Content:3,/Areas/Library/Themes/Base/Content:4,/Areas/Global/Content:5&amp;hashKey=380CB181B38C487101990C8F514C8659&amp;v=F314B163E8B6FD251181E3EA43E44BD3" },
{ url: "https://i1.services.social.microsoft.com/search/Widgets/SearchBox.jss?boxid=HeaderSearchTextBox&btnid=HeaderSearchButton&minimumTermLength=2&pgArea=header&brand=Msdn&loc=en-us&focusOnInit=false&emptyWatermark=true&searchButtonTooltip=Search MSDN" },
{ url: "https://i2-msdn.sec.s-msft.com/Combined.js?resources=0:JumpRedirect,1:LibraryMemberFilter,2:Toc_Fixed,2:CodeSnippet,2:TopicNotInScope,2:VersionSelector,2:SurveyBroker;/Areas/Epx/Themes/Base/Content:0,/Areas/Library/Content:1,/Areas/Epx/Content/Scripts:2&amp;hashKey=8B88EB517137869CDE8F8A6DFD775854&amp;v=F314B163E8B6FD251181E3EA43E44BD3" },
{ txt: "$(document).ready(function() {
        try {
            var token = $("#globalRequestVerification input[name='__RequestVerificationToken']").clone();
            $("#siteFeedbackForm").append(token);
        } catch(err) {
        }
    });" }
]);
/*]]>*/
</script></body>
</md>
'''

KEYBOARD = u'''<md>
# Keyboard
***

The *Win32_Keyboard* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Address or other identifying information to uniquely name the logical device.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and   corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## IsLocked
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is locked, preventing user input or output.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Layout
***

- Data type: *string*
- Access type: Read-only

Free-form string indicating the layout of the keyboard.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## NumberOfFunctionKeys
***

- Data type: *uint16*
- Access type: Read-only

Number of function keys on the keyboard.


## Password
***

- Data type: *uint16*
- Access type: Read-only

Status of hardware-level password enabled at the keyboard (value=4), preventing local input.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Disabled* (3)
4.    *Enabled* (4)
5.    *Not Implemented* (5)

## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.

</md>
'''

VOLTAGEPROBE = u'''<md>
# Voltage Probe
***

The *Win32_VoltageProbe* class has these properties.


## Accuracy
***

- Data type: *sint32*
- Access type: Read-only

Accuracy of the sensor for the measured property. The accuracy  value is recorded as plus or minus hundredths of a percent. Accuracy, along with resolution and tolerance, is used to calculate the actual value of the measured physical property. The accuracy may vary and depends on whether or not the device is linear in its dynamic range.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, this property allows all instances of this class and its subclasses to be uniquely identified.


## CurrentReading
***

- Data type: *sint32*
- Access type: Read-only

Current value indicated by the sensor.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the voltage probe.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information about any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object is installed. This property does not need a value to indicate that the object is installed.


## IsLinear
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the sensor is linear over its dynamic range.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## LowerThresholdCritical
***

- Data type: *sint32*
- Access type: Read-only

Sensor threshold values specify the ranges (minimum and maximum values) to determine if the sensor is operating under normal, noncritical, critical, or fatal conditions. If *CurrentReading* is between *LowerThresholdCritical* and *LowerThresholdFatal*, the current state is critical.


## LowerThresholdFatal
***

- Data type: *sint32*
- Access type: Read-only

Sensor threshold values specify the ranges (minimum and maximum values) to determine if the sensor is operating under normal, noncritical, critical, or fatal conditions. If *CurrentReading* is below *LowerThresholdFatal*, the current state is fatal.


## LowerThresholdNonCritical
***

- Data type: *sint32*
- Access type: Read-only

Sensor threshold values specify the ranges (minimum and maximum values) to determine if the sensor is operating under normal, noncritical, critical, or fatal conditions. If *CurrentReading* is between *LowerThresholdNonCritical* and *UpperThresholdNonCritical*, the sensor is reporting a normal value. If *CurrentReading* is between *LowerThresholdNonCritical* and *LowerThresholdCritical*, the current state is noncritical.


## MaxReadable
***

- Data type: *sint32*
- Access type: Read-only

Largest value of the measured property that the numeric sensor can read.


## MinReadable
***

- Data type: *sint32*
- Access type: Read-only

Smallest value of the measured property that the numeric sensor can read.


## Name
***

- Data type: *string*
- Access type: Read-only

Label for an object. When subclassed, the property can be overridden to be a key property.


## NominalReading
***

- Data type: *sint32*
- Access type: Read-only

Normal or expected value for the numeric sensor.


## NormalMax
***

- Data type: *sint32*
- Access type: Read-only

Normal or expected value for the numeric sensor.


## NormalMin
***

- Data type: *sint32*
- Access type: Read-only

Guidance for the user to indicate the normal minimum range for the numeric sensor.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState</em> parameter set to 5 (Power Cycle) and <em>Time</em> set to a specific date and time, or interval, for power-on.

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed, which means that it can be put into suspend mode, and so on. The property does not indicate that power management features are currently enabled, but it does indicate that the logical device is capable of power management.


## Resolution
***

- Data type: *uint32*
- Access type: Read-only

Ability of the sensor to resolve differences in the measured property. This value may vary and depends on whether the device is linear in its dynamic range.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value for the  *CreationClassName* property of the scoping computer.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## Tolerance
***

- Data type: *sint32*
- Access type: Read-only

Tolerance of the sensor for the measured property. Tolerance, along with resolution and accuracy, is used to calculate the actual value of the measured physical property. Tolerance may vary, and  depends on whether the device is linear in its dynamic range.


## UpperThresholdCritical
***

- Data type: *sint32*
- Access type: Read-only

Sensor threshold values specify the ranges (minimum and maximum values) to determine whether the sensor is operating under normal, noncritical, critical, or fatal conditions. If *CurrentReading* is between *UpperThresholdCritical* and *UpperThresholdFatal*, the current state is critical.


## UpperThresholdFatal
***

- Data type: *sint32*
- Access type: Read-only

Sensor threshold values specify the ranges (minimum and maximum values) to determine whether the sensor is operating under normal, noncritical, critical, or fatal conditions. If *CurrentReading* is above *UpperThresholdFatal*, the current state is fatal.


## UpperThresholdNonCritical
***

- Data type: *sint32*
- Access type: Read-only

Sensor threshold values specify the ranges (minimum and maximum values) to determine whether the sensor is operating under normal, noncritical, critical, or fatal conditions. If *CurrentReading* is between  *LowerThresholdNonCritical*and *UpperThresholdNonCritical*, the sensor is reporting a normal value. If *CurrentReading* is between *UpperThresholdNonCritical* and *UpperThresholdCritical*, the current state is noncritical.

</md>
'''

VIDEOCONTROLLER = u'''<md>
# Video Controller
***

The *Win32_VideoController* class has these properties.


## AcceleratorCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of graphics and 3-D capabilities of the video controller.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Graphics Accelerator* (2)
3.    *3D Accelerator* (3)
3-D Accelerator

## AdapterCompatibility
***

- Data type: *string*
- Access type: Read-only

General chipset used for this controller to compare compatibilities with the system.


## AdapterDACType
***

- Data type: *string*
- Access type: Read-only

Name or identifier of the digital-to-analog converter (DAC) chip. The character set of this property is
       alphanumeric.


## AdapterRAM
***

- Data type: *uint32*
- Access type: Read-only

Memory size of the video adapter.

Example: 64000


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
Offline
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## CapabilityDescriptions
***

- Data type: *string* array
- Access type: Read-only

Free-form strings providing more detailed explanations for any of the video accelerator features indicated in the *AcceleratorCapabilities* array. Note, each entry of this array is related to the entry in the *AcceleratorCapabilities* array that is located at the same index.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## ColorTableEntries
***

- Data type: *uint32*
- Access type: Read-only

Size of the system's color table. The device must have a color depth of no more than 8 bits per pixel; otherwise, this property is not set.

Example: 256


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, this property allows all instances of this class and its subclasses to be uniquely identified.


## CurrentBitsPerPixel
***

- Data type: *uint32*
- Access type: Read-only

Number of bits used to display each pixel.


## CurrentHorizontalResolution
***

- Data type: *uint32*
- Access type: Read-only

Current number of horizontal pixels.


## CurrentNumberOfColors
***

- Data type: *uint64*
- Access type: Read-only

Number of colors supported at the current resolution.


## CurrentNumberOfColumns
***

- Data type: *uint32*
- Access type: Read-only

Number of columns for this video controller (if in character mode). Otherwise, enter 0 (zero).


## CurrentNumberOfRows
***

- Data type: *uint32*
- Access type: Read-only

Number of rows for this video controller (if in character mode). Otherwise, enter 0 (zero).


## CurrentRefreshRate
***

- Data type: *uint32*
- Access type: Read-only

Frequency at which the video controller refreshes the image for the monitor. A value of 0 (zero) indicates the default rate is being used, while 0xFFFFFFFF indicates the optimal rate is being used.


## CurrentScanMode
***

- Data type: *uint16*
- Access type: Read-only

Current scan mode.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Interlaced* (3)
4.    *Non Interlaced* (4)
Noninterlaced

## CurrentVerticalResolution
***

- Data type: *uint32*
- Access type: Read-only

Current number of vertical pixels.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Identifier (unique to the computer system) for this video controller.


## DeviceSpecificPens
***

- Data type: *uint32*
- Access type: Read-only

Current number of device-specific pens. A value of 0xffff means that the device does not support pens.

Example: 3


## DitherType
***

- Data type: *uint32*
- Access type: Read-only

Dither type of the video controller. The property can be one of the predefined values, or a driver-defined value greater than or equal to 256. If line art dithering is chosen, the controller uses a dithering method that produces well-defined borders between black, white, and gray scalings. Line art dithering is not suitable for images that include continuous graduations in intensity and hue such as scanned photographs.

1.    *No dithering* (1)
2.    *Dithering with a coarse brush* (2)
3.    *Dithering with a fine brush* (3)
4.    *Line art dithering* (4)
5.    *Device does gray scaling* (5)

## DriverDate
***

- Data type: *datetime*
- Access type: Read-only

Last modification date and time of the currently installed video driver.


## DriverVersion
***

- Data type: *string*
- Access type: Read-only

Version number of the video driver.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* property is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

Free-form string supplying more information about the error recorded in *LastErrorCode* property, and information on any corrective actions that may be taken.


## ICMIntent
***

- Data type: *uint32*
- Access type: Read-only

Specific value of one of the three possible color-matching methods or intents that should be used by default. This property is used primarily for non-ICM applications. ICM applications establish intents by using the ICM functions. This property can be a predefined value or a driver defined value greater than or equal to 256. Color matching based on saturation is the most appropriate choice for business graphs when dithering is not desired. Color matching based on contrast is the most appropriate choice for scanned or photographic images when dithering is desired. Color matching optimized to match the exact color requested is most appropriate for use with business logos or other images when an exact color match is desired.

1.    *Saturation* (1)
2.    *Contrast* (2)
3.    *Exact Color* (3)

## ICMMethod
***

- Data type: *uint32*
- Access type: Read-only

Method of handling ICM. For non-ICM applications, this property determines if ICM is enabled. For ICM applications, the system examines this property to determine how to handle ICM support. This property can be a predefined value or a driver-defined value greater than or equal to 256. The value determines which system handles image color matching.

1.    *Disabled* (1)
2.    *Windows* (2)
3.    *Device Driver* (3)
4.    *Destination Device* (4)

## InfFilename
***

- Data type: *string*
- Access type: Read-only

Path to the video adapter's .inf file.

Example: "C:\Windows\SYSTEM32\DRIVERS"


## InfSection
***

- Data type: *string*
- Access type: Read-only

Section of the .inf file where the Windows video information resides.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## InstalledDisplayDrivers
***

- Data type: *string*
- Access type: Read-only

Name of the installed display device driver.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## MaxMemorySupported
***

- Data type: *uint32*
- Access type: Read-only

Maximum amount of memory supported in bytes.


## MaxNumberControlled
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.


## MaxRefreshRate
***

- Data type: *uint32*
- Access type: Read-only

Maximum refresh rate of the video controller in hertz.


## MinRefreshRate
***

- Data type: *uint32*
- Access type: Read-only

Minimum refresh rate of the video controller in hertz.


## Monochrome
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, gray scale is used to display images.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## NumberOfColorPlanes
***

- Data type: *uint16*
- Access type: Read-only

Current number of color planes. If this value is not applicable for the current video configuration, enter 0 (zero).


## NumberOfVideoPages
***

- Data type: *uint32*
- Access type: Read-only

Number of video pages supported given the current resolutions and available memory.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent <a href="https://msdn.microsoft.com/en-us/library/aa387884(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CIM_LogicalDevice*</a> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ProtocolSupported
***

- Data type: *uint16*
- Access type: Read-only

Protocol used by the controller to access "controlled" devices.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *EISA* (3)
4.    *ISA* (4)
5.    *PCI* (5)
6.    *ATA/ATAPI* (6)
ATA or ATAPI
7.    *Flexible Diskette* (7)
8.    *1496* (8)
9.    *SCSI Parallel Interface* (9)
10.    *SCSI Fibre Channel Protocol* (10)
11.    *SCSI Serial Bus Protocol* (11)
12.    *SCSI Serial Bus Protocol-2 (1394)* (12)
13.    *SCSI Serial Storage Architecture* (13)
14.    *VESA* (14)
15.    *PCMCIA* (15)
16.    *Universal Serial Bus* (16)
17.    *Parallel Protocol* (17)
18.    *ESCON* (18)
19.    *Diagnostic* (19)
20.    *I2C* (20)
21.    *Power* (21)
22.    *HIPPI* (22)
23.    *MultiBus* (23)
24.    *VME* (24)
25.    *IPI* (25)
26.    *IEEE-488* (26)
27.    *RS232* (27)
28.    *IEEE 802.3 10BASE5* (28)
29.    *IEEE 802.3 10BASE2* (29)
30.    *IEEE 802.3 1BASE5* (30)
31.    *IEEE 802.3 10BROAD36* (31)
32.    *IEEE 802.3 100BASEVG* (32)
33.    *IEEE 802.5 Token-Ring* (33)
34.    *ANSI X3T9.5 FDDI* (34)
35.    *MCA* (35)
36.    *ESDI* (36)
37.    *IDE* (37)
38.    *CMD* (38)
39.    *ST506* (39)
40.    *DSSI* (40)
41.    *QIC2* (41)
42.    *Enhanced ATA/IDE* (42)
43.    *AGP* (43)
44.    *TWIRP (two-way infrared)* (44)
45.    *FIR (fast infrared)* (45)
46.    *SIR (serial infrared)* (46)
47.    *IrBus* (47)

## ReservedSystemPaletteEntries
***

- Data type: *uint32*
- Access type: Read-only

Number of reserved entries in the system palette. The operating system may reserve entries to support standard colors for task bars and other desktop display items. This index is valid only if the device driver sets the *RC_PALETTE* bit in the RASTERCAPS index, and is available only if the driver is compatible with 16-bit Windows. If the system is not using a palette, *ReservedSystemPaletteEntries* is not set.

Example: 20


## SpecificationVersion
***

- Data type: *uint32*
- Access type: Read-only

Version number of the initialization data specification (upon which the structure is based).


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## SystemPaletteEntries
***

- Data type: *uint32*
- Access type: Read-only

Current number of color index entries in the system palette. This index is valid only if the device driver sets the *RC_PALETTE* bit in the RASTERCAPS index, and is available only if the driver is compatible with 16-bit Windows. If the system is not using a palette, *SystemPaletteEntries* is not set.

Example: 20


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time this controller was last reset. This could mean the controller was powered down or reinitialized.


## VideoArchitecture
***

- Data type: *uint16*
- Access type: Read-only

Type of video architecture.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *CGA* (3)
4.    *EGA* (4)
5.    *VGA* (5)
6.    *SVGA* (6)
7.    *MDA* (7)
8.    *HGC* (8)
9.    *MCGA* (9)
10.    *8514A* (10)
11.    *XGA* (11)
12.    *Linear Frame Buffer* (12)
160.    *PC-98* (160)

## VideoMemoryType
***

- Data type: *uint16*
- Access type: Read-only

Type of video memory.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *VRAM* (3)
4.    *DRAM* (4)
5.    *SRAM* (5)
6.    *WRAM* (6)
7.    *EDO RAM* (7)
8.    *Burst Synchronous DRAM* (8)
9.    *Pipelined Burst SRAM* (9)
10.    *CDRAM* (10)
11.    *3DRAM* (11)
12.    *SDRAM* (12)
13.    *SGRAM* (13)

## VideoMode
***

- Data type: *uint16*
- Access type: Read-only

Current video mode.


## VideoModeDescription
***

- Data type: *string*
- Access type: Read-only

Current resolution, color, and scan mode settings of the video controller.

Example: "1024 x 768 x 256 colors"


## VideoProcessor
***

- Data type: *string*
- Access type: Read-only

Free-form string describing the video processor.

</md>
'''

CACHEMEMORY = u'''<md>
# Cache Memory
***

The *Win32_CacheMemory* class has these properties.


## Access
***

- Data type: *uint16*
- Access type: Read-only

Type of access.

0.    *Unknown* (0)
1.    *Readable* (1)
2.    *Writeable* (2)
Writable
3.    *Read/Write Supported* (3)
4.    *Write Once* (4)

## AdditionalErrorData
***

- Data type: *uint8* array
- Access type: Read-only

Array of octets that hold additional error information. An example is ECC Syndrome or the return of the check bits if a CRC-based error methodology is used. In the latter case, if a single-bit error is recognized and the CRC algorithm is known, it is possible to determine the exact bit that failed. This type of data (ECC Syndrome, Check Bit, Parity Bit data, or other vendor supplied information) is included in this field. If the *ErrorInfo* property is equal to 3 (OK), then this property has no meaning.


## Associativity
***

- Data type: *uint16*
- Access type: Read-only

An integer enumeration that defines the system cache associativity.

This value comes from the *Associativity* member of the *Cache Information* structure in the SMBIOS information.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Direct Mapped* (3)
4.    *2-way Set-Associative* (4)
5.    *4-way Set-Associative* (5)
6.    *Fully Associative* (6)
7.    *8-way Set-Associative* (7)
8.    *16-way Set-Associative* (8)

## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

This value comes from the *Cache Configuration* member of the *Cache Information* structure in the SMBIOS information.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## BlockSize
***

- Data type: *uint64*
- Access type: Read-only

Size in bytes of the blocks that form this storage extent. If unknown or if a block concept is not valid (for example, for aggregate extents, memory, or logical disks), enter a 1.


## CacheSpeed
***

- Data type: *uint32*
- Access type: Read-only

Speed of the cache.

This value comes from the *Cache Speed* member of the *Cache Information* structure in the SMBIOS information.


## CacheType
***

- Data type: *uint16*
- Access type: Read-only

Type of cache.

This value comes from the *System Cache Type* member of the *Cache Information* structure in the SMBIOS information.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Instruction* (3)
4.    *Data* (4)
5.    *Unified* (5)

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device is using a user-defined configuration.


## CorrectableError
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the most recent error was correctable. If the *ErrorInfo* property is equal to 3 (OK), then this property has no meaning.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## CurrentSRAM
***

- Data type: *uint16* array
- Access type: Read-only

Array of types of Static Random Access Memory (SRAM) being used for the cache memory.

This value comes from the *Current SRAM Type* member of the *Cache Information* structure in the SMBIOS information.

0.    *Other* (0)
1.    *Unknown* (1)
2.    *Non-Burst* (2)
3.    *Burst* (3)
4.    *Pipeline Burst* (4)
5.    *Synchronous* (5)
6.    *Asynchronous* (6)

## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the cache represented by an instance of  *Win32_CacheMemory*.

Example: "Cache Memory 1"


## EndingAddress
***

- Data type: *uint64*
- Access type: Read-only

Ending address, referenced by an application or operating system and mapped by a memory controller, for this memory object. The ending address is specified in kilobytes.


## ErrorAccess
***

- Data type: *uint16*
- Access type: Read-only

Memory access operation that caused the last error. The type of error is described by the *ErrorInfo* property. If *ErrorInfo* is equal to 3 (OK), then this property has no meaning.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Read* (3)
4.    *Write* (4)
5.    *Partial Write* (5)

## ErrorAddress
***

- Data type: *uint64*
- Access type: Read-only

Address of the last memory error. The type of error is described by the *ErrorInfo* property. If *ErrorInfo* is equal to 3 (OK), then this property has no meaning.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the error reported in *LastErrorCode* is now cleared.


## ErrorCorrectType
***

- Data type: *uint16*
- Access type: Read-only

Error correction method used by the cache memory.

This value comes from the *Error Correction Type* member of the *Cache Information* structure in the SMBIOS information.

0.    *Reserved* (0)
1.    *Other* (1)
2.    *Unknown* (2)
3.    *None* (3)
4.    *Parity* (4)
5.    *Single-bit ECC* (5)
6.    *Multi-bit ECC* (6)

## ErrorData
***

- Data type: *uint8* array
- Access type: Read-only

Array of data captured during the last erroneous memory access. The data occupies the first <em>n</em> octets of the array necessary to hold the number of bits specified by the *ErrorTransferSize* property. If *ErrorTransferSize* is 0 (zero), then this property has no meaning.


## ErrorDataOrder
***

- Data type: *uint16*
- Access type: Read-only

Ordering for data stored in the *ErrorData* property. If *ErrorTransferSize* is 0 (zero), then this property has no meaning.

0.    *Unknown* (0)
1.    *Least Significant Byte First* (1)
2.    *Most Significant Byte First* (2)

## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information on any corrective actions that may be taken.


## ErrorInfo
***

- Data type: *uint16*
- Access type: Read-only

Type of error that occurred most recently. The values 12-14 are undefined in the CIM schema because in DMI they mix the semantics of the type of error and whether it was correctable or not. The latter is indicated in the property *CorrectableError*.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *OK* (3)
4.    *Bad Read* (4)
5.    *Parity Error* (5)
6.    *Single-Bit Error* (6)
7.    *Double-Bit Error* (7)
8.    *Multi-Bit Error* (8)
9.    *Nibble Error* (9)
10.    *Checksum Error* (10)
11.    *CRC Error* (11)
12.    *Undefined* (12)
13.    *Undefined* (13)
14.    *Undefined* (14)

## ErrorMethodology
***

- Data type: *string*
- Access type: Read-only

Details on the parity or CRC algorithms, ECC, or other mechanisms used.


## ErrorResolution
***

- Data type: *uint64*
- Access type: Read-only

Range, in bytes, to which the last error can be resolved. For example, if error addresses are resolved to bit 11 (that is, on a typical page basis), then errors can be resolved to 4 KB boundaries and this property is set to 4000. If the *ErrorInfo* property is equal to 3 (OK), then this property has no meaning.


## ErrorTime
***

- Data type: *datetime*
- Access type: Read-only

Time that the last memory error occurred. The type of error is described by the *ErrorInfo* property. If the *ErrorInfo* property is equal to 3 (OK), then this property has no meaning.


## ErrorTransferSize
***

- Data type: *uint32*
- Access type: Read-only

Size of the data transfer in bits that caused the last error. 0 (zero) indicates no error. If the *ErrorInfo* property is equal to 3 (OK), then this property should be set to 0 (zero).


## FlushTimer
***

- Data type: *uint32*
- Access type: Read-only

Maximum amount of time, in seconds, dirty lines or buckets may remain in the cache before they are flushed. A value of 0 (zero) indicates that a cache flush is not controlled by a flushing timer.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## InstalledSize
***

- Data type: *uint32*
- Access type: Read-only

Current size of the installed cache memory.

This value comes from the *Installed Size* member of the *Cache Information* structure in the SMBIOS information.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Level
***

- Data type: *uint16*
- Access type: Read-only

Level of the cache.

This value comes from the *Cache Configuration* member of the *Cache Information* structure in the SMBIOS information.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Primary* (3)
4.    *Secondary* (4)
5.    *Tertiary* (5)
6.    *Not Applicable* (6)

## LineSize
***

- Data type: *uint32*
- Access type: Read-only

Size, in bytes, of a single cache bucket or line.


## Location
***

- Data type: *uint16*
- Access type: Read-only

Physical location of the cache memory.

This value comes from the *Cache Configuration* member of the *Cache Information* structure in the SMBIOS information.

0.    *Internal* (0)
1.    *External* (1)
2.    *Reserved* (2)
3.    *Unknown* (3)

## MaxCacheSize
***

- Data type: *uint32*
- Access type: Read-only

Maximum cache size installable to this particular cache memory.

This value comes from the *Maximum Cache Size* member of the *Cache Information* structure in the SMBIOS information.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## NumberOfBlocks
***

- Data type: *uint64*
- Access type: Read-only

Total number of consecutive blocks, each block the size of the value contained in the *BlockSize* property, which form this storage extent. Total size of the storage extent can be calculated by multiplying the value of the *BlockSize* property by the value of this property. If the value of *BlockSize* is 1, this property is the total size of the storage extent.


## OtherErrorDescription
***

- Data type: *string*
- Access type: Read-only

Free-form string providing more information if the *ErrorType* property is set to 1, Other. Otherwise, this string has no meaning.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## Purpose
***

- Data type: *string*
- Access type: Read-only

Free-form string describing the media and its use.

This value comes from the *Socket Designation* member of the *Cache Information* structure in the SMBIOS information.


## ReadPolicy
***

- Data type: *uint16*
- Access type: Read-only

Policy that shall be employed by the cache for handling read requests.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Read* (3)
4.    *Read-Ahead* (4)
5.    *Read and Read-Ahead* (5)
6.    *Determination Per I/O* (6)

## ReplacementPolicy
***

- Data type: *uint16*
- Access type: Read-only

Algorithm to determine which cache lines or buckets should be reused.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Least Recently Used (LRU)* (3)
4.    *First In First Out (FIFO)* (4)
5.    *Last In First Out (LIFO)* (5)
6.    *Least Frequently Used (LFU)* (6)
7.    *Most Frequently Used (MFU)* (7)
8.    *Data Dependent Multiple Algorithms* (8)

## StartingAddress
***

- Data type: *uint64*
- Access type: Read-only

Beginning address, referenced by an application or operating system and mapped by a memory controller, for this memory object. The starting address is specified in kilobytes.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

This value comes from the *Cache Configuration* member of the *Cache Information* structure in the SMBIOS information.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SupportedSRAM
***

- Data type: *uint16* array
- Access type: Read-only

Array of supported types of Static Random Access Memory (SRAM) that can be used for the cache memory.

This value comes from the *Supported SRAM Type* member of the *Cache Information* structure in the SMBIOS information.

0.    *Other* (0)
1.    *Unknown* (1)
2.    *Non-Burst* (2)
3.    *Burst* (3)
4.    *Pipeline Burst* (4)
5.    *Synchronous* (5)
6.    *Asynchronous* (6)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemLevelAddress
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the address information in the property *ErrorAddress* is a system-level address. If *False*, it is a physical address. If the *ErrorInfo* property is equal to 3, then this property has no meaning.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## WritePolicy
***

- Data type: *uint16*
- Access type: Read-only

Write policy definition.

This value comes from the *Cache Configuration* member of the *Cache Information* structure in the SMBIOS information.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Write Back* (3)
4.    *Write Through* (4)
5.    *Varies with Address* (5)
6.    *Determination Per I/O* (6)
</md>
'''

PROCESSOR = u'''<md>
# Processor
***

The *Win32_Processor* class has these properties.


## AddressWidth
***

- Data type: *uint16*
- Access type: Read-only

On a 32-bit operating system, the value is 32 and on a 64-bit operating system it is 64.


## Architecture
***

- Data type: *uint16*
- Access type: Read-only

Processor architecture used by the  platform.

0.    *x86* (0)
1.    *MIPS* (1)
2.    *Alpha* (2)
3.    *PowerPC* (3)
- 5
ARM
6.    *ia64* (6)
Itanium-based systems
9.    *x64* (9)

## AssetTag
***

- Data type: *string*
- Access type: Read-only

Represents the asset tag of this processor.

This value comes from the *Asset Tag* member of the *Processor Information* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save state, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state, but is still functioning, and may exhibit decreased performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but can be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save state.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of an  object (a one-line string).


## Characteristics
***

- Data type: *uint32*
- Access type: Read-only

Defines which functions the processor supports.

This value comes from the *Processor Characteristics* member of the *Processor Information* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Windows API Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must  be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a configuration that the user defines.


## CpuStatus
***

- Data type: *uint16*
- Access type: Read-only

Current status of the processor. Status changes indicate  processor usage, but not the physical condition of the processor.

This value comes from the *Status* member of the *Processor Information* structure in the SMBIOS information.

0.    *Unknown* (0)
1.    *CPU Enabled* (1)
2.    *CPU Disabled by User via BIOS Setup* (2)
3.    *CPU Disabled By BIOS (POST Error)* (3)
4.    *CPU is Idle* (4)
5.    *Reserved* (5)
6.    *Reserved* (6)
7.    *Other* (7)

## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used to create  an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.


## CurrentClockSpeed
***

- Data type: *uint32*
- Access type: Read-only

Current speed of the processor, in MHz.

This value comes from the *Current Speed* member of the *Processor Information* structure in the SMBIOS information.


## CurrentVoltage
***

- Data type: *uint16*
- Access type: Read-only

Voltage of the processor. If the eighth bit is set,  bits  0-6 contain the voltage multiplied by 10. If the eighth bit is not set, then the bit setting in *VoltageCaps* represents the voltage value. *CurrentVoltage* is only set when SMBIOS designates a voltage value.

Example: Value for a processor voltage of 1.8 volts is 0x12 (1.8 x 10).

This value comes from the *Voltage* member of the *Processor Information* structure in the SMBIOS information.


## DataWidth
***

- Data type: *uint16*
- Access type: Read-only

On a 32-bit processor, the value is 32 and on a 64-bit processor it is 64.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of a processor  on the system.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is  clear.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information about corrective actions that can be taken.


## ExtClock
***

- Data type: *uint32*
- Access type: Read-only

External clock frequency, in MHz. If the frequency is unknown, this property is set to *NULL*.

This value comes from the *External Clock* member of the *Processor Information* structure in the SMBIOS information.


## Family
***

- Data type: *uint16*
- Access type: Read-only

Processor family type.

This value comes from the *Processor Information* structure in the SMBIOS version information. For SMBIOS versions 2.0 thru 2.5 the value comes from the *Processor Family* member. For SMBIOS version 2.6+ the value comes from the *Processor Family 2* member.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *8086* (3)
4.    *80286* (4)
5.    *80386* (5)
Intel386 Processor
6.    *80486* (6)
Intel486 Processor
7.    *8087* (7)
8.    *80287* (8)
9.    *80387* (9)
10.    *80487* (10)
11.    *Pentium(R) brand* (11)
Pentium Brand
12.    *Pentium(R) Pro* (12)
Pentium Pro
13.    *Pentium(R) II* (13)
Pentium II
14.    *Pentium(R) processor with MMX(TM) technology* (14)
Pentium Processor with MMX Technology
15.    *Celeron(TM)* (15)
Celeron
16.    *Pentium(R) II Xeon(TM)* (16)
Pentium II Xeon
17.    *Pentium(R) III* (17)
Pentium III
18.    *M1 Family* (18)
19.    *M2 Family* (19)
24.    *K5 Family* (24)
AMD Duron Processor Family
25.    *K6 Family* (25)
K5 Family
26.    *K6-2* (26)
K6 Family
27.    *K6-3* (27)
K6-2
28.    *AMD Athlon(TM) Processor Family* (28)
K6-3
29.    *AMD(R) Duron(TM) Processor* (29)
AMD Athlon Processor Family
30.    *AMD29000 Family* (30)
AMD2900 Family
31.    *K6-2+* (31)
32.    *Power PC Family* (32)
33.    *Power PC 601* (33)
34.    *Power PC 603* (34)
35.    *Power PC 603+* (35)
36.    *Power PC 604* (36)
37.    *Power PC 620* (37)
38.    *Power PC X704* (38)
39.    *Power PC 750* (39)
48.    *Alpha Family* (48)
49.    *Alpha 21064* (49)
50.    *Alpha 21066* (50)
51.    *Alpha 21164* (51)
52.    *Alpha 21164PC* (52)
53.    *Alpha 21164a* (53)
54.    *Alpha 21264* (54)
55.    *Alpha 21364* (55)
64.    *MIPS Family* (64)
65.    *MIPS R4000* (65)
66.    *MIPS R4200* (66)
67.    *MIPS R4400* (67)
68.    *MIPS R4600* (68)
69.    *MIPS R10000* (69)
80.    *SPARC Family* (80)
81.    *SuperSPARC* (81)
82.    *microSPARC II* (82)
83.    *microSPARC IIep* (83)
84.    *UltraSPARC* (84)
85.    *UltraSPARC II* (85)
86.    *UltraSPARC IIi* (86)
87.    *UltraSPARC III* (87)
88.    *UltraSPARC IIIi* (88)
96.    *68040* (96)
97.    *68xxx Family* (97)
98.    *68000* (98)
99.    *68010* (99)
100.    *68020* (100)
101.    *68030* (101)
112.    *Hobbit Family* (112)
120.    *Crusoe(TM) TM5000 Family* (120)
Crusoe TM5000 Family
121.    *Crusoe(TM) TM3000 Family* (121)
Crusoe TM3000 Family
122.    *Efficeon(TM) TM8000 Family* (122)
Efficeon TM8000 Family
128.    *Weitek* (128)
130.    *Itanium(TM) Processor* (130)
Itanium Processor
131.    *AMD Athlon(TM) 64 Processor Family* (131)
AMD Athlon 64 Processor Family
132.    *AMD Opteron(TM) Family* (132)
AMD Opteron Processor Family
144.    *PA-RISC Family* (144)
145.    *PA-RISC 8500* (145)
146.    *PA-RISC 8000* (146)
147.    *PA-RISC 7300LC* (147)
148.    *PA-RISC 7200* (148)
149.    *PA-RISC 7100LC* (149)
150.    *PA-RISC 7100* (150)
160.    *V30 Family* (160)
176.    *Pentium(R) III Xeon(TM)* (176)
Pentium III Xeon Processor
177.    *Pentium(R) III Processor with Intel(R) SpeedStep(TM) Technology* (177)
Pentium III Processor with Intel SpeedStep Technology
178.    *Pentium(R) 4* (178)
Pentium 4
179.    *Intel(R) Xeon(TM)* (179)
Intel Xeon
180.    *AS400 Family* (180)
181.    *Intel(R) Xeon(TM) processor MP* (181)
Intel Xeon Processor MP
182.    *AMD AthlonXP(TM) Family* (182)
AMD Athlon XP Family
183.    *AMD AthlonMP(TM) Family* (183)
AMD Athlon MP Family
184.    *Intel(R) Itanium(R) 2* (184)
Intel Itanium 2
185.    *Intel Pentium M Processor* (185)
190.    *K7* (190)
- 198
Intel Core i7-2760QM
200.    *IBM390 Family* (200)
201.    *G4* (201)
202.    *G5* (202)
203.    *G6* (203)
204.    *z/Architecture base* (204)
250.    *i860* (250)
251.    *i960* (251)
260.    *SH-3* (260)
261.    *SH-4* (261)
280.    *ARM* (280)
281.    *StrongARM* (281)
300.    *6x86* (300)
301.    *MediaGX* (301)
302.    *MII* (302)
320.    *WinChip* (320)
350.    *DSP* (350)
500.    *Video Processor* (500)

## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

## L2CacheSize
***

- Data type: *uint32*
- Access type: Read-only

Size of the  Level 2  processor cache. A Level 2 cache is an external memory area that has a faster access time than the main RAM memory.

This value comes from the *L2 Cache Handle* member of the *Processor Information* structure in the SMBIOS information.


## L2CacheSpeed
***

- Data type: *uint32*
- Access type: Read-only

Clock speed of the Level 2 processor cache. A Level 2 cache is an external memory area that has a faster access time than the main RAM memory.

This value comes from the *L2 Cache Handle* member of the *Processor Information* structure in the SMBIOS information.


## L3CacheSize
***

- Data type: *uint32*
- Access type: Read-only

Size of the Level 3 processor cache. A Level 3 cache is an external memory area that has a faster access time than the main RAM memory.

This value comes from the *L3 Cache Handle* member of the *Processor Information* structure in the SMBIOS information.


## L3CacheSpeed
***

- Data type: *uint32*
- Access type: Read-only

Clockspeed of the Level 3 property cache. A Level 3 cache is an external memory area that has a faster access time than the main RAM memory.

This value comes from the *L3 Cache Handle* member of the *Processor Information* structure in the SMBIOS information.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Level
***

- Data type: *uint16*
- Access type: Read-only

Definition of the processor type. The value depends on the architecture of the processor.


## LoadPercentage
***

- Data type: *uint16*
- Access type: Read-only

Load capacity of each processor, averaged  to  the last second. Processor  loading refers to the total computing burden for each processor  at one time.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the processor manufacturer.

Example: A. Datum Corporation

This value comes from the *Processor Manufacturer* member of the *Processor Information* structure in the SMBIOS information.


## MaxClockSpeed
***

- Data type: *uint32*
- Access type: Read-only

Maximum speed  of the  processor, in MHz.

This value comes from the *Max Speed* member of the *Processor Information* structure in the SMBIOS information.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When this property is a subclass,  it can be overridden to be a key property.

This value comes from the *Processor Version* member of the *Processor Information* structure in the SMBIOS information.


## NumberOfCores
***

- Data type: *uint32*
- Access type: Read-only

Number of cores for the current instance of the processor. A core is a physical processor on the integrated circuit. For example, in a dual-core processor this property has a value of 2. For more information, see Remarks.

This value comes from the *Processor Information* structure in the SMBIOS version information. For SMBIOS versions 2.5 thru 2.9 the value comes from the *Core Count* member. For SMBIOS version 3.0+ the value comes from the *Core Count 2* member.


## NumberOfEnabledCore
***

- Data type: *uint32*
- Access type: Read-only

The number of enabled cores per processor socket.

This value comes from the *Processor Information* structure in the SMBIOS version information. For SMBIOS versions 2.5 thru 2.9 the value comes from the *Core Enabled* member. For SMBIOS version 3.0+ the value comes from the *Core Enabled 2* member.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## NumberOfLogicalProcessors
***

- Data type: *uint32*
- Access type: Read-only

Number of logical processors for the current instance of the processor. For processors capable of hyperthreading, this value includes only the processors which have hyperthreading enabled. For more information, see Remarks.


## OtherFamilyDescription
***

- Data type: *string*
- Access type: Read-only

Processor family type. Used when the *Family* property is set to 1, which means Other. This string should be set to *NULL* when the *Family* property is a value that is not  1.


## PartNumber
***

- Data type: *string*
- Access type: Read-only

The part number of this processor as set by the manufacturer.

This value comes from the *Part Number* member of the *Processor Information* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: *PNP030b


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the power of the device can be managed, which means that it can be put into suspend mode, and so on. The property does not indicate that power management features are enabled, but it does indicate  that the logical device power can be  managed.


## ProcessorId
***

- Data type: *string*
- Access type: Read-only

Processor information that describes the processor features. For  an x86 class CPU, the field format depends on the processor support of the CPUID instruction. If the instruction is supported, the property contains 2 (two)  *DWORD* formatted values. The first is an offset of  08h-0Bh, which  is the EAX value that  a CPUID instruction returns with input EAX set to 1. The second is an offset of  0Ch-0Fh, which  is the EDX value  that the instruction returns. Only the first two bytes of the property are significant  and contain  the contents of the DX register at CPU resetall others are set to 0 (zero), and the contents are in *DWORD* format.

This value comes from the *Processor ID* member of the *Processor Information* structure in the SMBIOS information.


## ProcessorType
***

- Data type: *uint16*
- Access type: Read-only

Primary function of the processor.

This value comes from the *Processor Type* member of the *Processor Information* structure in the SMBIOS information.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Central Processor* (3)
4.    *Math Processor* (4)
5.    *DSP Processor* (5)
6.    *Video Processor* (6)

## Revision
***

- Data type: *uint16*
- Access type: Read-only

System revision level that depends on the architecture.  The system revision level  contains the same values as the *Version* property, but in a numerical format.


## Role
***

- Data type: *string*
- Access type: Read-only

Role of the processor.

Examples: Central Processor or Math Processor


## SecondLevelAddressTranslationExtensions
***

- Data type: *boolean*
- Access type: Read-only

If *True*,  the processor supports address translation extensions used for virtualization.

*Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows8 and Windows Server2012.


## SerialNumber
***

- Data type: *string*
- Access type: Read-only

The serial number of this processor This value is set by the manufacturer and normally not changeable.

This value comes from the *Serial Number* member of the *Processor Information* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## SocketDesignation
***

- Data type: *string*
- Access type: Read-only

Type of chip socket used on the circuit.

Example: J202

This value comes from the *Socket Designation* member of the *Processor Information* structure in the SMBIOS information.


## Status
***

- Data type: *string*
- Access type: Read-only

Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, use the value 5, which means Not Applicable.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## Stepping
***

- Data type: *string*
- Access type: Read-only

Revision level of the processor in the processor family.


## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the *CreationClassName* property for the scoping computer.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## ThreadCount
***

- Data type: *uint32*
- Access type: Read-only

The number of threads per processor socket.

This value comes from the *Processor Information* structure in the SMBIOS version information. For SMBIOS versions 2.5 thru 2.9 the value comes from the *Thread Count* member. For SMBIOS version 3.0+ the value comes from the *Thread Count 2* member.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows Server2016 Technical Preview and
        Windows10.


## UniqueId
***

- Data type: *string*
- Access type: Read-only

Globally unique identifier for the processor. This identifier may only be unique within a processor family.


## UpgradeMethod
***

- Data type: *uint16*
- Access type: Read-only

CPU socket information, including the method by which this processor can be upgraded, if upgrades are supported. This property is an integer enumeration.

This value comes from the *Processor Upgrade* member of the *Processor Information* structure in the SMBIOS information.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Daughter Board* (3)
4.    *ZIF Socket* (4)
5.    *Replacement/Piggy Back* (5)
Replacement or Piggy Back
6.    *None* (6)
7.    *LIF Socket* (7)
8.    *Slot 1* (8)
9.    *Slot 2* (9)
10.    *370 Pin Socket* (10)
11.    *Slot A* (11)
12.    *Slot M* (12)
13.    *Socket 423* (13)
14.    *Socket A (Socket 462)* (14)
15.    *Socket 478* (15)
16.    *Socket 754* (16)
17.    *Socket 940* (17)
18.    *Socket 939* (18)

## Version
***

- Data type: *string*
- Access type: Read-only

Processor  revision number that depends on the architecture.

Example: Model 2, Stepping 12


## VirtualizationFirmwareEnabled
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the Firmware has enabled virtualization extensions.

*Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows8 and Windows Server2012.


## VMMonitorModeExtensions
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the processor supports Intel or AMD Virtual Machine Monitor extensions.

*Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows8 and Windows Server2012.


## VoltageCaps
***

- Data type: *uint32*
- Access type: Read-only

Voltage capabilities of the processor. Bits 0-3 of the field represent specific voltages that the processor socket can accept. All other bits should be set to 0 (zero). The socket is configurable if multiple bits are  set. For more information about the actual voltage at which the processor is running, see *CurrentVoltage*. If the property is *NULL*, then the voltage capabilities are unknown.

1.    *5* (1)
5 volts
2.    *3.3* (2)
3.3 volts
4.    *2.9* (4)
2.9 volts
</md>
'''

PRINTERCONTROLLER = u'''<md>
# Printer Controller
***

The *Win32_PrinterController* class has these properties.


## AccessState
***

- Data type: *uint16*
- Access type: Read-only

State of the controller access to the device. This information is necessary when a logical device can be commanded by, or accessed through, multiple controllers.

- *0*
Unknown
- *1*
Active
- *2*
Inactive

## Antecedent
***

- Data type: *CIM_Controller*
- Access type: Read-only

## Dependent
***

- Data type: *Win32_Printer*
- Access type: Read-only

Reference to the

## NegotiatedDataWidth
***

- Data type: *uint32*
- Access type: Read-only

Data width in use between devices (when several bus or connection data widths are possible). Data width is specified in bits. If data width is not negotiated, or if this information is not available or important to device management, the property should be set to 0 (zero).


## NegotiatedSpeed
***

- Data type: *uint64*
- Access type: Read-only

Speed in use between devices (when several bus or connection speeds are possible). Speed is specified in bits per second. If connection or bus speeds are not negotiated, or if this information is not available or important to device management, the property should be set to 0 (zero).


## NumberOfHardResets
***

- Data type: *uint32*
- Access type: Read-only

Number of hard resets issued by the controller.


## NumberOfSoftResets
***

- Data type: *uint32*
- Access type: Read-only

Number of soft resets issued by the controller.

</md>
'''

PRINTER = u'''<md>
# Printer
***

The *Win32_Printer* class has these properties.


## Attributes
***

- Data type: *uint32*
- Access type: Read-only

Bitmap of attributes for a Windows-based printing device.

- *PRINTER_ATTRIBUTE_QUEUED* (1 (0x1))
Queued

Print jobs are buffered and queued.
- *PRINTER_ATTRIBUTE_DIRECT* (2 (0x2))
Direct

Document to  be sent directly to the printer. This value is used if print jobs are not queued correctly.
- *PRINTER_ATTRIBUTE_DEFAULT* (4 (0x4))
Default

Default printer on a  computer.
- *PRINTER_ATTRIBUTE_SHARED* (8 (0x8))
Shared

Available as a shared network resource.
- *PRINTER_ATTRIBUTE_NETWORK* (16 (0x10))
Network

Attached to a network. If both Local and Network bits are set, this indicates a network printer.
- *PRINTER_ATTRIBUTE_HIDDEN* (32 (0x20))
Hidden

Hidden from some users on the network.
- *PRINTER_ATTRIBUTE_LOCAL* (64 (0x40))
Local

Directly connected to a  computer.
        If both Local and Network bits are set, this indicates a network printer.
- *PRINTER_ATTRIBUTE_ENABLEDEVQ* (128 (0x80))
EnableDevQ

Enable the queue on the printer if available.
- *PRINTER_ATTRIBUTE_KEEPPRINTEDJOBS* (256 (0x100))
KeepPrintedJobs

Spooler should not delete documents after they are printed.
- *PRINTER_ATTRIBUTE_DO_COMPLETE_FIRST* (512 (0x200))
DoCompleteFirst

Start jobs that are finished spooling first.
- *PRINTER_ATTRIBUTE_WORK_OFFLINE* (1024 (0x400))
WorkOffline

Queue print jobs when  a printer is not available.
- *PRINTER_ATTRIBUTE_ENABLE_BIDI* (2048 (0x800))
EnableBIDI

Enable bidirectional printing.
- *PRINTER_ATTRIBUTE_RAW_ONLY* (4096 (0x1000))
Allow only raw data type jobs to be spooled.
- *PRINTER_ATTRIBUTE_PUBLISHED* (8192 (0x2000))
Published

Published in the network directory service.

## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but is still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## AvailableJobSheets
***

- Data type: *string* array
- Access type: Read-only

Array of all  the job sheets available on a  printer. Can also be used to describe the banner that a printer might provide at the beginning of each job, or other user-specified options.


## AveragePagesPerMinute
***

- Data type: *uint32*
- Access type: Read-only

Printing rate, in average number of pages per minute,  that a  printer  can produce output.


## Capabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of printer capabilities.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Color Printing* (2)
3.    *Duplex Printing* (3)
4.    *Copies* (4)
5.    *Collation* (5)
6.    *Stapling* (6)
7.    *Transparency Printing* (7)
8.    *Punch* (8)
9.    *Cover* (9)
10.    *Bind* (10)
11.    *Black and White Printing* (11)
12.    *One Sided* (12)
One-Sided
13.    *Two Sided Long Edge* (13)
Two-Sided Long Edge
14.    *Two Sided Short Edge* (14)
Two-Sided Short Edge
15.    *Portrait* (15)
16.    *Landscape* (16)
17.    *Reverse Portrait* (17)
18.    *Reverse Landscape* (18)
19.    *Quality High* (19)
20.    *Quality Normal* (20)
21.    *Quality Low* (21)

## CapabilityDescriptions
***

- Data type: *string* array
- Access type: Read-only

Array of free-form strings that provide  detailed explanations for  the printer features indicated in the *Capabilities* array. Each  entry of this array is related to an  entry in the *Capabilities* array that is located in  the same index.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of an  objecta one-line string.


## CharSetsSupported
***

- Data type: *string* array
- Access type: Read-only

Array of available character sets for  output. Strings provided in this property must  conform to the semantics and syntax specified by section 4.1.2 ("Charset parameters") in RFC 2046 (MIME Part 2) and contained in the IANA character-set registry. Examples include, "UTF-8", "us-ASCII", and "iso-8859-1".


## Comment
***

- Data type: *string*
- Access type: Read/write

Comment for a print queue.

Example: Color printer


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have a valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used to create  an instance. When used with  other key properties of the class, the property allows all instances of this class and its subclasses to be identified uniquely.


## CurrentCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of printer capabilities that are  being used currently. An entry in this property must also be listed in the *Capabilities* array.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Color Printing* (2)
3.    *Duplex Printing* (3)
4.    *Copies* (4)
5.    *Collation* (5)
6.    *Stapling* (6)
7.    *Transparency Printing* (7)
8.    *Punch* (8)
9.    *Cover* (9)
10.    *Bind* (10)
11.    *Black and White Printing* (11)
12.    *One Sided* (12)
One-Sided
13.    *Two Sided Long Edge* (13)
Two-Sided Long Edge
14.    *Two Sided Short Edge* (14)
Two-Sided Short Edge
15.    *Portrait* (15)
16.    *Landscape* (16)
17.    *Reverse Portrait* (17)
18.    *Reverse Landscape* (18)
19.    *Quality High* (19)
20.    *Quality Normal* (20)
21.    *Quality Low* (21)

## CurrentCharSet
***

- Data type: *string*
- Access type: Read-only

The character set currently  used for output. Strings provided in this property must conform to the semantics and syntax specified by section 4.1.2 ("Charset parameters") in RFC 2046 (MIME Part 2) and contained in the IANA character-set registry. Examples include "utf-8", "us-ASCII", and iso-8859-1.


## CurrentLanguage
***

- Data type: *uint16*
- Access type: Read-only

Printer language currently  used. The language used must  be listed in the *LanguagesSupported* property.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *PCL* (3)
4.    *HPGL* (4)
5.    *PJL* (5)
6.    *PS* (6)
7.    *PSPrinter* (7)
8.    *IPDS* (8)
9.    *PPDS* (9)
10.    *EscapeP* (10)
11.    *Epson* (11)
12.    *DDIF* (12)
13.    *Interpress* (13)
14.    *ISO6429* (14)
15.    *Line Data* (15)
LineData
16.    *MODCA* (16)
DODCA
17.    *REGIS* (17)
18.    *SCS* (18)
19.    *SPDL* (19)
20.    *TEK4014* (20)
21.    *PDS* (21)
22.    *IGP* (22)
23.    *CodeV* (23)
24.    *DSCDSE* (24)
25.    *WPS* (25)
26.    *LN03* (26)
27.    *CCITT* (27)
28.    *QUIC* (28)
29.    *CPAP* (29)
30.    *DecPPL* (30)
31.    *Simple Text* (31)
SimpleText
32.    *NPAP* (32)
33.    *DOC* (33)
34.    *imPress* (34)
35.    *Pinwriter* (35)
36.    *NPDL* (36)
37.    *NEC201PL* (37)
38.    *Automatic* (38)
39.    *Pages* (39)
40.    *LIPS* (40)
41.    *TIFF* (41)
42.    *Diagnostic* (42)
43.    *CaPSL* (43)
44.    *EXCL* (44)
45.    *LCDS* (45)
46.    *XES* (46)
47.    *MIME* (47)
- 48
XPS
- 49
HPGL2
- 50
PCLXL

## CurrentMimeType
***

- Data type: *string*
- Access type: Read-only

MIME type currently  being used if the *CurrentLanguage* is a MIME type (value = 47).


## CurrentNaturalLanguage
***

- Data type: *string*
- Access type: Read-only

Language that  the printer is using for management currently. The language listed here must also be listed in the *NaturalLanguagesSupported* property.


## CurrentPaperType
***

- Data type: *string*
- Access type: Read-only

Type of paper the printer is  using. Must be expressed in the form specified by the ISO/IEC10175 Document Printing Application  (DPA), which is summarized in AppendixC of RFC1759 (PrinterMIB).


## Default
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the printer is the default printer.


## DefaultCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the printer capabilities  used by default. Each entry in the *DefaultCapabilities* array must also be listed in the *Capabilities* array.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Color Printing* (2)
3.    *Duplex Printing* (3)
4.    *Copies* (4)
5.    *Collation* (5)
6.    *Stapling* (6)
7.    *Transparency Printing* (7)
8.    *Punch* (8)
9.    *Cover* (9)
10.    *Bind* (10)
11.    *Black and White Printing* (11)
12.    *One Sided* (12)
One-Sided
13.    *Two Sided Long Edge* (13)
Two-Sided Long Edge
14.    *Two Sided Short Edge* (14)
Two-Sided Short Edge
15.    *Portrait* (15)
16.    *Landscape* (16)
17.    *Reverse Portrait* (17)
18.    *Reverse Landscape* (18)
19.    *Quality High* (19)
20.    *Quality Normal* (20)
21.    *Quality Low* (21)

## DefaultCopies
***

- Data type: *uint32*
- Access type: Read-only

Number of copies produced for one  jobunless otherwise specified.


## DefaultLanguage
***

- Data type: *uint16*
- Access type: Read-only

Default printer language. The language listed here must also be listed in the *LanguagesSupported* property.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *PCL* (3)
4.    *HPGL* (4)
5.    *PJL* (5)
6.    *PS* (6)
7.    *PSPrinter* (7)
8.    *IPDS* (8)
9.    *PPDS* (9)
10.    *EscapeP* (10)
11.    *Epson* (11)
12.    *DDIF* (12)
13.    *Interpress* (13)
14.    *ISO6429* (14)
15.    *Line Data* (15)
LineData
16.    *MODCA* (16)
DODCA
17.    *REGIS* (17)
18.    *SCS* (18)
19.    *SPDL* (19)
20.    *TEK4014* (20)
21.    *PDS* (21)
22.    *IGP* (22)
23.    *CodeV* (23)
24.    *DSCDSE* (24)
25.    *WPS* (25)
26.    *LN03* (26)
27.    *CCITT* (27)
28.    *QUIC* (28)
29.    *CPAP* (29)
30.    *DecPPL* (30)
31.    *Simple Text* (31)
SimpleText
32.    *NPAP* (32)
33.    *DOC* (33)
34.    *imPress* (34)
35.    *Pinwriter* (35)
36.    *NPDL* (36)
37.    *NEC201PL* (37)
38.    *Automatic* (38)
39.    *Pages* (39)
40.    *LIPS* (40)
41.    *TIFF* (41)
42.    *Diagnostic* (42)
43.    *CaPSL* (43)
44.    *EXCL* (44)
45.    *LCDS* (45)
46.    *XES* (46)
47.    *MIME* (47)
- 48
XPS
- 49
HPGL2
- 50
PCLXL

## DefaultMimeType
***

- Data type: *string*
- Access type: Read-only

MIME type currently being used, if the *DefaultLanguage* value is a MIME type (value = 47).


## DefaultNumberUp
***

- Data type: *uint32*
- Access type: Read-only

Number of print-stream pages that the printer renders on one  media sheetunless a job specifies otherwise.


## DefaultPaperType
***

- Data type: *string*
- Access type: Read-only

## DefaultPriority
***

- Data type: *uint32*
- Access type: Read/write

Default priority value assigned to each print job.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of an object.


## DetectedErrorState
***

- Data type: *uint16*
- Access type: Read-only

Printer error information.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *No Error* (2)
3.    *Low Paper* (3)
4.    *No Paper* (4)
5.    *Low Toner* (5)
6.    *No Toner* (6)
7.    *Door Open* (7)
8.    *Jammed* (8)
9.    *Offline* (9)
10.    *Service Requested* (10)
11.    *Output Bin Full* (11)

## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the printer  on a  system.


## Direct
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the print job is  sent directly to the printer. If *FALSE*, the print job is  spooled.


## DoCompleteFirst
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the printer starts  jobs that are finished spooling. If  *FALSE*, the printer starts jobs in the order that the jobs are  received.


## DriverName
***

- Data type: *string*
- Access type: Read/write

Name of the Windows printer driver.

Example: Windows Fax Driver


## EnableBIDI
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the printer can  print bidirectionally.


## EnableDevQueryPrint
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the printer holds documents in the queue when document and printer setups do not match.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* has been cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

Information  about the error recorded in *LastErrorCode*, and information about corrective actions  that can be taken.


## ErrorInformation
***

- Data type: *string* array
- Access type: Read/write

Array of supplemental information for the current error state indicated in *DetectedErrorState*.


## ExtendedDetectedErrorState
***

- Data type: *uint16*
- Access type: Read-only

Reports standard error information. Additional information should be recorded in *DetectedErrorState*.

Values are:

- 0 (0x0)
Unknown
- 1 (0x1)
Other
- 2 (0x2)
No Error
- 3 (0x3)
Low Paper
- 4 (0x4)
No Paper
- 5 (0x5)
Low Toner
- 6 (0x6)
No Toner
- 7 (0x7)
Door Open
- 8 (0x8)
Jammed
- 9 (0x9)
Service Requested
- 10 (0xA)
Output Bin Full
- 11 (0xB)
Paper Problem
- 12 (0xC)
Cannot Print Page
- 13 (0xD)
User Intervention Required
- 14 (0xE)
Out of Memory
- 15 (0xF)
Server Unknown

## ExtendedPrinterStatus
***

- Data type: *uint16*
- Access type: Read-only

Status information for a printer that is different from information specified in the *Availability* property.

- 1 (0x1)
Other
- 2 (0x2)
Unknown
- 3 (0x3)
Idle
- 4 (0x4)
Printing
- 5 (0x5)
Warming Up
- 6 (0x6)
Stopped Printing
- 7
Offline
- 8 (0x8)
Paused
- 9 (0x9)
Error
- 10 (0xA)
Busy
- 11 (0xB)
Not Available
- 12 (0xC)
Waiting
- 13 (0xD)
Processing
- 14 (0xE)
Initialization
- 15
Power Save
- 16 (0x10)
Pending Deletion
- 17 (0x11)
I/O Active
- 18 (0x12)
Manual Feed

## Hidden
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the printer is hidden from network users.


## HorizontalResolution
***

- Data type: *uint32*
- Access type: Read-only

Horizontal  resolution of the printerin pixels per inch.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

## JobCountSinceLastReset
***

- Data type: *uint32*
- Access type: Read-only
- Qualifiers: *Counter*

Number of print jobs since the printer was last reset.


## KeepPrintedJobs
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the print spooler does  not delete the completed jobs.


## LanguagesSupported
***

- Data type: *uint16* array
- Access type: Read-only

Array of the print languages natively supported.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *PCL* (3)
4.    *HPGL* (4)
5.    *PJL* (5)
6.    *PS* (6)
7.    *PSPrinter* (7)
8.    *IPDS* (8)
9.    *PPDS* (9)
10.    *EscapeP* (10)
11.    *Epson* (11)
12.    *DDIF* (12)
13.    *Interpress* (13)
14.    *ISO6429* (14)
15.    *Line Data* (15)
LineData
16.    *MODCA* (16)
DODCA
17.    *REGIS* (17)
18.    *SCS* (18)
19.    *SPDL* (19)
20.    *TEK4014* (20)
21.    *PDS* (21)
22.    *IGP* (22)
23.    *CodeV* (23)
24.    *DSCDSE* (24)
25.    *WPS* (25)
26.    *LN03* (26)
27.    *CCITT* (27)
28.    *QUIC* (28)
29.    *CPAP* (29)
30.    *DecPPL* (30)
31.    *Simple Text* (31)
SimpleText
32.    *NPAP* (32)
33.    *DOC* (33)
34.    *imPress* (34)
35.    *Pinwriter* (35)
36.    *NPDL* (36)
37.    *NEC201PL* (37)
38.    *Automatic* (38)
39.    *Pages* (39)
40.    *LIPS* (40)
41.    *TIFF* (41)
42.    *Diagnostic* (42)
43.    *CaPSL* (43)
44.    *EXCL* (44)
45.    *LCDS* (45)
46.    *XES* (46)
47.    *MIME* (47)
48.    *XPS* (48)
49.    *HPGL2* (49)
50.    *PCLXL* (50)

## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code that  the logical device reports.


## Local
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the printer is not attached to a network. If both the *Local* and *Network* properties are set to *TRUE*, then the printer is a network printer.


## Location
***

- Data type: *string*
- Access type: Read/write

Physical location of the printer.

Example: Bldg. 38, Room 1164


## MarkingTechnology
***

- Data type: *uint16*
- Access type: Read-only

Marking technology the printer uses.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Electrophotographic LED* (3)
4.    *Electrophotographic Laser* (4)
5.    *Electrophotographic Other* (5)
6.    *Impact Moving Head Dot Matrix 9pin* (6)
7.    *Impact Moving Head Dot Matrix 24pin* (7)
8.    *Impact Moving Head Dot Matrix Other* (8)
9.    *Impact Moving Head Fully Formed* (9)
10.    *Impact Band* (10)
11.    *Impact Other* (11)
12.    *Inkjet Aqueous* (12)
13.    *Inkjet Solid* (13)
14.    *Inkjet Other* (14)
15.    *Pen* (15)
16.    *Thermal Transfer* (16)
17.    *Thermal Sensitive* (17)
18.    *Thermal Diffusion* (18)
19.    *Thermal Other* (19)
20.    *Electroerosion* (20)
21.    *Electrostatic* (21)
22.    *Photographic Microfiche* (22)
23.    *Photographic Imagesetter* (23)
24.    *Photographic Other* (24)
25.    *Ion Deposition* (25)
26.    *eBeam* (26)
27.    *Typesetter* (27)

## MaxCopies
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of copies the printer can  produce for one  job.


## MaxNumberUp
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of print-stream pages the printer can  render on  one  media sheet, such as paper.


## MaxSizeSupported
***

- Data type: *uint32*
- Access type: Read-only

Largest job as a byte stream, in kilobytes, that the printer can  accept. A value of 0 (zero) indicates that no limit is  set.


## MimeTypesSupported
***

- Data type: *string* array
- Access type: Read-only

Array of detailed MIME-type explanations  that  the printer supports. If data is provided, then the value 47 ("MIME") must be included in the *LanguagesSupported* property.


## Name
***

- Data type: *string*
- Access type: Read-only

Name of the printer.


## NaturalLanguagesSupported
***

- Data type: *string* array
- Access type: Read-only

## Network
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the printer is a network printer. If both the *Local* and *Network* properties are set to *TRUE*, then the printer is a network printer.


## PaperSizesSupported
***

- Data type: *uint16* array
- Access type: Read-only

Array of the paper  types that the printer supports.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *A* (2)
3.    *B* (3)
4.    *C* (4)
5.    *D* (5)
6.    *E* (6)
7.    *Letter* (7)
8.    *Legal* (8)
9.    *NA-10x13-Envelope* (9)
10.    *NA-9x12-Envelope* (10)
11.    *NA-Number-10-Envelope* (11)
12.    *NA-7x9-Envelope* (12)
13.    *NA-9x11-Envelope* (13)
14.    *NA-10x14-Envelope* (14)
15.    *NA-Number-9-Envelope* (15)
16.    *NA-6x9-Envelope* (16)
17.    *NA-10x15-Envelope* (17)
18.    *A0* (18)
19.    *A1* (19)
20.    *A2* (20)
21.    *A3* (21)
22.    *A4* (22)
23.    *A5* (23)
24.    *A6* (24)
25.    *A7* (25)
26.    *A8* (26)
27.    *A9A10* (27)
28.    *B0* (28)
29.    *B1* (29)
30.    *B2* (30)
31.    *B3* (31)
32.    *B4* (32)
33.    *B5* (33)
34.    *B6* (34)
35.    *B7* (35)
36.    *B8* (36)
37.    *B9* (37)
38.    *B10* (38)
39.    *C0* (39)
40.    *C1* (40)
41.    *C2C3* (41)
C2
42.    *C4* (42)
C3
43.    *C5* (43)
C4
44.    *C6* (44)
C5
45.    *C7* (45)
C6
46.    *C8* (46)
C7
47.    *ISO-Designated* (47)
C8
48.    *JIS B0* (48)
ISO-Designated
49.    *JIS B1* (49)
JIS B0
50.    *JIS B2* (50)
JIS B1
51.    *JIS B3* (51)
JIS B2
52.    *JIS B4* (52)
JIS B3
53.    *JIS B5* (53)
JIS B4
54.    *JIS B6* (54)
JIS B5
55.    *JIS B7* (55)
JIS B6
56.    *JIS B8* (56)
JIS B7
57.    *JIS B9* (57)
JIS B8
58.    *JIS B10* (58)
JIS B9
59.    *NA-Letter* (59)
JIS B10
60.    *NA-Legal* (60)
61.    *B4-Envelope* (61)
62.    *B5-Envelope* (62)
63.    *C3-Envelope* (63)
64.    *C4-Envelope* (64)
65.    *C5-Envelope* (65)
66.    *C6-Envelope* (66)
67.    *Designated-Long-Envelope* (67)
68.    *Monarch-Envelope* (68)
69.    *Executive* (69)
70.    *Folio* (70)
71.    *Invoice* (71)
72.    *Ledger* (72)
73.    *Quarto* (73)

## PaperTypesAvailable
***

- Data type: *string* array
- Access type: Read-only
Example: iso-a4-colored


## Parameters
***

- Data type: *string*
- Access type: Read/write

Optional parameters for the print processor.

Example: "Copies=2"


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: *PNP030b


## PortName
***

- Data type: *string*
- Access type: Read/write

Port that is  used to transmit data to a printer. If a printer is connected to more than one port, the names of each port are separated by commas.

Example: LPT1:, LPT2:, LPT3:


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled, but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the power of the device can be managed, which means that it can be put into suspend mode. The property does not indicate that power management features are  enabled, only that the logical device is capable of power management.


## PrinterPaperNames
***

- Data type: *string* array
- Access type: Read-only

Array of paper sizes supported by the printer. The printer-specified names are used to represent supported paper sizes.

Example: B5 (JIS)


## PrinterState
***

- Data type: *uint32*
- Access type: Read-only

One of the possible states relating to this printer. This property is obsolete. In place of this property,  use *PrinterStatus*.

- 0
Idle - for more information, see the Remarks section below.
- 1
Paused
- 2
Error
- 3
Pending Deletion
- 4
Paper Jam
- 5
Paper Out
- 6
Manual Feed
- 7
Paper Problem
- 8
Offline
- 9
I/O Active
- 10
Busy
- 11
Printing
- 12
Output Bin Full
- 13
Not Available
- 14
Waiting
- 15
Processing
- 16
Initialization
- 17
Warming Up
- 18
Toner Low
- 19
No Toner
- 20
Page Punt
- 21
User Intervention Required
- 22
Out of Memory
- 23
Door Open
- 24
Server_Unknown
- 25
Power Save

## PrinterStatus
***

- Data type: *uint16*
- Access type: Read-only

Status information for a printer  that is different from information  specified in the logical device *Availability* property.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Idle* (3)
Idle - for more information, see the Remarks section below.
4.    *Printing* (4)
5.    *Warmup* (5)
Warming Up
6.    *Stopped Printing* (6)
7.    *Offline* (7)

## PrintJobDataType
***

- Data type: *string*
- Access type: Read/write

Data type of a print job waiting for  the Windows-based printing device.


## PrintProcessor
***

- Data type: *string*
- Access type: Read/write

Name of the print spooler that handles print jobs.

Example: SPOOLSS.DLL


## Priority
***

- Data type: *uint32*
- Access type: Read/write

Priority of the printer. Jobs on a higher priority printer are scheduled first.


## Published
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the printer is published in the network directory service.


## Queued
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the printer buffers and queues print jobs.


## RawOnly
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the printer accepts only raw data to be spooled.


## SeparatorFile
***

- Data type: *string*
- Access type: Read/write

Name of the file used to create a separator page. This page is used to separate print jobs sent to the printer.


## ServerName
***

- Data type: *string*
- Access type: Read-only

Name of the server that controls  the printer. If this string is *NULL*, the printer is controlled locally.


## Shared
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, the printer is available as a shared network resource.


## ShareName
***

- Data type: *string*
- Access type: Read/write

Share name of the Windows-based printing device.

Example: "\PRINTSERVER1\PRINTER2"


## SpoolEnabled
***

- Data type: *boolean*
- Access type: Read-only

This property is obsolete; do not use. If *TRUE*, spooling is enabled for  printer.


## StartTime
***

- Data type: *datetime*
- Access type: Read/write

Date and time that  a  printer can  start to print a jobif the printer is limited to print at specific times. This value is expressed as the time elapsed since  12:00 AM GMT (Greenwich Mean Time).


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: *OK*, *Degraded*, and *Pred Fail* (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: *Error*, *Starting*, *Stopping*, and *Service*. The latter, *Service*, could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither *OK* nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (*Not Applicable*) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time the  printer was last reset.


## UntilTime
***

- Data type: *datetime*
- Access type: Read/write

Date and time that a  printer can print the last  jobif the printer is  limited to print  at specific  times. This value is expressed as  the time elapsed since  12:00 AM GMT (Greenwich Mean Time).


## VerticalResolution
***

- Data type: *uint32*
- Access type: Read-only

Vertical resolution, in pixels-per-inch,  of the printer.


## WorkOffline
***

- Data type: *boolean*
- Access type: Read/write

If *TRUE*, you can  queue print jobs on the computer when  the printer is offline.

</md>
'''

CONTROLLER1394 = u'''<md>
# 1394  Controller
***

The *Win32_1394Controller* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but is still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of this controller.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information on any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Manufacturer of the controller.


## MaxNumberControlled
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em> parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ProtocolSupported
***

- Data type: *uint16*
- Access type: Read-only

Protocol used by the controller to access "controlled" devices.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *EISA* (3)
4.    *ISA* (4)
5.    *PCI* (5)
6.    *ATA/ATAPI* (6)
7.    *Flexible Diskette* (7)
8.    *1496* (8)
9.    *SCSI Parallel Interface* (9)
10.    *SCSI Fibre Channel Protocol* (10)
11.    *SCSI Serial Bus Protocol* (11)
12.    *SCSI Serial Bus Protocol-2 (1394)* (12)
13.    *SCSI Serial Storage Architecture* (13)
14.    *VESA* (14)
15.    *PCMCIA* (15)
16.    *Universal Serial Bus* (16)
17.    *Parallel Protocol* (17)
18.    *ESCON* (18)
19.    *Diagnostic* (19)
20.    *I2C* (20)
21.    *Power* (21)
22.    *HIPPI* (22)
23.    *MultiBus* (23)
24.    *VME* (24)
25.    *IPI* (25)
26.    *IEEE-488* (26)
27.    *RS232* (27)
28.    *IEEE 802.3 10BASE5* (28)
29.    *IEEE 802.3 10BASE2* (29)
30.    *IEEE 802.3 1BASE5* (30)
31.    *IEEE 802.3 10BROAD36* (31)
32.    *IEEE 802.3 100BASEVG* (32)
33.    *IEEE 802.5 Token-Ring* (33)
34.    *ANSI X3T9.5 FDDI* (34)
35.    *MCA* (35)
36.    *ESDI* (36)
37.    *IDE* (37)
38.    *CMD* (38)
39.    *ST506* (39)
40.    *DSSI* (40)
41.    *QIC2* (41)
42.    *Enhanced ATA/IDE* (42)
43.    *AGP* (43)
44.    *TWIRP (two-way infrared)* (44)
45.    *FIR (fast infrared)* (45)
46.    *SIR (serial infrared)* (46)
47.    *IrBus* (47)

## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value for the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time controller was last reset. This could mean the controller was powered down or reinitialized.

</md>
'''

MOTHERBOARDDEVICE = u'''<md>
# Motherboard Device
***

The *Win32_MotherboardDevice* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of this motherboard.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information about any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## PrimaryBusType
***

- Data type: *string*
- Access type: Read-only

Primary bus type of the motherboard.

Example: "PCI"


## RevisionNumber
***

- Data type: *string*
- Access type: Read-only

Revision number of the motherboard.

Example: "00"


## SecondaryBusType
***

- Data type: *string*
- Access type: Read-only

Secondary bus type of the motherboard.

Example: "ISA"


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.

</md>
'''

FAN = u'''<md>
# Fan
***

The *Win32_Fan* class has these properties.


## ActiveCooling
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the cooling device provides active (as opposed to passive) cooling.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DesiredSpeed
***

- Data type: *uint64*
- Access type: Read-only

## DeviceID
***

- Data type: *string*
- Access type: Read-only

Identifies the fan device.

## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the error reported in the *LastErrorCode* property is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

Free-form string supplying more information about the error recorded in *LastErrorCode* property, and information on any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
Power-related capacities are not supported for this device.
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## VariableSpeed
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the fan supports variable speeds.

</md>
'''

SCSICONTROLLER = u'''<md>
# SCSI Controller
***

The *Win32_SCSIController* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## ControllerTimeouts
***

- Data type: *uint32*
- Access type: Read-only

Number of time-outs that have occurred after the *TimeOfLastReset* value.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the SCSI controller with other devices on the system.


## DeviceMap
***

- Data type: *string*
- Access type: Read-only

Order in which the devices are listed with this SCSI controller.


## DriverName
***

- Data type: *string*
- Access type: Read-only

Driver file name of the SCSI controller.

Example: "Adaptec"


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

Free-form string supplying more information about the error recorded in *LastErrorCode*, and information about any corrective actions that may be taken.


## HardwareVersion
***

- Data type: *string*
- Access type: Read-only

Hardware version number of the SCSI controller.

Example: "1.25"


## Index
***

- Data type: *uint32*
- Access type: Read-only

Index number of the SCSI controller in the system registry.

Example: 0


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the SCSI controller manufacturer.

Example: "Adaptec"


## MaxDataWidth
***

- Data type: *uint32*
- Access type: Read-only

Maximum data width (in bits) supported by the SCSI controller.


## MaxNumberControlled
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.


## MaxTransferRate
***

- Data type: *uint64*
- Access type: Read-only

Maximum transfer rate (in bits per second) supported by the SCSI controller.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ProtectionManagement
***

- Data type: *uint16*
- Access type: Read-only

Support of the SCSI controller for redundancy or protection against device failures.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Unprotected* (3)
4.    *Protected* (4)
5.    *Protected through SCC (SCSI-3 Controller Command)* (5)
6.    *Protected through SCC-2 (SCSI-3 Controller Command)* (6)

## ProtocolSupported
***

- Data type: *uint16*
- Access type: Read-only

Protocol used by the controller to access "controlled" devices.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *EISA* (3)
4.    *ISA* (4)
5.    *PCI* (5)
6.    *ATA/ATAPI* (6)
7.    *Flexible Diskette* (7)
8.    *1496* (8)
9.    *SCSI Parallel Interface* (9)
10.    *SCSI Fibre Channel Protocol* (10)
11.    *SCSI Serial Bus Protocol* (11)
12.    *SCSI Serial Bus Protocol-2 (1394)* (12)
13.    *SCSI Serial Storage Architecture* (13)
14.    *VESA* (14)
15.    *PCMCIA* (15)
16.    *Universal Serial Bus* (16)
17.    *Parallel Protocol* (17)
18.    *ESCON* (18)
19.    *Diagnostic* (19)
20.    *I2C* (20)
21.    *Power* (21)
22.    *HIPPI* (22)
23.    *MultiBus* (23)
24.    *VME* (24)
25.    *IPI* (25)
26.    *IEEE-488* (26)
27.    *RS232* (27)
28.    *IEEE 802.3 10BASE5* (28)
29.    *IEEE 802.3 10BASE2* (29)
30.    *IEEE 802.3 1BASE5* (30)
31.    *IEEE 802.3 10BROAD36* (31)
32.    *IEEE 802.3 100BASEVG* (32)
33.    *IEEE 802.5 Token-Ring* (33)
34.    *ANSI X3T9.5 FDDI* (34)
35.    *MCA* (35)
36.    *ESDI* (36)
37.    *IDE* (37)
38.    *CMD* (38)
39.    *ST506* (39)
40.    *DSSI* (40)
41.    *QIC2* (41)
42.    *Enhanced ATA/IDE* (42)
43.    *AGP* (43)
44.    *TWIRP (two-way infrared)* (44)
45.    *FIR (fast infrared)* (45)
46.    *SIR (serial infrared)* (46)
47.    *IrBus* (47)

## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time this controller was last reset. This could mean the controller was powered down, or reinitialized.

</md>
'''

ONBOARDDEVICE = u'''<md>
# On Board Device
***

The *Win32_OnBoardDevice* class has these properties.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceType
***

- Data type: *uint16*
- Access type: Read-only

Type of device being represented.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Video* (3)
4.    *SCSI Controller* (4)
5.    *Ethernet* (5)
6.    *Token Ring* (6)
7.    *Sound* (7)

## Enabled
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the on-board device is available for use.


## HotSwappable
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, a physical package can be hot-swapped (if it is possible to replace the element with a physically different but equivalent one while the containing package has power applied to it). For example, a disk drive package inserted using SCA connectors is removable and can be hot-swapped. All packages that can be hot-swapped are inherently removable and replaceable.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the organization responsible for producing the physical element.


## Model
***

- Data type: *string*
- Access type: Read-only

Name by which the physical element is generally known.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## OtherIdentifyingInfo
***

- Data type: *string*
- Access type: Read-only

Additional data, beyond asset tag information, that could be used to identify a physical element. One example is bar code data associated with an element that also has an asset tag. Note that if only bar code data is available and is unique or able to be used as an element key, this property would be *NULL* and the bar code data is used as the class key in the tag property.


## PartNumber
***

- Data type: *string*
- Access type: Read-only

Part number assigned by the organization responsible for producing or manufacturing the physical element.


## PoweredOn
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the physical element is powered on.


## Removable
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, a physical package is removable (if it is designed to be taken in and out of the physical container in which it is normally found, without impairing the function of the overall packaging). A package can still be removable if power must be "off" to perform the removal. If power can be "on" and the package removed, then the element is removable and can be hot-swapped. For example, an extra battery in a laptop is removable, as is a disk drive package inserted using SCA connectors. However, the latter can be hot-swapped. A laptop's display is not removable, nor is a nonredundant power supply. Removing these components would affect the function of the overall packaging or is impossible due to the tight integration of the package.


## Replaceable
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, a physical package is replaceable (if it is possible to replace, FRU or upgrade, the element with a physically different one). For example, some computer systems allow the main processor chip to be upgraded to one of a higher clock rating. In this case, the processor is said to be replaceable. Another example is a power supply package mounted on sliding rails. All removable packages are inherently replaceable.


## SerialNumber
***

- Data type: *string*
- Access type: Read-only

Manufacturer-allocated number used to identify the physical element.


## SKU
***

- Data type: *string*
- Access type: Read-only

Stock-keeping unit number for the physical element.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## Tag
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the on-board device connected to the system.

Example: "On Board Device 1"


## Version
***

- Data type: *string*
- Access type: Read-only

Version of the physical element.

</md>
'''

DESKTOPMONITOR = u'''<md>
# Desktop Monitor
***

The *Win32_DesktopMonitor* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Bandwidth
***

- Data type: *uint32*
- Access type: Read-only

Monitor's bandwidth in megahertz. If unknown, enter 0 (zero).


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of a desktop monitor.


## DisplayType
***

- Data type: *uint16*
- Access type: Read-only

Type of desktop monitor or CRT.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Multiscan Color* (2)
3.    *Multiscan Monochrome* (3)
4.    *Fixed Frequency Color* (4)
5.    *Fixed Frequency Monochrome* (5)

## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

Free-form string supplying more information about the error recorded in *LastErrorCode*, and information on any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## IsLocked
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is locked, preventing user input or output.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## MonitorManufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the monitor manufacturer.

Example: "NEC"


## MonitorType
***

- Data type: *string*
- Access type: Read-only

Type of monitor.

Example: "NEC 5FGp"


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PixelsPerXLogicalInch
***

- Data type: *uint32*
- Access type: Read-only

Resolution along the x-axis (horizontal direction) of the monitor.


## PixelsPerYLogicalInch
***

- Data type: *uint32*
- Access type: Read-only

Resolution along the y-axis (vertical direction) of the monitor.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

0.    *Unknown* (0)
1.    *Not Supported* (1)
Power-related capacities are not supported for this device.
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState</em> parameter set to 5 (Power Cycle) and <em>Time</em> set to a specific date and time, or interval, for power-on.

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ScreenHeight
***

- Data type: *uint32*
- Access type: Read-only

Logical height of the display in screen coordinates.


## ScreenWidth
***

- Data type: *uint32*
- Access type: Read-only

Logical width of the display in screen coordinates.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational
       statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may
       be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error",
       "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk,
       reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed
       element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.

</md>
'''

CDROMDRIVE = u'''<md>
# CDROM Drive
***

The *Win32_CDROMDrive* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Capabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of capabilities of the media access device. For example, the device may support random access (3),
       removable media (7), and automatic cleaning (9).

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Sequential Access* (2)
3.    *Random Access* (3)
4.    *Supports Writing* (4)
5.    *Encryption* (5)
6.    *Compression* (6)
7.    *Supports Removeable Media* (7)
Supports Removable Media
8.    *Manual Cleaning* (8)
9.    *Automatic Cleaning* (9)
10.    *SMART Notification* (10)
11.    *Supports Dual Sided Media* (11)
Supports Dual-Sided Media
12.    *Predismount Eject Not Required* (12)

## CapabilityDescriptions
***

- Data type: *string* array
- Access type: Read-only

Array of more detailed explanations for any of the access device features indicated in the
       *Capabilities* array. Each entry of this array is related to the entry in the
       *Capabilities* array that is located at the same index.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of the objecta one-line string.


## CompressionMethod
***

- Data type: *string*
- Access type: Read-only

Algorithm or tool used by the device to support compression. If it is not possible or not desired to describe the compression scheme (perhaps because it is not known), use the following words: "Unknown" to represent that it is not known whether the device supports compression capabilities; "Compressed" to represent that the device supports compression capabilities but either its compression scheme is not known or not disclosed; and "Not Compressed" to represent that the device does not support compression capabilities.

- ** ("Unknown")
The compression scheme is unknown or not described.
- ** ("Compressed")
The logical file is compressed, but the compression scheme is unknown or not described
- ** ("Not Compressed")
If the logical file is not compressed

## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Windows Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.


## DefaultBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Default block size, in bytes, for this device.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier for a CD-ROM drive.


## Drive
***

- Data type: *string*
- Access type: Read-only

Drive letter of the CD-ROM drive.

Example: "d:"


## DriveIntegrity
***

- Data type: *boolean*
- Access type: Read-only

If *True*, files can be accurately read from the CD device. This is achieved by reading a block of data twice and comparing the data against itself.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information about  corrective actions that can be taken.


## ErrorMethodology
***

- Data type: *string*
- Access type: Read-only

Type of error detection and correction supported by this device.


## FileSystemFlags
***

- Data type: *uint16*
- Access type: Read-only

This property is obsolete. In place of this property, use *FileSystemFlagsEx*.


## FileSystemFlagsEx
***

- Data type: *uint32*
- Access type: Read-only

File system flags associated with the Windows CD-ROM drive. This parameter can be any combination of flags, but *FS_FILE_COMPRESSION* and *FS_VOL_IS_COMPRESSED* are mutually exclusive.

1.    *Case Sensitive Search* (1)
The file system supports case-sensitive file names.
2.    *Case Preserved Names* (2)
The file system preserves the case of file names when it places a name on a disk.
4.    *Unicode On Disk* (4)
The file system supports Unicode in file names as they appear on the disk.
8.    *Persistent ACLs* (8)
The file system preserves and enforces access control lists (ACLs). For example, the NTFS file system preserves and enforces ACLs and the FAT file system does not.
16.    *File Compression* (16)
The file system supports file-based compression.
32.    *Volume Quotas* (32)
The file system supports disk quotas.
64.    *Supports Sparse Files* (64)
The file system supports spare files.
128.    *Supports Reparse Points* (128)
The file system supports reparse points.
256.    *Supports Remote Storage* (256)
The file system supports the remote storage of files.
16384.    *Supports Long Names* (16384)
The file system supports file names that are longer than eight characters.
32768.    *Volume Is Compressed* (32768)
The specified disk volume is a compressed volume, for example, a DoubleSpace volume.
524289.    *Read Only Volume* (524289)
The specified volume is read-only.
65536.    *Supports Object IDS* (65536)
The file system supports object identifiers.
131072.    *Supports Encryption* (131072)
The file system supports the Encrypted File System (EFS).
262144.    *Supports Named Streams* (262144)
The file system supports named streams.
Example: 0


## Id
***

- Data type: *string*
- Access type: Read-only

Drive letter that uniquely identifies this CD-ROM drive.

Example: "d:"


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object is installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Manufacturer of the Windows CD-ROM drive.

Example: "PLEXTOR"


## MaxBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Maximum block size, in bytes, for media accessed by this device.


## MaximumComponentLength
***

- Data type: *uint32*
- Access type: Read-only

Maximum length of a filename component supported by the Windows CD-ROM drive. A file name component the portion of a file name between backslashes. The value can be used to indicate that long names are supported by the specified file system. For example, for a FAT file system supporting long names, the function stores the value 255, rather than the previous 8.3 indicator. Long names can also be supported on systems that use the NTFS file system.

Example: 255


## MaxMediaSize
***

- Data type: *uint64*
- Access type: Read-only

Maximum size, in kilobytes, of media supported by this device.


## MediaLoaded
***

- Data type: *boolean*
- Access type: Read-only

If *True*, a CD-ROM is in the drive.


## MediaType
***

- Data type: *string*
- Access type: Read-only

Type of media that can be used or accessed by this device.  Possible values are:

- *Random Access* ("Random Access")
- *Supports Writing* ("Supports Writing")
- *Removable Media* ("Removable Media")
- *CD-ROM* ("CD-ROM")

## MfrAssignedRevisionLevel
***

- Data type: *string*
- Access type: Read-only

Firmware revision level that is assigned by the manufacturer.


## MinBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Minimum block size, in bytes, for media accessed by this device.


## Name
***

- Data type: *string*
- Access type: Read-only

Label for the object. When subclassed, the property can be overridden to be a key property.


## NeedsCleaning
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the media access device needs cleaning. Whether manual or automatic cleaning is possible is indicated in the *Capabilities* property.


## NumberOfMediaSupported
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of media that can be supported or inserted, when the media access device supports multiple individual media.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
Power-related capacities are not supported for this device.
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState</em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device can be power-managed, which means that it can be put into suspend mode, and so on. The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## RevisionLevel
***

- Data type: *string*
- Access type: Read-only

Firmware revision level of the Windows CD-ROM drive.


## SCSIBus
***

- Data type: *uint32*
- Access type: Read-only

SCSI bus number for the disk drive.

Example: 0


## SCSILogicalUnit
***

- Data type: *uint16*
- Access type: Read-only

SCSI logical unit number (LUN) of the disk drive. The LUN is used to designate which SCSI controller is being accessed in a system with more than one controller being used. The SCSI device identifier is similar, but is the designation for multiple devices on one controller.

Example: 0


## SCSIPort
***

- Data type: *uint16*
- Access type: Read-only

SCSI port number of the disk drive.

Example: 1


## SCSITargetId
***

- Data type: *uint16*
- Access type: Read-only

SCSI identifier number of the Windows CD-ROM drive.

Example: 0


## SerialNumber
***

- Data type: *string*
- Access type: Read-only

Number supplied by the manufacturer that identifies the physical media.  Example: WD-WM3493798728.


## Size
***

- Data type: *uint64*
- Access type: Read-only

Size of the disk drive.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TransferRate
***

- Data type: *real64*
- Access type: Read-only

Transfer rate of the CD-ROM drive. A value of -1 indicates that the rate cannot be determined. When this happens,   the CD is not in the drive.


## VolumeName
***

- Data type: *string*
- Access type: Read-only

Volume name of the Windows CD-ROM drive.


## VolumeSerialNumber
***

- Data type: *string*
- Access type: Read-only

Volume serial number of the media in the CD-ROM drive.

Example: A8C3-D032

</md>
'''

SERIALPORT = u'''<md>
# Serial Port
***

The *Win32_SerialPort* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Binary
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the serial port is configured for binary data transfer. Because the Windows API does not support nonbinary mode transfers, this property must be *TRUE*.


## Capabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of chip-level compatibility for the serial controller. This property describes the buffering and other capabilities of the serial controller that may be inherent in the chip hardware. The property is an enumerated integer.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *XT/AT Compatible* (3)
4.    *16450 Compatible* (4)
5.    *16550 Compatible* (5)
6.    *16550A Compatible* (6)
160.    *8251 Compatible* (160)
161.    *8251FIFO Compatible* (161)

## CapabilityDescriptions
***

- Data type: *string* array
- Access type: Read-only

Array of free-form strings providing more detailed explanations for any of the serial controller features indicated in the *Capabilities* array. Note, each entry of this array is related to the entry in the *Capabilities* array that is located at the same index.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the serial port with other devices on the system.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

Free-form string supplying more information about the error recorded in *LastErrorCode*, and information about any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## MaxBaudRate
***

- Data type: *uint32*
- Access type: Read-only

Maximum baud rate (in bits per second) supported by the serial controller.


## MaximumInputBufferSize
***

- Data type: *uint32*
- Access type: Read-only

Maximum size of the serial port driver's internal input buffer. A value of 0 (zero) indicates that no maximum value is imposed by the serial provider.


## MaximumOutputBufferSize
***

- Data type: *uint32*
- Access type: Read-only

Maximum size of the serial port driver's internal output buffer. A value of 0 (zero) indicates that no maximum value is imposed by the serial provider.


## MaxNumberControlled
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## OSAutoDiscovered
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the instances of this class were automatically discovered by the operating system. If, for example, hardware was added through Control Panel, the operating system finds instances of this class by querying hardware from the instances of this class.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ProtocolSupported
***

- Data type: *uint16*
- Access type: Read-only

Protocol used by the controller to access "controlled" devices.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *EISA* (3)
4.    *ISA* (4)
5.    *PCI* (5)
6.    *ATA/ATAPI* (6)
ATA or ATAPI
7.    *Flexible Diskette* (7)
8.    *1496* (8)
9.    *SCSI Parallel Interface* (9)
10.    *SCSI Fibre Channel Protocol* (10)
11.    *SCSI Serial Bus Protocol* (11)
12.    *SCSI Serial Bus Protocol-2 (1394)* (12)
13.    *SCSI Serial Storage Architecture* (13)
14.    *VESA* (14)
15.    *PCMCIA* (15)
16.    *Universal Serial Bus* (16)
17.    *Parallel Protocol* (17)
18.    *ESCON* (18)
19.    *Diagnostic* (19)
20.    *I2C* (20)
21.    *Power* (21)
22.    *HIPPI* (22)
23.    *MultiBus* (23)
24.    *VME* (24)
25.    *IPI* (25)
26.    *IEEE-488* (26)
27.    *RS232* (27)
28.    *IEEE 802.3 10BASE5* (28)
29.    *IEEE 802.3 10BASE2* (29)
30.    *IEEE 802.3 1BASE5* (30)
31.    *IEEE 802.3 10BROAD36* (31)
32.    *IEEE 802.3 100BASEVG* (32)
33.    *IEEE 802.5 Token-Ring* (33)
34.    *ANSI X3T9.5 FDDI* (34)
35.    *MCA* (35)
36.    *ESDI* (36)
37.    *IDE* (37)
38.    *CMD* (38)
39.    *ST506* (39)
40.    *DSSI* (40)
41.    *QIC2* (41)
42.    *Enhanced ATA/IDE* (42)
43.    *AGP* (43)
44.    *TWIRP (two-way infrared)* (44)
45.    *FIR (fast infrared)* (45)
46.    *SIR (serial infrared)* (46)
47.    *IrBus* (47)

## ProviderType
***

- Data type: *string*
- Access type: Read-only

Communications provider type.

The values are:

<dd>"FAX Device"

<dd>"LAT Protocol"

<dd>"Modem Device"

<dd>"Network Bridge"

<dd>"Parallel Port"

<dd>"RS232 Serial Port"

<dd>"RS422 Port"

<dd>"RS423 Port"

<dd>"RS449 Port"

<dd>"Scanner Device"

<dd>"TCP/IP TelNet"

<dd>"X.25"

<dd>"Unspecified"

- *FAX Device* ("FAX Device")
- *LAT Protocol* ("LAT Protocol")
- *Modem Device* ("Modem Device")
- *Network Bridge* ("Network Bridge")
- *Parallel Port* ("Parallel Port")
- *RS232 Serial Port* ("RS232 Serial Port")
- *RS422 Port* ("RS422 Port")
- *RS423 Port* ("RS423 Port")
- *RS449 Port* ("RS449 Port")
- *Scanner Device* ("Scanner Device")
- *TCP/IP TelNet* ("TCP/IP TelNet")
- *X.25* ("X.25")
- *Unspecified* ("Unspecified")

## SettableBaudRate
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the baud rate can be changed for this serial port.


## SettableDataBits
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, data bits can be set for this serial port.


## SettableFlowControl
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, flow control can be set for this serial port.


## SettableParity
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, parity can be set for this serial port.


## SettableParityCheck
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, parity checking can be set for this serial port (if parity checking is supported).


## SettableRLSD
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, Received Line Signal Detect (RLSD) can be set for this serial port (if RLSD is supported).


## SettableStopBits
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, stop bits can be set for this serial port.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## Supports16BitMode
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, 16-bit mode is supported on this serial port.


## SupportsDTRDSR
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, data terminal ready (DTR) and data set ready (DSR) signals are supported on this serial port.


## SupportsElapsedTimeouts
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, elapsed time-outs are supported on this serial port. Elapsed timeouts track the total amount of time between data transmissions.


## SupportsIntTimeouts
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, interval time-outs are supported. An interval timeout is the amount of time allowed to elapse between the arrival of each piece of data.


## SupportsParityCheck
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, parity checking is supported on this serial port.


## SupportsRLSD
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, Received Line Signal Detect (RLSD) is supported on this serial port.


## SupportsRTSCTS
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, ready to send (RTS) and clear to send (CTS) signals are supported on this serial port.


## SupportsSpecialCharacters
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, serial port control characters are supported. These characters signal events rather than data. These characters are not displayable and are set by the driver. They include EofChar, ErrorChar, BreakChar, EventChar, XonChar, and XoffChar.


## SupportsXOnXOff
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, XON or XOFF flow-control is supported on this serial port.


## SupportsXOnXOffSet
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the communications provider supports configuration of the XONor XOFF flow-control setting.


## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time this controller was last reset. This could mean the controller was powered down, or reinitialized.

</md>
'''

START = u'''<md>
# Get Device Action
***


## Description
***

This action searches all devices on you computer for one of the following.

- Name
- Description
- HardwareId
- DeviceId
- DeviceID

It will return a list (tuple) of WMI instances that represent devices that can be iterated over. If no devices are found the list is empty.
These instances have different attributes (information pieces) that can be accessed. There are different attribute names for different device types so be sure to read the help for each of the various device types to find out the attribyte names for the different device types.

## Using GetDevices in a Python Script
***

    eg.plugins.System.GetDevices()

There are 2 ways to use the action. You can simply pass the text being searched for into the action.

    eg.plugins.System.GetDevices("The device Name")
This process takes some time to perform. and the more devices you have in your system the longer it takes. It will take even longer if you use any wildcards. The next example will target a specific device grouping or type. These device types can be gotten from this dialog.. They are the names of the groups of devices. You will need to remove the spaces from the name.

    eg.plugins.System.GetDevices(DiskDrives="Some Hard Drive Name")

## Wildcards
***

In order to make use of wildcarding you will need to use a python script to pass the wildcard to the action. It is strongly recommended that you also pass the device type along with what you are searching for. The combination of using wildcarding without having a device type and having alot of devices on your system is very expensive and is going to take a while to compile the data.
We are going to use "Some Device Name" as out search string in the examples below

- *? Wildcard*

The ? wildcard represents a single character in your search. "Som? Dev?ce N?me" will return the device if it finds a device called "Some Device Name"
- ** Wildcard*

The * wildcard represents multiple characters. So if you know the begining of the search string but not the end you would do "Some Dev*" and this will return all devices that have "Some Dev" in the begining. You can also put the * in the begining if you know the end. It can even be used in the middle so if the begining and the end match no matter what is in the middle it will return the device.

## Code Example
***

    for device in eg.plugins.System.GetDevice(DiskDrives="*Seagate*"):
        if device.FreeSpace < 56874956125:
            print device.Name, "Is running low in space: ", device.FreeSpace

</md>
'''

REFRIGERATION = u'''<md>
# Refrigeration
***

The *Win32_Refrigeration* class has these properties.


## ActiveCooling
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the cooling device provides active  coolingnot passive cooling.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the refrigeration device.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
Power-related capacities are not supported for this device.
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value for the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.

</md>
'''

TCPIPPRINTERPORT = u'''<md>
# TCPIP Printer Port
***

The *Win32_TCPIPPrinterPort* class has these properties.


## ByteCount
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the computer counts the bytes in a document before sending them to the printer and the printer reports back the number of bytes actually read. This capability is used for diagnostics when missing bytes are detected in the print output.


## Caption
***

- Data type: *string*
- Access type: Read-only

A short textual description of the object.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the class or  subclass used in the creation of an instance. When used with  other key properties of the class, this property allows all instances of the class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

A textual description of the object.


## HostAddress
***

- Data type: *string*
- Access type: Read-only

Address of the device or print server.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Indicates when the object was installed. Lack of a value does not indicate that the object is not
      installed.


## Name
***

- Data type: *string*
- Access type: Read-only

Uniquely identifies the service access point and provides an indication of the functionality that is managed.  This functionality is described in more detail in the object's Description property.


## PortNumber
***

- Data type: *uint32*
- Access type: Read-only

Number of the TCP ports used by the port monitor to communicate with the device.


## Protocol
***

- Data type: *uint32*
- Access type: Read-only

Printing protocol used. Some printers support only LPR.

- *1*
RAW

Printing directly to a device or print server.
- *2*
LPR

Legacy protocol, which is eventually replaced by RAW.

## Queue
***

- Data type: *string*
- Access type: Read-only

Name of the print queue on the server when used with the LPR protocol.


## SNMPCommunity
***

- Data type: *string*
- Access type: Read-only

Security level value for the device.

Example: "public'"


## SNMPDevIndex
***

- Data type: *uint32*
- Access type: Read-only

SNMP index number of this device for the SNMP agent.


## SNMPEnabled
***

- Data type: *boolean*
- Access type: Read-only

## Status
***

- Data type: *string*
- Access type: Read-only

String that indicates the current status of the object. Operational and non-operational status can be
       defined. Operational status can include "OK", "Degraded", and "Pred Fail". "Pred Fail" indicates that an
       element is functioning properly, but is predicting a failure (for example, a SMART-enabled hard disk drive).

Non-operational status can include "Error", "Starting", "Stopping", and "Service". "Service" can apply during
       disk mirror-resilvering, reloading a user permissions list, or other administrative work. Not all such work is
       online, but the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

The scoping system's creation class name.


## SystemName
***

- Data type: *string*
- Access type: Read-only

The scoping system's name.


## Type
***

- Data type: *uint32*
- Access type: Read-only

Type of SAP, such as attached or redirected.

1.    *Write* (1)
2.    *Read* (2)
4.    *Redirected* (4)
8.    *Net_Attached* (8)
16.    *unknown* (16)
</md>
'''

POINTINGDEVICE = u'''<md>
# Pointing Device
***

The *Win32_PointingDevice* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the pointing device with other devices on the system.


## DeviceInterface
***

- Data type: *uint16*
- Access type: Read-only

Type of interface used for the pointing device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Serial* (3)
4.    *PS/2* (4)
5.    *Infrared* (5)
6.    *HP-HIL* (6)
7.    *Bus mouse* (7)
8.    *ADB (Apple Desktop Bus)* (8)
160.    *Bus mouse DB-9* (160)
161.    *Bus mouse micro-DIN* (161)
162.    *USB* (162)

## DoubleSpeedThreshold
***

- Data type: *uint32*
- Access type: Read-only

One of two acceleration values. The sensitivity of the pointing device doubles (toggles from the first to the second value) when the pointing device moves a distance greater than this threshold value.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information on any corrective actions that may be taken.


## Handedness
***

- Data type: *uint16*
- Access type: Read-only

Configuration of the pointing device for left-hand or right-hand operation.

0.    *Unknown* (0)
1.    *Not Applicable* (1)
2.    *Right Handed Operation* (2)
Right-Handed Operation
3.    *Left Handed Operation* (3)
Left-Handed Operation

## HardwareType
***

- Data type: *string*
- Access type: Read-only

Type of hardware used for the Windows pointing device.

Example: "MICROSOFT PS2 MOUSE"


## InfFileName
***

- Data type: *string*
- Access type: Read-only

Name of the .inf file for the Windows pointing device.

Example: "ab.inf"


## InfSection
***

- Data type: *string*
- Access type: Read-only

Section of the .inf file that holds configuration information for the Windows pointing device.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## IsLocked
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is locked, preventing user input or output.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the processor's manufacturer.

Example: "GenuineSilicon"


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## NumberOfButtons
***

- Data type: *uint8*
- Access type: Read-only

Number of buttons on the pointing device.

Example: 2


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PointingType
***

- Data type: *uint16*
- Access type: Read-only

Type of pointing device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Mouse* (3)
4.    *Track Ball* (4)
Trackball
5.    *Track Point* (5)
6.    *Glide Point* (6)
7.    *Touch Pad* (7)
8.    *Touch Screen* (8)
9.    *Mouse - Optical Sensor* (9)

## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## QuadSpeedThreshold
***

- Data type: *uint32*
- Access type: Read-only

One of two acceleration threshold values. The system doubles the speed of the pointer movement when the pointer device moves a distance greater than this value. Because this speed increase occurs after the *DoubleSpeedThreshold* value has been met, the pointer effectively moves at four times its original speed.


## Resolution
***

- Data type: *uint32*
- Access type: Read-only

Tracking resolution.

Example: 0


## SampleRate
***

- Data type: *uint32*
- Access type: Read-only

Rate at which the pointing device is polled for input information.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## Synch
***

- Data type: *uint32*
- Access type: Read-only

Length of time after which the next interrupt is assumed to indicate the start of a new device packet (partial packets are discarded). In the event that an interrupt is lost, this allows the pointing device driver to synchronize its internal representation of the packet state with the hardware state.


## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.

</md>
'''

PARALLELPORT = u'''<md>
# Parallel Port
***

The *Win32_ParallelPort* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Capabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the capabilities of the parallel controller.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *XT/AT Compatible* (2)
3.    *PS/2 Compatible* (3)
4.    *ECP* (4)
5.    *EPP* (5)
6.    *PC-98* (6)
7.    *PC-98-Hireso* (7)
8.    *PC-H98* (8)

## CapabilityDescriptions
***

- Data type: *string* array
- Access type: Read-only

Array of more detailed explanations for any of the parallel controller features indicated in the *Capabilities* array. Each entry of this array is related to the entry in the *Capabilities* array that is located at the same index.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Identifier of the parallel port.


## DMASupport
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the parallel port supports DMA.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is  cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information about  corrective actions that might be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## MaxNumberControlled
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## OSAutoDiscovered
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the parallel port was automatically detected by the operating system. If *FALSE*, the port was detected by other means (such as being manually added through the Control Panel).


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed, which means that it can be put into suspend mode, and so on. The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ProtocolSupported
***

- Data type: *uint16*
- Access type: Read-only

Protocol used by the controller to access "controlled" devices.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *EISA* (3)
4.    *ISA* (4)
5.    *PCI* (5)
6.    *ATA/ATAPI* (6)
7.    *Flexible Diskette* (7)
8.    *1496* (8)
9.    *SCSI Parallel Interface* (9)
10.    *SCSI Fibre Channel Protocol* (10)
11.    *SCSI Serial Bus Protocol* (11)
12.    *SCSI Serial Bus Protocol-2 (1394)* (12)
13.    *SCSI Serial Storage Architecture* (13)
14.    *VESA* (14)
15.    *PCMCIA* (15)
16.    *Universal Serial Bus* (16)
17.    *Parallel Protocol* (17)
18.    *ESCON* (18)
19.    *Diagnostic* (19)
20.    *I2C* (20)
21.    *Power* (21)
22.    *HIPPI* (22)
23.    *MultiBus* (23)
24.    *VME* (24)
25.    *IPI* (25)
26.    *IEEE-488* (26)
27.    *RS232* (27)
28.    *IEEE 802.3 10BASE5* (28)
29.    *IEEE 802.3 10BASE2* (29)
30.    *IEEE 802.3 1BASE5* (30)
31.    *IEEE 802.3 10BROAD36* (31)
32.    *IEEE 802.3 100BASEVG* (32)
33.    *IEEE 802.5 Token-Ring* (33)
34.    *ANSI X3T9.5 FDDI* (34)
35.    *MCA* (35)
36.    *ESDI* (36)
37.    *IDE* (37)
38.    *CMD* (38)
39.    *ST506* (39)
40.    *DSSI* (40)
41.    *QIC2* (41)
42.    *Enhanced ATA/IDE* (42)
43.    *AGP* (43)
44.    *TWIRP (two-way infrared)* (44)
45.    *FIR (fast infrared)* (45)
46.    *SIR (serial infrared)* (46)
47.    *IrBus* (47)

## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time the controller was last reset. This could mean the controller was powered down or reinitialized.

</md>
'''

TAPEDRIVE = u'''<md>
# Tape Drive
***

The *Win32_TapeDrive* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Capabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of capabilities of the media access device. For example, the device may support Random Access, removable media and Automatic Cleaning. In this case, the values 3, 7, and 9 would be written to the array.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Sequential Access* (2)
3.    *Random Access* (3)
4.    *Supports Writing* (4)
5.    *Encryption* (5)
6.    *Compression* (6)
7.    *Supports Removeable Media* (7)
Supports Removable Media
8.    *Manual Cleaning* (8)
9.    *Automatic Cleaning* (9)
10.    *SMART Notification* (10)
11.    *Supports Dual Sided Media* (11)
Supports Dual-Sided Media
12.    *Predismount Eject Not Required* (12)

## CapabilityDescriptions
***

- Data type: *string* array
- Access type: Read-only

Array of free-form strings providing more detailed explanations for any of the access device features indicated in the *Capabilities* array. Note that each entry of this array is related to the entry in the *Capabilities* array that is located at the same index.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## Compression
***

- Data type: *uint32*
- Access type: Read-only

If *TRUE*, hardware data compression is enabled.

- *0*
FALSE
- *1*
TRUE

## CompressionMethod
***

- Data type: *string*
- Access type: Read-only

Free-form string indicating the algorithm or tool used by the device to support compression. If it is not possible or not desired to describe the compression scheme (perhaps because it is not known), use the following words: "Unknown" to represent that it is not known whether the device supports compression capabilities or not; "Compressed" to represent that the device supports compression capabilities but either its compression scheme is not known or not disclosed; and "Not Compressed" to represent that the device does not support compression capabilities.

- ** ("Unknown")
The compression scheme is unknown or not described.
- ** ("Compressed")
The logical file is compressed, but the compression scheme is unknown or not described
- ** ("Not Compressed")
If the logical file is not compressed

## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, this property allows all instances of this class and its subclasses to be uniquely identified.


## DefaultBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Default block size, in bytes, for this device.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the tape drive with other devices on the system.


## ECC
***

- Data type: *uint32*
- Access type: Read-only

If *TRUE*, the device supports hardware error correction.

0.    *False* (0)
1.    *True* (1)

## EOTWarningZoneSize
***

- Data type: *uint32*
- Access type: Read-only

Zone size for the end of tape (EOT) warning.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

Free-form string supplying more information about the error recorded in *LastErrorCode*, and information about any corrective actions that may be taken.


## ErrorMethodology
***

- Data type: *string*
- Access type: Read-only

Free-form string describing the type of error detection and correction supported by this device.


## FeaturesHigh
***

- Data type: *uint32*
- Access type: Read-only

High-order 32 bits of the device features flag.


## FeaturesLow
***

- Data type: *uint32*
- Access type: Read-only

Low-order 32 bits of the device features flag.


## Id
***

- Data type: *string*
- Access type: Read-only

Manufacturer's identifying name of the Windows CD ROM drive.

Example: "PLEXTOR CD-ROM PX-12CS 1.01"


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Manufacturer of the Windows CD-ROM drive.

Example: "PLEXTOR"


## MaxBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Maximum block size, in bytes, for media accessed by this device.


## MaxMediaSize
***

- Data type: *uint64*
- Access type: Read-only

Maximum size, in kilobytes, of media supported by this device.


## MaxPartitionCount
***

- Data type: *uint32*
- Access type: Read-only

Maximum partition count for the tape drive.


## MediaType
***

- Data type: *string*
- Access type: Read-only

Media type used by (or accessed by) this device. In this case, it is set to "Tape Drive".


## MinBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Minimum block size, in bytes, for media accessed by this device.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## NeedsCleaning
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the media access device needs cleaning. Whether manual or automatic cleaning is possible is indicated in the *Capabilities* property.


## NumberOfMediaSupported
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of individual media which can be supported or inserted in the media access device (when supported).


## Padding
***

- Data type: *uint32*
- Access type: Read-only

Number of bytes inserted between blocks on a tape media.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
Power-related capacities are not supported for this device.
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ReportSetMarks
***

- Data type: *uint32*
- Access type: Read-only

If *TRUE*, setmark reporting is enabled. Setmark reporting makes use of a specialized recorded element that does not contain user data. This recorded element is used to provide a segmentation scheme that is hierarchically superior to filemarks. Setmarks provide faster positioning on high-capacity tapes.

- *0*
FALSE
- *1*
TRUE

## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.

</md>
'''

BATTERY = u'''<md>
# Battery
***

The *Win32_Battery* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## BatteryRechargeTime
***

- Data type: *uint32*
- Access type: Read-only

Time required to fully charge the battery. This property is not supported. *BatteryRechargeTime*  does not have a replacement property, and is now considered obsolete.


## BatteryStatus
***

- Data type: *uint16*
- Access type: Read-only

Status of the battery. The value 10 (Undefined) is not valid in the CIM schema because in DMI it represents that no battery is installed. In this case, the object should not be instantiated.

1.    *Other* (1)
The battery is discharging.
2.    *Unknown* (2)
The system has access to AC so no battery is being discharged. However, the battery is not necessarily charging.
3.    *Fully Charged* (3)
4.    *Low* (4)
5.    *Critical* (5)
6.    *Charging* (6)
7.    *Charging and High* (7)
8.    *Charging and Low* (8)
9.    *Charging and Critical* (9)
10.    *Undefined* (10)
11.    *Partially Charged* (11)

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of the objecta one-line string.


## Chemistry
***

- Data type: *uint16*
- Access type: Read-only

Enumeration that describes the battery's chemistry.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Lead Acid* (3)
4.    *Nickel Cadmium* (4)
5.    *Nickel Metal Hydride* (5)
6.    *Lithium-ion* (6)
7.    *Zinc air* (7)
8.    *Lithium Polymer* (8)

## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Windows Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DesignCapacity
***

- Data type: *uint32*
- Access type: Read-only

Design capacity of the battery in milliwatt-hours. If the property is not supported, enter 0 (zero).


## DesignVoltage
***

- Data type: *uint64*
- Access type: Read-only

Design voltage of the battery in millivolts. If the attribute is not supported, enter 0 (zero).


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Identifies the battery.

Example: "Internal Battery"


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the error reported in the *LastErrorCode* property is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

Free-form string that supplies more information about the error recorded in *LastErrorCode* property, and information about any corrective actions that may be taken.


## EstimatedChargeRemaining
***

- Data type: *uint16*
- Access type: Read-only

Estimate of the percentage of full charge remaining.


## EstimatedRunTime
***

- Data type: *uint32*
- Access type: Read-only

Estimate in minutes of the time to battery charge depletion under the present load conditions if the utility power is off, or lost and remains off, or a laptop is disconnected from a power source.


## ExpectedBatteryLife
***

- Data type: *uint32*
- Access type: Read-only

Amount of time it takes to completely drain the battery after it is fully charged. This property is no longer used and is considered obsolete.


## ExpectedLife
***

- Data type: *uint32*
- Access type: Read-only

Battery's expected lifetime in minutes, assuming that the battery is fully charged. The property represents the total expected life of the battery, not its current remaining life, which is indicated by the *EstimatedRunTime* property.


## FullChargeCapacity
***

- Data type: *uint32*
- Access type: Read-only

Full charge capacity of the battery in milliwatt-hours. Comparison of the value to the *DesignCapacity* property determines when the battery requires replacement. A battery's end of life is typically when the *FullChargeCapacity* property falls below 80% of the *DesignCapacity* property. If the property is not supported, enter 0 (zero).


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## MaxRechargeTime
***

- Data type: *uint32*
- Access type: Read-only

Maximum time, in minutes, to fully charge the battery. The property represents the time to recharge a fully depleted battery, not the current remaining charge time, which is indicated in the *TimeToFullCharge* property.


## Name
***

- Data type: *string*
- Access type: Read-only

Defines the label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent <a href="https://msdn.microsoft.com/en-us/library/aa387884(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CIM_LogicalDevice*</a> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## SmartBatteryVersion
***

- Data type: *string*
- Access type: Read-only

Data Specification version number supported by the battery. If the battery does not support this function, the value should be left blank.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOnBattery
***

- Data type: *uint32*
- Access type: Read-only

Elapsed time in seconds since the computer system's UPS last switched to battery power, or the time since the system or UPS was last restarted, whichever is less. If the battery is "on line", 0 (zero) is returned.


## TimeToFullCharge
***

- Data type: *uint32*
- Access type: Read-only

Remaining time to charge the battery fully in minutes at the current charging rate and usage.

</md>
'''

PCMCIACONTROLLER = u'''<md>
# PCMCIA Controller
***

The *Win32_PCMCIAController* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
Paused.
19.    *Not Ready* (19)
Not ready.
20.    *Not Configured* (20)
Not configured.
21.    *Quiesced* (21)
Quiesced.

The PCMCIA controller is unavailable.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information on any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the PCMCIA controller manufacturer.

Example: "Acme"


## MaxNumberControlled
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ProtocolSupported
***

- Data type: *uint16*
- Access type: Read-only

Protocol used by the controller to access "controlled" devices.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *EISA* (3)
4.    *ISA* (4)
5.    *PCI* (5)
6.    *ATA/ATAPI* (6)
7.    *Flexible Diskette* (7)
8.    *1496* (8)
9.    *SCSI Parallel Interface* (9)
10.    *SCSI Fibre Channel Protocol* (10)
11.    *SCSI Serial Bus Protocol* (11)
12.    *SCSI Serial Bus Protocol-2 (1394)* (12)
13.    *SCSI Serial Storage Architecture* (13)
14.    *VESA* (14)
15.    *PCMCIA* (15)
16.    *Universal Serial Bus* (16)
17.    *Parallel Protocol* (17)
18.    *ESCON* (18)
19.    *Diagnostic* (19)
20.    *I2C* (20)
21.    *Power* (21)
22.    *HIPPI* (22)
23.    *MultiBus* (23)
24.    *VME* (24)
25.    *IPI* (25)
26.    *IEEE-488* (26)
27.    *RS232* (27)
28.    *IEEE 802.3 10BASE5* (28)
29.    *IEEE 802.3 10BASE2* (29)
30.    *IEEE 802.3 1BASE5* (30)
31.    *IEEE 802.3 10BROAD36* (31)
32.    *IEEE 802.3 100BASEVG* (32)
33.    *IEEE 802.5 Token-Ring* (33)
34.    *ANSI X3T9.5 FDDI* (34)
35.    *MCA* (35)
36.    *ESDI* (36)
37.    *IDE* (37)
38.    *CMD* (38)
39.    *ST506* (39)
40.    *DSSI* (40)
41.    *QIC2* (41)
42.    *Enhanced ATA/IDE* (42)
43.    *AGP* (43)
44.    *TWIRP (two-way infrared)* (44)
45.    *FIR (fast infrared)* (45)
46.    *SIR (serial infrared)* (46)
47.    *IrBus* (47)

## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time the controller was last reset. This could mean the controller was powered down or reinitialized.

</md>
'''

SOUNDDEVICE = u'''<md>
# Sound Device
***

The *Win32_SoundDevice* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the sound device.


## DMABufferSize
***

- Data type: *uint16*
- Access type: Read-only

Size of the Direct Memory Access buffer.

Example: 4


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

Free-form string supplying more information about the error recorded in *LastErrorCode*, and information about any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Manufacturer of the sound device.

Example: "Creative Labs"


## MPU401Address
***

- Data type: *uint32*
- Access type: Read-only

Starting I/O address assigned to the MPU-401 port of the sound device.

Example: 300


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ProductName
***

- Data type: *string*
- Access type: Read-only

Product name of the sound device.

Example: "Creative Labs SoundBlaster AWE64PNP"


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.

</md>
'''

IDECONTROLLER = u'''<md>
# IDE Controller
***

The *Win32_IDEController* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the IDE controllerwith other devices on the system.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode* property, and information about any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Manufacturer of the IDE controller device.


## MaxNumberControlled
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device ID of the logical device.

Example: *PNP030b


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managedput into suspend mode, and so on. The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ProtocolSupported
***

- Data type: *uint16*
- Access type: Read-only

Protocol used by the controller to access "controlled" devices.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *EISA* (3)
4.    *ISA* (4)
5.    *PCI* (5)
6.    *ATA/ATAPI* (6)
7.    *Flexible Diskette* (7)
8.    *1496* (8)
9.    *SCSI Parallel Interface* (9)
10.    *SCSI Fibre Channel Protocol* (10)
11.    *SCSI Serial Bus Protocol* (11)
12.    *SCSI Serial Bus Protocol-2 (1394)* (12)
13.    *SCSI Serial Storage Architecture* (13)
14.    *VESA* (14)
15.    *PCMCIA* (15)
16.    *Universal Serial Bus* (16)
17.    *Parallel Protocol* (17)
18.    *ESCON* (18)
19.    *Diagnostic* (19)
20.    *I2C* (20)
21.    *Power* (21)
22.    *HIPPI* (22)
23.    *MultiBus* (23)
24.    *VME* (24)
25.    *IPI* (25)
26.    *IEEE-488* (26)
27.    *RS232* (27)
28.    *IEEE 802.3 10BASE5* (28)
29.    *IEEE 802.3 10BASE2* (29)
30.    *IEEE 802.3 1BASE5* (30)
31.    *IEEE 802.3 10BROAD36* (31)
32.    *IEEE 802.3 100BASEVG* (32)
33.    *IEEE 802.5 Token-Ring* (33)
34.    *ANSI X3T9.5 FDDI* (34)
35.    *MCA* (35)
36.    *ESDI* (36)
37.    *IDE* (37)
38.    *CMD* (38)
39.    *ST506* (39)
40.    *DSSI* (40)
41.    *QIC2* (41)
42.    *Enhanced ATA/IDE* (42)
43.    *AGP* (43)
44.    *TWIRP (two-way infrared)* (44)
45.    *FIR (fast infrared)* (45)
46.    *SIR (serial infrared)* (46)
47.    *IrBus* (47)

## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value for the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time this controller was last reset. This could mean the controller was powered down or reinitialized.

</md>
'''

SYSTEMSLOT = u'''<md>
# System Slot
***

The *Win32_SystemSlot* class has these properties.


## BusNumber
***

- Data type: *uint32*
- Access type: Read-only

SMBIOS Bus Number.

This value comes from the *Bus Number* member of the *System Slots* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows10 and Windows Server2016 Technical Preview.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of an objecta one-line string.


## ConnectorPinout
***

- Data type: *string*
- Access type: Read-only

Free-form string that describes the pin configuration and signal usage of a physical connector.


## ConnectorType
***

- Data type: *uint16* array
- Access type: Read-only

Array of physical attributes of the connector that this slot uses.

This value comes from the *Slot Type* member of the *System Slots* structure in the SMBIOS information.


The possible values are.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Male* (2)
3.    *Female* (3)
4.    *Shielded* (4)
5.    *Unshielded* (5)
6.    *SCSI (A) High-Density (50 pins)* (6)
7.    *SCSI (A) Low-Density (50 pins)* (7)
8.    *SCSI (P) High-Density (68 pins)* (8)
9.    *SCSI SCA-I (80 pins)* (9)
10.    *SCSI SCA-II (80 pins)* (10)
11.    *SCSI Fibre Channel (DB-9, Copper)* (11)
12.    *SCSI Fibre Channel (Fibre)* (12)
13.    *SCSI Fibre Channel SCA-II (40 pins)* (13)
14.    *SCSI Fibre Channel SCA-II (20 pins)* (14)
15.    *SCSI Fibre Channel BNC* (15)
16.    *ATA 3-1/2 Inch (40 pins)* (16)
17.    *ATA 2-1/2 Inch (44 pins)* (17)
18.    *ATA-2* (18)
19.    *ATA-3* (19)
20.    *ATA/66* (20)
21.    *DB-9* (21)
22.    *DB-15* (22)
23.    *DB-25* (23)
24.    *DB-36* (24)
25.    *RS-232C* (25)
26.    *RS-422* (26)
27.    *RS-423* (27)
28.    *RS-485* (28)
29.    *RS-449* (29)
30.    *V.35* (30)
31.    *X.21* (31)
32.    *IEEE-488* (32)
33.    *AUI* (33)
34.    *UTP Category 3* (34)
35.    *UTP Category 4* (35)
36.    *UTP Category 5* (36)
37.    *BNC* (37)
38.    *RJ11* (38)
39.    *RJ45* (39)
40.    *Fiber MIC* (40)
41.    *Apple AUI* (41)
42.    *Apple GeoPort* (42)
43.    *PCI* (43)
44.    *ISA* (44)
45.    *EISA* (45)
46.    *VESA* (46)
47.    *PCMCIA* (47)
48.    *PCMCIA Type I* (48)
49.    *PCMCIA Type II* (49)
50.    *PCMCIA Type III* (50)
51.    *ZV Port* (51)
52.    *CardBus* (52)
53.    *USB* (53)
54.    *IEEE 1394* (54)
55.    *HIPPI* (55)
56.    *HSSDC (6 pins)* (56)
57.    *GBIC* (57)
58.    *DIN* (58)
59.    *Mini-DIN* (59)
60.    *Micro-DIN* (60)
61.    *PS/2* (61)
62.    *Infrared* (62)
63.    *HP-HIL* (63)
64.    *Access.bus* (64)
65.    *NuBus* (65)
66.    *Centronics* (66)
67.    *Mini-Centronics* (67)
68.    *Mini-Centronics Type-14* (68)
69.    *Mini-Centronics Type-20* (69)
70.    *Mini-Centronics Type-26* (70)
71.    *Bus Mouse* (71)
72.    *ADB* (72)
73.    *AGP* (73)
74.    *VME Bus* (74)
75.    *VME64* (75)
76.    *Proprietary* (76)
77.    *Proprietary Processor Card Slot* (77)
78.    *Proprietary Memory Card Slot* (78)
79.    *Proprietary I/O Riser Slot* (79)
80.    *PCI-66MHZ* (80)
81.    *AGP2X* (81)
82.    *AGP4X* (82)
83.    *PC-98* (83)
84.    *PC-98-Hireso* (84)
85.    *PC-H98* (85)
86.    *PC-98Note* (86)
87.    *PC-98Full* (87)
88.    *PCI-X* (88)
89.    *Sbus IEEE 1396-1993 32 bit* (89)
90.    *Sbus IEEE 1396-1993 64 bit* (90)
91.    *MCA* (91)
92.    *GIO* (92)
93.    *XIO* (93)
94.    *HIO* (94)
95.    *NGIO* (95)
96.    *PMC* (96)
97.    *Future I/O* (97)
98.    *InfiniBand* (98)
99.    *AGP8X* (99)
100.    *PCI-E* (100)

## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of a class, this property allows all instances of this class and its subclasses to be  identified uniquely.


## CurrentUsage
***

- Data type: *uint16*
- Access type: Read-only

Status of system slot use.

This value comes from the *Current Usage* member of the *System Slots* structure in the SMBIOS information.


The possible values are.

0.    *Reserved* (0)
1.    *Other* (1)
2.    *Unknown* (2)
3.    *Available* (3)
4.    *In use* (4)

## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceNumber
***

- Data type: *uint32*
- Access type: Read-only

SMBIOS Device Number.

This value comes from the *Device/Function Number* member of the *System Slots* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows10 and Windows Server2016 Technical Preview.


## FunctionNumber
***

- Data type: *uint32*
- Access type: Read-only

SMBIOS Function Number.

This value comes from the *Device/Function Number* member of the *System Slots* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows10 and Windows Server2016 Technical Preview.


## HeightAllowed
***

- Data type: *real32*
- Access type: Read-only

Maximum height of an adapter card that can be inserted into the slotin inches.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object is installed. This property does not need a value to indicate that the object is installed.


## LengthAllowed
***

- Data type: *real32*
- Access type: Read-only

Maximum length of an adapter card that can be inserted into the slotin inches.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the organization that produces the physical element.


## MaxDataWidth
***

- Data type: *uint16*
- Access type: Read-only

Maximum bus width of adapter cards that can be inserted into this slotin bits.  This can be one of the following values.

This value comes from the *Slot Data Bus Width* member of the *System Slots* structure in the SMBIOS information.


The possible values are.

0.    *8* (0)
Maximum data width (bits): 8
1.    *16* (1)
Maximum data width (bits): 16
2.    *32* (2)
Maximum data width (bits): 32
3.    *64* (3)
Maximum data width (bits): 64
4.    *128* (4)
Maximum data width (bits): 128

## Model
***

- Data type: *string*
- Access type: Read-only

Name for the physical element.


## Name
***

- Data type: *string*
- Access type: Read-only

Label for the object. When subclassed, this property can be overridden to be a key property.


## Number
***

- Data type: *uint16*
- Access type: Read-only

Physical slot number that can be used as an index into a system slot table, whether or not that slot is physically empty.

This value comes from the *Slot ID* member of the *System Slots* structure in the SMBIOS information.


## OtherIdentifyingInfo
***

- Data type: *string*
- Access type: Read-only

Additional data (that is, more than the asset tag information), that can be used to identify a physical element. One example is bar code data associated with an element that also has an asset tag. Note that if only bar code data is available, and it is unique or can be used as an element key, this property is *NULL*, and the bar code data is used as the class key in the *Tag* property.


## PartNumber
***

- Data type: *string*
- Access type: Read-only

Part number that the producer or manufacturer assigns to the physical element.


## PMESignal
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the PCI bus Power Management Enabled (PME) signal is supported by this slot.

This value comes from the *Slot Characteristics 2* member of the *System Slots* structure in the SMBIOS information.


## PoweredOn
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the physical element is powered on.


## PurposeDescription
***

- Data type: *string*
- Access type: Read-only

Free-form string that describes how this slot is physically unique and may hold special types of hardware. This property only has meaning when the corresponding property *SpecialPurpose* is *TRUE*.


## SegmentGroupNumber
***

- Data type: *uint32*
- Access type: Read-only

SMBIOS Segment Group Number.

This value comes from the *Segment Group Number* member of the *System Slots* structure in the SMBIOS information.

*Windows Server2012R2, Windows8.1, Windows Server2012, Windows8, Windows Server2008R2, Windows7, Windows Server2008, and WindowsVista:*This property is not supported before Windows10 and Windows Server2016 Technical Preview.


## SerialNumber
***

- Data type: *string*
- Access type: Read-only

Manufacturer-allocated number used to identify the physical element.


## Shared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, two or more slots share a location on the baseboard, such as a PCI/EISA shared slot.

This value comes from the *Slot Characteristics 1* member of the *System Slots* structure in the SMBIOS information.


## SKU
***

- Data type: *string*
- Access type: Read-only

Stockkeeping unit number for the physical element.


## SlotDesignation
***

- Data type: *string*
- Access type: Read-only

SMBIOS string that identifies the system slot designation of the slot on the motherboard.

Example: "PCI-1"

This value comes from the *Slot Designation* member of the *System Slots* structure in the SMBIOS information.


## SpecialPurpose
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, this slot is physically unique and may hold special types of hardware, such as a graphics processor slot. If *TRUE*, then *PurposeDescription* should specify the nature of the uniqueness or purpose of the slot.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


The possible values are.

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## SupportsHotPlug
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the slot supports hot-plugging of adapter cards.

This value comes from the *Slot Characteristics 2* member of the *System Slots* structure in the SMBIOS information.


## Tag
***

- Data type: *string*
- Access type: Read-only

System slot represented by an instance of this class.

Example: "System Slot 1"


## ThermalRating
***

- Data type: *uint32*
- Access type: Read-only

Maximum thermal dissipation of the slot in milliwatts.


## VccMixedVoltageSupport
***

- Data type: *uint16* array
- Access type: Read-only

Array of enumerated integers indicating the Vcc voltage supported by this slot.

This value comes from the *Slot Characteristics 1* member of the *System Slots* structure in the SMBIOS information.


The possible values are.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *3.3V* (2)
3.    *5V* (3)

## Version
***

- Data type: *string*
- Access type: Read-only

Version of the physical element.


## VppMixedVoltageSupport
***

- Data type: *uint16* array
- Access type: Read-only

Array of enumerated integers indicating the Vpp voltage supported by this slot.


The possible values are.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *3.3V* (2)
3.    *5V* (3)
4.    *12V* (4)
</md>
'''

FLOPPYDRIVE = u'''<md>
# Floppy Drive
***

The *Win32_FloppyDrive* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
Power Save - Unknown

The device in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
Power Save - Low Power Mode

The device is in a power save state, but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
Power Save - Standby

The device is not functioning, but can be quickly restored to full-power.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
Power Save - Warning

The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Capabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of capabilities of the media access device. For example, the device may support Random Access, Removable Media, and Automatic Cleaning. In this case, the values 3, 7, and 9 would be written to the array.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Sequential Access* (2)
3.    *Random Access* (3)
4.    *Supports Writing* (4)
5.    *Encryption* (5)
6.    *Compression* (6)
7.    *Supports Removeable Media* (7)
Supports Removable Media
8.    *Manual Cleaning* (8)
9.    *Automatic Cleaning* (9)
10.    *SMART Notification* (10)
11.    *Supports Dual Sided Media* (11)
Supports Dual-Sided Media
12.    *Predismount Eject Not Required* (12)

## CapabilityDescriptions
***

- Data type: *string* array
- Access type: Read-only

Array of free-form strings providing more detailed explanations for any of the serial controller features indicated in the *Capabilities* array. Note, each entry of this array is related to the entry in the *Capabilities* array that is located at the same index.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## CompressionMethod
***

- Data type: *string*
- Access type: Read-only

Free form string indicating the algorithm or tool used by the device to support compression. If it is not possible or not desired to describe the compression scheme (perhaps because it is not known), use  "Unknown" to represent that it is not known whether the device supports compression capabilities or not; "Compressed" to represent that the device supports compression capabilities, but either its compression scheme is not known or not disclosed; and "Not Compressed" to represent that the device does not support compression capabilities.

- ** ("Unknown")
The compression scheme is unknown or not described.
- ** ("Compressed")
The logical file is compressed, but the compression scheme is unknown or not described
- ** ("Not Compressed")
If the logical file is not compressed

## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Windows Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## DefaultBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Default block size, in bytes, for this device.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the floppy disk drive with other devices on the system.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

Free-form string that supplies more information about the error recorded in *LastErrorCode*, and information on any corrective actions that may be taken.


## ErrorMethodology
***

- Data type: *string*
- Access type: Read-only

Free-form string that describes the type of error detection and correction supported by this device.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the manufacturer of the floppy disk drive.

Example: "Acme"


## MaxBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Maximum block size, in bytes, for media accessed by this device.


## MaxMediaSize
***

- Data type: *uint64*
- Access type: Read-only

Maximum size, in kilobytes, of media supported by this device.


## MinBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Minimum block size, in bytes, for media accessed by this device.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## NeedsCleaning
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the media access device requires cleaning. Whether manual or automatic cleaning is possible is indicated in the *Capabilities* property.


## NumberOfMediaSupported
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of individual media which can be supported or inserted in the media access device (when supported).


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
Enabled

The power management features are currently enabled, but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
Power Saving Modes Entered Automatically

The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
Power State Settable
6.    *Power Cycling Supported* (6)
Power Cycling Supported
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational
       statuses include: "OK", "Degraded", and "Pred Fail" (an
       element, such as a SMART-enabled hard disk drive, may be functioning properly, but predicting a failure in the
       near future). Nonoperational statuses include: "Error", "Starting",
       "Stopping", and "Service". The latter, "Service", could
       apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not
       all such work is online, yet the managed element is neither "OK" nor in one of the other
       states.


The values are:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5
       ("Not Applicable") should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer *CreationClassName* property. This property is

## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.

</md>
'''

NETWORKADAPTER = u'''<md>
# Network Adapter
***

The *Win32_NetworkAdapter* class has these properties.


## AdapterType
***

- Data type: *string*
- Access type: Read-only

Network medium in use.
     The network adapters are as follows:

- *Ethernet 802.3* ("Ethernet 802.3")
- *Token Ring 802.5* ("Token Ring 802.5")
- *Fiber Distributed Data Interface (FDDI)* ("Fiber Distributed Data Interface (FDDI)")
- *Wide Area Network (WAN)* ("Wide Area Network (WAN)")
- *LocalTalk* ("LocalTalk")
- *Ethernet using DIX header format* ("Ethernet using DIX header format")
- *ARCNET* ("ARCNET")
- *ARCNET (878.2)* ("ARCNET (878.2)")
- *ATM* ("ATM")
- *Wireless* ("Wireless")
- *Infrared Wireless* ("Infrared Wireless")
- *Bpc* ("Bpc")
- *CoWan* ("CoWan")
- *1394* ("1394")

## AdapterTypeID
***

- Data type: *uint16*
- Access type: Read-only

Network medium in use. Returns the same information as the *AdapterType* property, except that the information is in the form of an integer.

0.    *Ethernet 802.3* (0)
1.    *Token Ring 802.5* (1)
2.    *Fiber Distributed Data Interface (FDDI)* (2)
3.    *Wide Area Network (WAN)* (3)
4.    *LocalTalk* (4)
5.    *Ethernet using DIX header format* (5)
6.    *ARCNET* (6)
7.    *ARCNET (878.2)* (7)
8.    *ATM* (8)
9.    *Wireless* (9)
10.    *Infrared Wireless* (10)
11.    *Bpc* (11)
12.    *CoWan* (12)
13.    *1394* (13)

## AutoSense
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the network adapter can automatically determine the speed of the attached or network media.

This property has not been implemented yet. It returns a *NULL* value by default.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save state, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state, but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save state.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Windows Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the network adapter from other devices on the system.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information about any corrective actions that may be taken.


## GUID
***

- Data type: *string*
- Access type: Read-only

Globally unique identifier for the connection.


## Index
***

- Data type: *uint32*
- Access type: Read-only

Index number of the network adapter, stored in the system registry.

Example: 0


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.

This property has not been implemented yet. It returns a *NULL* value by default.


## Installed
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the network adapter is installed in the system.


## InterfaceIndex
***

- Data type: *uint32*
- Access type: Read-only

## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## MACAddress
***

- Data type: *string*
- Access type: Read-only

Media access control address for this network adapter. A MAC address is a unique 48-bit number assigned to the network adapter by the manufacturer. It uniquely identifies this network adapter and is used for mapping TCP/IP network communications.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the network adapter's manufacturer.

Example: "3COM"


## MaxNumberControlled
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of directly addressable ports supported by this network adapter. A value of 0 (zero) should be used if the number is unknown.


## MaxSpeed
***

- Data type: *uint64*
- Access type: Read-only

Maximum speed, in bits per second, for the network adapter.

This property has not been implemented yet. It returns a *NULL* value by default.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## NetConnectionID
***

- Data type: *string*
- Access type: Read/write

Name of the network connection as it appears in the *Network Connections* Control Panel program.


## NetConnectionStatus
***

- Data type: *uint16*
- Access type: Read-only

State of the network adapter connection to the network.

0.    *Disconnected* (0)
1.    *Connecting* (1)
2.    *Connected* (2)
3.    *Disconnecting* (3)
4.    *Hardware Not Present* (4)
5.    *Hardware Disabled* (5)
6.    *Hardware Malfunction* (6)
7.    *Media Disconnected* (7)
8.    *Authenticating* (8)
9.    *Authentication Succeeded* (9)
10.    *Authentication Failed* (10)
11.    *Invalid Address* (11)
12.    *Credentials Required* (12)
- *Other*
<dd>1365535


## NetEnabled
***

- Data type: *boolean*
- Access type: Read-only

## NetworkAddresses
***

- Data type: *string* array
- Access type: Read-only

Array of network addresses for an adapter.

This property has not been implemented yet. It returns a *NULL* value by default.


## PermanentAddress
***

- Data type: *string*
- Access type: Read-only

Network address hard-coded into an adapter. This hard-coded address may be changed by firmware upgrade or software configuration. If so, this field should be updated when the change is made. The property should be left blank if no hard-coded address exists for the network adapter.

This property has not been implemented yet. It returns a *NULL* value by default.


## PhysicalAdapter
***

- Data type: *boolean*
- Access type: Read-only

Indicates whether the adapter is a physical or a logical adapter. If *True*, the adapter is physical.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent <a href="https://msdn.microsoft.com/en-us/library/aa387884(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CIM_LogicalDevice*</a> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ProductName
***

- Data type: *string*
- Access type: Read-only

Product name of the network adapter.

Example: "Fast EtherLink XL"


## ServiceName
***

- Data type: *string*
- Access type: Read-only

Service name of the network adapter. This name is usually shorter than the full product name.

Example: "Elnkii"


## Speed
***

- Data type: *uint64*
- Access type: Read-only

Estimate of the current bandwidth in bits per second. For endpoints which vary in bandwidth or for those where no accurate estimation can be made, this property should contain the nominal bandwidth.


## Status
***

- Data type: *string*
- Access type: Read-only

Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time the network adapter was last reset.

</md>
'''

FLOPPYCONTROLLER = u'''<md>
# Floppy Controller
***

The *Win32_FloppyController* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
Power Save - Unknown

The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
Power Save - Low Power Mode

The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
Power Save - Standby

The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
Power Save - Warning

The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description  of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the
        device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is
        removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance.
       When used with the other key properties of the class, the property allows all instances of this class and its
       subclasses to be  identified uniquely.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the floppy controller.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is
       now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information
       about any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object is installed. This property does not need a value to indicate that the object is
       installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the floppy controller manufacturer.

Example: "Microsoft"


## MaxNumberControlled
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of directly addressable entities that this controller supports. A value of 0 (zero) should be
       used if the number is unknown.


## Name
***

- Data type: *string*
- Access type: Read-only

Label for the object. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier for the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information
         is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The
         method is supported. This method is found on the parent *CIM_LogicalDevice*
         class and can be implemented. For more information, see

6.    *Power Cycling Supported* (6)
The
         method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
The
         method can be invoked with the <em>PowerState</em> parameter set to 5 (Power Cycle) and
         <em>Time</em> set to a specific date and time, or interval, for power-on.

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed, which means that it can be put into
       suspend mode, and so on. The property does not indicate that power management features are currently enabled,
       only that the logical device is capable of power management.


## ProtocolSupported
***

- Data type: *uint16*
- Access type: Read-only

Protocol used by the controller to access "controlled" devices.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *EISA* (3)
4.    *ISA* (4)
5.    *PCI* (5)
6.    *ATA/ATAPI* (6)
7.    *Flexible Diskette* (7)
8.    *1496* (8)
9.    *SCSI Parallel Interface* (9)
10.    *SCSI Fibre Channel Protocol* (10)
11.    *SCSI Serial Bus Protocol* (11)
12.    *SCSI Serial Bus Protocol-2 (1394)* (12)
13.    *SCSI Serial Storage Architecture* (13)
14.    *VESA* (14)
15.    *PCMCIA* (15)
16.    *Universal Serial Bus* (16)
17.    *Parallel Protocol* (17)
18.    *ESCON* (18)
19.    *Diagnostic* (19)
20.    *I2C* (20)
21.    *Power* (21)
22.    *HIPPI* (22)
23.    *MultiBus* (23)
24.    *VME* (24)
25.    *IPI* (25)
26.    *IEEE-488* (26)
27.    *RS232* (27)
28.    *IEEE 802.3 10BASE5* (28)
29.    *IEEE 802.3 10BASE2* (29)
30.    *IEEE 802.3 1BASE5* (30)
31.    *IEEE 802.3 10BROAD36* (31)
32.    *IEEE 802.3 100BASEVG* (32)
33.    *IEEE 802.5 Token-Ring* (33)
34.    *ANSI X3T9.5 FDDI* (34)
35.    *MCA* (35)
36.    *ESDI* (36)
37.    *IDE* (37)
38.    *CMD* (38)
39.    *ST506* (39)
40.    *DSSI* (40)
41.    *QIC2* (41)
42.    *Enhanced ATA/IDE* (42)
43.    *AGP* (43)
44.    *TWIRP (two-way infrared)* (44)
45.    *FIR (fast infrared)* (45)
46.    *SIR (serial infrared)* (46)
47.    *IrBus* (47)

## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational
       statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may
       be functioning properly but predicting a failure in the near future). Nonoperational statuses include:
       "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of
       a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the
       managed element is neither "OK" nor in one of the other states.


The values are:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5
       (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time the controller was last reset. This could mean the controller was powered down or
       reinitialized.

</md>
'''

PHYSICALMEDIA = u'''<md>
# Physical Media
***

The *Win32_PhysicalMedia* class has these properties.


## Capacity
***

- Data type: *uint64*
- Access type: Read-only

Number of bytes that can be read from or written to this physical media component. This property does not apply to "Hard Copy" or cleaner media. Data compression should not be assumed as it would increase the value of this property. For tapes, it should be assumed that no filemarks or blank space areas are recorded on the media.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short, one-line textual description of the object.


## CleanerMedia
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the physical media is used for cleaning purposes and not data storage.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the class or subclass used in the creation of an instance. When used with other key properties of this class, *CreationClassName* allows all instances of this class and its subclasses to be uniquely identified.


## Description
***

- Data type: *string*
- Access type: Read-only

Textual description of the object.


## HotSwappable
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, this physical media component can be replaced with a physically different but equivalent one while the containing package has the power applied. For example, a fan component may be designed to be hot-swapped. All components that can be hot-swapped are inherently removable and replaceable.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

When the object was installed. This property does not require a value to indicate that the object is installed.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the organization responsible for producing the physical element. This can be the entity from whom the element is purchased, but this is not necessarily the case as this information is contained in the *Vendor* property.


## MediaDescription
***

- Data type: *string*
- Access type: Read-only

Additional detail related to the *MediaType* property. For example, if *MediaType* has the value 3 (QIC Cartridge) the *MediaDescription* property can indicate whether the tape is wide or quarter inch.


## MediaType
***

- Data type: *uint16*
- Access type: Read-only

The type of the media, as an enumerated integer. The *MediaDescription* property provides a more explicit definition of the media type.


The following list lists the possible values.

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Tape Cartridge* (2)
3.    *QIC Cartridge* (3)
4.    *AIT Cartridge* (4)
5.    *DTF Cartridge* (5)
6.    *DAT Cartridge* (6)
7.    *8mm Tape Cartridge* (7)
8.    *19mm Tape Cartridge* (8)
9.    *DLT Cartridge* (9)
10.    *Half-Inch Magnetic Tape Cartridge* (10)
11.    *Cartridge Disk* (11)
12.    *JAZ Disk* (12)
13.    *ZIP Disk* (13)
14.    *SyQuest Disk* (14)
15.    *Winchester Removable Disk* (15)
16.    *CD-ROM* (16)
CD ROM
17.    *CD-ROM/XA* (17)
CD ROM/XA
18.    *CD-I* (18)
19.    *CD Recordable* (19)
20.    *WORM* (20)
21.    *Magneto-Optical* (21)
22.    *DVD* (22)
23.    *DVD+RW* (23)
24.    *DVD-RAM* (24)
25.    *DVD-ROM* (25)
26.    *DVD-Video* (26)
27.    *Divx* (27)
28.    *Floppy/Diskette* (28)
29.    *Hard Disk* (29)
30.    *Memory Card* (30)
31.    *Hard Copy* (31)
32.    *Clik Disk* (32)
33.    *CD-RW* (33)
34.    *CD-DA* (34)
35.    *CD+* (35)
36.    *DVD Recordable* (36)
37.    *DVD-RW* (37)
38.    *DVD-Audio* (38)
39.    *DVD-5* (39)
40.    *DVD-9* (40)
41.    *DVD-10* (41)
42.    *DVD-18* (42)
43.    *Magneto-Optical Rewriteable* (43)
44.    *Magneto-Optical Write Once* (44)
45.    *Magneto-Optical Rewriteable (LIMDOW)* (45)
46.    *Phase Change Write Once* (46)
47.    *Phase Change Rewriteable* (47)
48.    *Phase Change Dual Rewriteable* (48)
49.    *Ablative Write Once* (49)
50.    *Near Field Recording* (50)
51.    *MiniQic* (51)
52.    *Travan* (52)
53.    *8mm Metal Particle* (53)
54.    *8mm Advanced Metal Evaporate* (54)
55.    *NCTP* (55)
56.    *LTO Ultrium* (56)
57.    *LTO Accelis* (57)
58.    *9 Track Tape* (58)
59.    *18 Track Tape* (59)
60.    *36 Track Tape* (60)
61.    *Magstar 3590* (61)
62.    *Magstar MP* (62)
63.    *D2 Tape* (63)
64.    *Tape - DST Small* (64)
65.    *Tape - DST Medium* (65)
66.    *Tape - DST Large* (66)

## Model
***

- Data type: *string*
- Access type: Read-only

Name by which the physical element is generally known.


## Name
***

- Data type: *string*
- Access type: Read-only

## OtherIdentifyingInfo
***

- Data type: *string*
- Access type: Read-only

Additional data, beyond asset tag information, that can be used to identify a physical element. One example is bar code data associated with an element that also has an asset tag. Note that if only bar code data is available, is unique, and  it can be used as an element key, this property is *NULL* and the bar code data used is the class key in the *Tag* property.


## PartNumber
***

- Data type: *string*
- Access type: Read-only

Part number assigned by the manufacturer of the physical element.


## PoweredOn
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE* the physical element is powered on.


## Removable
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the physical component is designed to be taken in and out of the physical container in which it is normally found, without impairing the function of the overall packaging. A component can still be removable if the power must be "off" to perform the removal. If power can be "on" and the component removed, the element is removable and can be hot-swapped.


## Replaceable
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, this physical media component can be replaced  with a physically different one. For example, some computer systems allow the main processor chip to be upgraded to one of a higher clock rating. In this case, the processor is said to be replaceable. All removable components are inherently replaceable.


## SerialNumber
***

- Data type: *string*
- Access type: Read-only

Manufacturer-allocated number used to identify the physical media. The default value is *NULL*.

Example: WD-WM3493798728


## SKU
***

- Data type: *string*
- Access type: Read-only

Stock keeping unit number for this physical element.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses are "OK", "Degraded", and "Pred Fail". "Pred Fail" indicates that an element may  function properly at the present, but predicts a failure in the near future. For example, a SMART-enabled hard disk drive. Nonoperational statuses can also be specified.  These are, "Error", "Starting", "Stopping," and "Service". The "Service" status applies to administrative work, such as mirror-resilvering of a disk or reload of a user permissions list. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


The values are:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## Tag
***

- Data type: *string*
- Access type: Read-only

Uniquely identifies the physical media in the system.

Example: PHYSICALDRIVE0


## Version
***

- Data type: *string*
- Access type: Read-only

Version of the physical element.


## WriteProtectOn
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the media is currently write protected by some kind of physical mechanism, such as a protect tab on a floppy disk.

<h2>Requirements</h2>
<table summary="table">
<tr><th scope="row">
Minimum supported client

</th><td>
WindowsVista

</td></tr>
<tr><th scope="row">
Minimum supported server

</th><td>
Windows Server2008

</td></tr>
<tr><th scope="row">
Namespace

</th><td>
Root\CIMV2

</td></tr>
<tr><th scope="row">
MOF

</th><td>
- Wmipcima.mof
</td></tr>
<tr><th scope="row">
DLL

</th><td>
- Wmipcima.dll
</td></tr>
</table>
<h2>See also</h2>
-
-
</div>
</div>
<div class="libraryMemberFilter">
    <div class="filterContainer">
        <span>Show:</span>
        <label>
            <input type="checkbox" class="libraryFilterInherited" checked="checked" value="Inherit" />Inherited
        </label>
        <label>
            <input type="checkbox" class="libraryFilterProtected" checked="checked" value="Protected" />Protected
        </label>
    </div>
</div>
<input type="hidden" id="libraryMemberFilterEmptyWarning" value="There are no members available with your current filter settings." />
    </div>
<div id="rightNavigationMenu" ms.cmpgrp="right nav">
    <div id="mobileButtons">
        <div id="navigationButtons">
            <a id="isd_printABook" href="/en-us/library/export/help/?returnurl=%2fen-us%2flibrary%2faa394346(v%3dvs.85).aspx">
                <ins class="export"></ins>Export (<span class="count">0</span>)
            </a>
        </div>
    </div>
    <div id="navMain">
        <div id="closeNavigation">
            <a class="tocCloseSmall" id="closeButton"></a>
        </div>
        <div id="navigationButtons">
            <a id="isd_printABook2" href="/en-us/library/export/help/?returnurl=%2fen-us%2flibrary%2faa394346(v%3dvs.85).aspx">
                <ins class="export"></ins>Export (<span class="count">0</span>)
            </a>
            <a id="isdShare" href="#" role="button" aria-expanded="false">
                <ins class="share"></ins>Share
            </a>
            <div id="socials" style="display: none">
                <a class="isdFacebook" href="#" aria-label="Share on Facebook">
                    <ins class="facebook"></ins>
                </a>
                <a class="isdTwitter" href="#" aria-label="Share on Twitter">
                    <ins class="twitter"></ins>
                </a>
                <a class="isdGooglePlus" href="#" aria-label="Share on Google+">
                    <ins class="googlePlus"></ins>
                </a>
            </div>
        </div>
        <div id="indoc_toc" style="display: none" ms.cmpgrp="indoc toc">
            <div id="indoc_title">IN THIS ARTICLE</div>
            <ul id="indoc_toclist"></ul>
        </div>
    </div>
</div>
<div id="rightNavigationMenuThumbnail" class="rightNavigationMenuThumbnail">
</div>
        </div>
        <div class="clear"></div>
<input name="__RequestVerificationToken" type="hidden" value="OFDdh5ALYS93z4atXgokQ1VQ6fiot-qWXbTbw5W6PqaaWuRm7uQM57_lly8Rtsn6M_Uv6306P_69VPcVhoo_w0GfJW01" />
<input id="ratingValueSubmitUrl" type="hidden" value="https://msdn.microsoft.com/en-us/library/feedback/rate/aa394346(v=vs.85).aspx" />
<input id="ratingAdditionalSubmitUrl" type="hidden" value="https://msdn.microsoft.com/en-us/library/feedback/additional/aa394346(v=vs.85).aspx" />
<input id="isTopicRated" type="hidden" value="false" />
    <div id="lib-footer">
    <link type="text/css" rel="stylesheet" />
    <div id="ux-footer" class="" style="" dir="ltr" ms.pgarea="footer">
    <div id="standardRatingBefore" class="clear stdr-container-before"></div>
    <div id="standardRating" class="stdr-container" ms.pgarea="body">
        <div class="stdr-close"></div>
        <div class="stdr-vote stdr-content">
            <div class="stdr-content">
                <span class="stdr-votetitle">Is this page helpful?</span>
                <button class="stdr-yes" aria-label="Yes, this page was helpful">Yes</button>
                <button class="stdr-no" aria-label="No, this page was not helpful">No</button>
                <input id="s_ratingValue" type="hidden" value="" />
            </div>
        </div>
        <div class="stdr-feedback" style="display: none">
            <div class="stdr-form">
                <div class="stdr-fieldtitle">Additional feedback?</div>
                <textarea class="stdr-detail" rows="6" maxlength="1500"></textarea>
                <div>
                    <span class="stdr-count"><span class="stdr-charcnt">1500</span> characters remaining</span>
                    <div class="stdr-buttons">
                        <button class="stdr-provide" aria-label="Submit my additional feedback">Submit</button>
                        <button class="stdr-skip" aria-label="Skip additional feedback">Skip this</button>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="stdr-thanks" style="display: none">
            <div class="stdr-content">
                <span class="stdr-thankyou">Thank you!</span>
                <span class="stdr-appreciate">We appreciate your feedback.</span>
            </div>
        </div>
        <div id="contentFeedbackQAContainer" style="display: none;"></div>
    </div>
    <div id="standardRatingPlaceholder" style="display: none"></div>
        <footer class="top" role="navigation" aria-label="footer">
            <div data-fragmentName="LeftLinks" id="Fragment_LeftLinks" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <h4 class="linkListTitle">Dev centers</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            <div id="rightLinks">
                <div data-fragmentName="CenterLinks1" id="Fragment_CenterLinks1" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <h4 class="linkListTitle">Learning resources</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks2" id="Fragment_CenterLinks2" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <h4 class="linkListTitle">Community</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks3" id="Fragment_CenterLinks3" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <h4 class="linkListTitle">Support</h4>
    <ul class="links">
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks4" id="Fragment_CenterLinks4" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <h4 class="linkListTitle">Programs</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            </div>
        </footer>
        <footer class="bottom" role="contentinfo">
            <span class="localeContainer">
    <form class="selectLocale" id="selectLocaleForm" action="https://msdn.microsoft.com/en-us/selectlocale-dmc">
        <input type="hidden" name="fromPage" value="https%3a%2f%2fmsdn.microsoft.com%2fen-us%2flibrary%2faa394346(v%3dvs.85).aspx" />
    </form>
            </span>
            <div data-fragmentName="BottomLinks" id="Fragment_BottomLinks" xmlns="http://www.w3.org/1999/xhtml">
  <div class="linkList">
    <ul class="links horizontal">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            <span class="logoLegal">
                <span class="logoSpan clip67x13" role="img" tabindex="0" aria-label="microsoft logo">
                    <img alt="logo" class="logo" src="https://i-msdn.sec.s-msft.com/Areas/Centers/Themes/StandardDevCenter/Content/HeaderFooterSprite.png?v=636221982560760644" />
                </span>
                <span class="copyright"> 2017 Microsoft</span>
            </span>
        </footer>
    </div>
    </div>
        <div class="footerPrintView">
            <div class="footerCopyrightPrintView"> 2017 Microsoft</div>
        </div>
    <input id="tocPaddingPerLevel" type="hidden" value="17" />
        <input id="MtpsDevice" type="hidden" value="Default" />
<![CDATA[ Third party scripts and code linked to or referenced from this website are licensed to you by the parties that own such code, not by Microsoft.  See ASP.NET Ajax CDN Terms of Use  http://www.asp.net/ajaxlibrary/CDN.ashx. ]]>
<![CDATA[ WebTrends view model not available or IncludeLegacyWebTrendsScriptInGlobal feature flag is off]]>
<div id="globalRequestVerification">
    <input name="__RequestVerificationToken" type="hidden" value="lGq3MlE2SC4hiDXe4FDv-1RYKUfZQBYtED6Q9_lrG2oEM9ZFAWF4OdPkNK-3ho1WWcgK1uksrhfjseJRQZBee_2rPnU1" />
</div>
    </div>
<script type="text/javascript" class="mtps-injected">
/*<![CDATA[*/
(function(window,document){"use strict";function preload(scripts){for(var result=[],script,e,i=0;i<scripts.length;i++)script=scripts[i],script.hasOwnProperty("url")&&(e=document.createElement("script"),e.src=script.url,script.throwaway=e),result.push(script);return result}function inject(scripts,index){var script,elem;if(index>=scripts.length){delete mtps.injectScripts;return}script=scripts[index];elem=document.createElement("script");elem.className="mtps-injected";elem.async=!1;var isLoaded=!1,timeoutId=0,injectNextFnName="",injectNext=elem.onerror=function(){isLoaded||(isLoaded=!0,inject(scripts,index+1),window.clearTimeout(timeoutId),elem.onload=elem.onerror=elem.onreadystatechange=null,injectNextFnName&&delete mtps[injectNextFnName],elem.removeEventListener&&elem.removeEventListener("load",injectNext,!1))};elem.addEventListener?elem.addEventListener("load",injectNext,!1):elem.readyState==="uninitialized"?elem.onreadystatechange=function(){(this.readyState==="loaded"||this.readyState==="complete")&&injectNext()}:elem.onload=injectNext;script.hasOwnProperty("url")?(timeoutId=window.setTimeout(injectNext,12e4),elem.src=script.url):(injectNextFnName="_injectNextScript_"+index,mtps[injectNextFnName]=injectNext,timeoutId=window.setTimeout(injectNext,2e3),elem.text="try {
"+script.txt+"
} finally { MTPS."+injectNextFnName+" && MTPS."+injectNextFnName+"(); }");parent.appendChild(elem)}var mtps=window.MTPS||(window.MTPS={}),parent=document.getElementsByTagName("head")[0];mtps.injectScripts=function(scripts){inject(preload(scripts),0)}})(window,document);
MTPS.injectScripts([
{ txt: "/**/
(window.MTPS || (window.MTPS = {})).cdnDomains || (window.MTPS.cdnDomains = {
"image": "https://i-msdn.sec.s-msft.com",
"js": "https://i2-msdn.sec.s-msft.com",
"css": "https://i-msdn.sec.s-msft.com",
"ttf": "https://i-msdn.sec.s-msft.com"
});
/**/" },
{ txt: "//
        window.appInsightsId = '5eb1b2eb-c47a-497a-a7ac-a1c230b2882f';
        //" },
{ url: "https://i2-msdn.sec.s-msft.com/Combined.js?resources=0:Utilities,1:Layout,2:Header,3:Breadcrumbs,4:LibraryRightNavigationMenu,4:PrintExportButton,5:StandardRating,2:Footer,0:Topic,3:ResponsiveSupport,0:AppInsightsPerf,3:ResponsiveToc,0:ABTestControl,4:WEDCS,3:CmpgrpForHeader,1:SearchBox;/Areas/Epx/Content/Scripts:0,/Areas/Epx/Themes/Base/Content:1,/Areas/Centers/Themes/StandardDevCenter/Content:2,/Areas/Library/Content:3,/Areas/Library/Themes/Base/Content:4,/Areas/Global/Content:5&amp;hashKey=380CB181B38C487101990C8F514C8659&amp;v=F314B163E8B6FD251181E3EA43E44BD3" },
{ url: "https://i1.services.social.microsoft.com/search/Widgets/SearchBox.jss?boxid=HeaderSearchTextBox&btnid=HeaderSearchButton&minimumTermLength=2&pgArea=header&brand=Msdn&loc=en-us&focusOnInit=false&emptyWatermark=true&searchButtonTooltip=Search MSDN" },
{ url: "https://i2-msdn.sec.s-msft.com/Combined.js?resources=0:JumpRedirect,1:LibraryMemberFilter,2:Toc_Fixed,2:CodeSnippet,2:TopicNotInScope,2:VersionSelector,2:SurveyBroker;/Areas/Epx/Themes/Base/Content:0,/Areas/Library/Content:1,/Areas/Epx/Content/Scripts:2&amp;hashKey=8B88EB517137869CDE8F8A6DFD775854&amp;v=F314B163E8B6FD251181E3EA43E44BD3" },
{ txt: "$(document).ready(function() {
        try {
            var token = $("#globalRequestVerification input[name='__RequestVerificationToken']").clone();
            $("#siteFeedbackForm").append(token);
        } catch(err) {
        }
    });" }
]);
/*]]>*/
</script></body>
</md>
'''

DISKDRIVE = u'''<md>
# Disk Drive
***

The *Win32_DiskDrive* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
19.    *Not Ready* (19)
20.    *Not Configured* (20)
21.    *Quiesced* (21)
The disk drive is unavailable.

## BytesPerSector
***

- Data type: *uint32*
- Access type: Read-only

Number of bytes in each sector for the physical disk drive.

Example: 512


## Capabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of capabilities of the media access device. For example, the device may support random access (3), removable media (7), and automatic cleaning (9).

0.    *Unknown* (0)
1.    *Other* (1)
2.    *Sequential Access* (2)
3.    *Random Access* (3)
4.    *Supports Writing* (4)
5.    *Encryption* (5)
6.    *Compression* (6)
7.    *Supports Removeable Media* (7)
Supports Removable Media
8.    *Manual Cleaning* (8)
9.    *Automatic Cleaning* (9)
10.    *SMART Notification* (10)
11.    *Supports Dual Sided Media* (11)
Supports Dual-Sided Media
12.    *Predismount Eject Not Required* (12)
Ejection Prior to Drive Dismount Not Required

## CapabilityDescriptions
***

- Data type: *string* array
- Access type: Read-only

List of more detailed explanations for any of the access device features indicated in the *Capabilities* array. Note, each entry of this array is related to the entry in the *Capabilities* array that is located at the same index.


## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the object.


## CompressionMethod
***

- Data type: *string*
- Access type: Read-only

The name of the compression algorithm or one of the following values.

- ** ("Unknown")
Whether the device supports compression capabilities or not is not known.
- ** ("Compressed")
The device supports compression capabilities but its compression scheme is not known or not disclosed.
- ** ("Not Compressed")
The device does not support compression.

## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Windows Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.


## DefaultBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Default block size, in bytes, for this device.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the disk drive with other devices on the system.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information on any corrective actions that may be taken.


## ErrorMethodology
***

- Data type: *string*
- Access type: Read-only

Type of error detection and correction supported by this device.


## FirmwareRevision
***

- Data type: *string*
- Access type: Read-only

Revision for the disk drive firmware that is assigned by the manufacturer.


## Index
***

- Data type: *uint32*
- Access type: Read-only
       control code. A value of 0xffffffff indicates that the given drive does not map to a physical drive.

Example: 1


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## InterfaceType
***

- Data type: *string*
- Access type: Read-only

Interface type of physical disk drive.


The values are:

<p class="indent">SCSI

<p class="indent">HDC

<p class="indent">IDE

<p class="indent">USB

<p class="indent">1394


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Name of the disk drive manufacturer.

Example: "Seagate"


## MaxBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Maximum block size, in bytes, for media accessed by this device.


## MaxMediaSize
***

- Data type: *uint64*
- Access type: Read-only

Maximum media size, in kilobytes, of media supported by this device.


## MediaLoaded
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the media for a disk drive is loaded, which means that the device has a readable file system and is accessible. For fixed disk drives, this property will always be *TRUE*.


## MediaType
***

- Data type: *string*
- Access type: Read-only

Type of media used or accessed by this device.


Possible values are:

- *External hard disk media*
- *Removable media* ("Removable media other than floppy")
- *Fixed hard disk* ("Fixed hard disk media")
- *Unknown* ("Format is unknown")

## MinBlockSize
***

- Data type: *uint64*
- Access type: Read-only

Minimum block size, in bytes, for media accessed by this device.


## Model
***

- Data type: *string*
- Access type: Read-only

Manufacturer's model number of the disk drive.

Example: "ST32171W"


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## NeedsCleaning
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the media access device needs cleaning. Whether manual or automatic cleaning is possible is indicated in the *Capabilities* property.


## NumberOfMediaSupported
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of media which can be supported or inserted (when the media access device supports multiple individual media).


## Partitions
***

- Data type: *uint32*
- Access type: Read-only

Number of partitions on this physical disk drive that are recognized by the operating system.

Example: 2


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
Power-related capacities are not supported for this device.
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent <a href="https://msdn.microsoft.com/en-us/library/aa387884(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CIM_LogicalDevice*</a> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *True*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## SCSIBus
***

- Data type: *uint32*
- Access type: Read-only

SCSI bus number of the disk drive.

Example: 0


## SCSILogicalUnit
***

- Data type: *uint16*
- Access type: Read-only

SCSI logical unit number (LUN) of the disk drive.

Example: 0


## SCSIPort
***

- Data type: *uint16*
- Access type: Read-only

SCSI port number of the disk drive.

Example: 0


## SCSITargetId
***

- Data type: *uint16*
- Access type: Read-only

SCSI identifier number of the disk drive.

Example: 0


## SectorsPerTrack
***

- Data type: *uint32*
- Access type: Read-only

Number of sectors in each track for this physical disk drive.

Example: 63


## SerialNumber
***

- Data type: *string*
- Access type: Read-only

Number allocated by the manufacturer to identify the physical media.

Example: WD-WM3493798728


## Signature
***

- Data type: *uint32*
- Access type: Read-only

Disk identification. This property can be used to identify a shared resource.


## Size
***

- Data type: *uint64*
- Access type: Read-only

Size of the disk drive. It is calculated by multiplying the total number of cylinders, tracks in each cylinder, sectors in each track, and bytes in each sector.


## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational
       statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may
       be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error",
       "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk,
       reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed
       element is neither "OK" nor in one of the other states.


Values are:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value of the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TotalCylinders
***

- Data type: *uint64*
- Access type: Read-only

Total number of cylinders on the physical disk drive. Note: the value for this property is obtained through extended functions of BIOS interrupt 13h. The value may be inaccurate if the drive uses a translation scheme to support high-capacity disk sizes. Consult the manufacturer for accurate drive specifications.

Example: 657


## TotalHeads
***

- Data type: *uint32*
- Access type: Read-only

Total number of heads on the disk drive. Note: the value for this property is obtained through extended functions of BIOS interrupt 13h. The value may be inaccurate if the drive uses a translation scheme to support high-capacity disk sizes. Consult the manufacturer for accurate drive specifications.


## TotalSectors
***

- Data type: *uint64*
- Access type: Read-only

Total number of sectors on the physical disk drive. Note: the value for this property is obtained through extended functions of BIOS interrupt 13h. The value may be inaccurate if the drive uses a translation scheme to support high-capacity disk sizes. Consult the manufacturer for accurate drive specifications.

Example: 2649024


## TotalTracks
***

- Data type: *uint64*
- Access type: Read-only

Total number of tracks on the physical disk drive. Note: the value for this property is obtained through extended functions of BIOS interrupt 13h. The value may be inaccurate if the drive uses a translation scheme to support high-capacity disk sizes. Consult the manufacturer for accurate drive specifications.

Example: 42048


## TracksPerCylinder
***

- Data type: *uint32*
- Access type: Read-only

Number of tracks in each cylinder on the physical disk drive. Note: the value for this property is obtained through extended functions of BIOS interrupt 13h. The value may be inaccurate if the drive uses a translation scheme to support high-capacity disk sizes. Consult the manufacturer for accurate drive specifications.

Example: 64

</md>
'''

INFRAREDDEVICE = u'''<md>
# Infrared Device
***

The *Win32_InfraredDevice* class has these properties.


## Availability
***

- Data type: *uint16*
- Access type: Read-only

Availability and status of the device.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Running/Full Power* (3)
Running or Full Power
4.    *Warning* (4)
5.    *In Test* (5)
6.    *Not Applicable* (6)
7.    *Power Off* (7)
8.    *Off Line* (8)
9.    *Off Duty* (9)
10.    *Degraded* (10)
11.    *Not Installed* (11)
12.    *Install Error* (12)
13.    *Power Save - Unknown* (13)
The device is known to be in a power save mode, but its exact status is unknown.
14.    *Power Save - Low Power Mode* (14)
The device is in a power save state but still functioning, and may exhibit degraded performance.
15.    *Power Save - Standby* (15)
The device is not functioning, but could be brought to full power quickly.
16.    *Power Cycle* (16)
17.    *Power Save - Warning* (17)
The device is in a warning state, though also in a power save mode.
18.    *Paused* (18)
The device is paused.
19.    *Not Ready* (19)
The device is not ready.
20.    *Not Configured* (20)
The device is not configured.
21.    *Quiesced* (21)
The device is quiet.

## Caption
***

- Data type: *string*
- Access type: Read-only

Short description of the objecta one-line string.


## ConfigManagerErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Win32 Configuration Manager error code.

0.    *This device is working properly.* (0)
Device is working properly.
1.    *This device is not configured correctly.* (1)
Device is not configured correctly.
2.    *Windows cannot load the driver for this device.* (2)
3.    *The driver for this device might be corrupted, or your system may be running low on memory or other resources.* (3)
Driver for this device might be corrupted, or the  system may be  low on memory or other resources.
4.    *This device is not working properly. One of its drivers or your registry might be corrupted.* (4)
Device is not working properly. One of its drivers or the  registry might be corrupted.
5.    *The driver for this device needs a resource that Windows cannot manage.* (5)
Driver for the device requires a resource that Windows cannot manage.
6.    *The boot configuration for this device conflicts with other devices.* (6)
Boot configuration for the device conflicts with other devices.
7.    *Cannot filter.* (7)
8.    *The driver loader for the device is missing.* (8)
Driver loader for the device is missing.
9.    *This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.* (9)
Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.
10.    *This device cannot start.* (10)
Device cannot start.
11.    *This device failed.* (11)
Device failed.
12.    *This device cannot find enough free resources that it can use.* (12)
Device cannot find enough free resources to use.
13.    *Windows cannot verify this device's resources.* (13)
Windows cannot verify the device's resources.
14.    *This device cannot work properly until you restart your computer.* (14)
Device cannot work properly until the computer is restarted.
15.    *This device is not working properly because there is probably a re-enumeration problem.* (15)
Device is not working properly due to a possible re-enumeration problem.
16.    *Windows cannot identify all the resources this device uses.* (16)
Windows cannot identify all of the resources that the device uses.
17.    *This device is asking for an unknown resource type.* (17)
Device is requesting  an unknown resource type.
18.    *Reinstall the drivers for this device.* (18)
Device drivers must be reinstalled.
19.    *Failure using the VxD loader.* (19)
20.    *Your registry might be corrupted.* (20)
Registry might be corrupted.
21.    *System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.* (21)
System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.
22.    *This device is disabled.* (22)
Device is disabled.
23.    *System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.* (23)
System failure. If changing the device driver is ineffective, see the hardware documentation.
24.    *This device is not present, is not working properly, or does not have all its drivers installed.* (24)
Device is not present,  not working properly, or does not have all of its drivers installed.
25.    *Windows is still setting up this device.* (25)
Windows is still setting up the device.
26.    *Windows is still setting up this device.* (26)
Windows is still setting up the device.
27.    *This device does not have valid log configuration.* (27)
Device does not have valid log configuration.
28.    *The drivers for this device are not installed.* (28)
Device drivers   are not installed.
29.    *This device is disabled because the firmware of the device did not give it the required resources.* (29)
Device is disabled.  The device firmware   did not provide  the required resources.
30.    *This device is using an Interrupt Request (IRQ) resource that another device is using.* (30)
Device is using an IRQ resource that another device is using.
31.    *This device is not working properly because Windows cannot load the drivers required for this device.* (31)
Device is not working properly.  Windows cannot load the  required device drivers.

## ConfigManagerUserConfig
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device is using a user-defined configuration.


## CreationClassName
***

- Data type: *string*
- Access type: Read-only

Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.


## Description
***

- Data type: *string*
- Access type: Read-only

Description of the object.


## DeviceID
***

- Data type: *string*
- Access type: Read-only

Unique identifier of the infrared device.


## ErrorCleared
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the error reported in *LastErrorCode* is now cleared.


## ErrorDescription
***

- Data type: *string*
- Access type: Read-only

More information about the error recorded in *LastErrorCode*, and information about any corrective actions that may be taken.


## InstallDate
***

- Data type: *datetime*
- Access type: Read-only

Date and time the object was installed. This property does not need a value to indicate that the object is installed.


## LastErrorCode
***

- Data type: *uint32*
- Access type: Read-only

Last error code reported by the logical device.


## Manufacturer
***

- Data type: *string*
- Access type: Read-only

Manufacturer of the device.


## MaxNumberControlled
***

- Data type: *uint32*
- Access type: Read-only

Maximum number of directly addressable entities supportable by this device. A value of 0 (zero) should be used if the number is unknown.


## Name
***

- Data type: *string*
- Access type: Read-only

Label by which the object is known. When subclassed, the property can be overridden to be a key property.


## PNPDeviceID
***

- Data type: *string*
- Access type: Read-only

Windows Plug and Play device identifier of the logical device.

Example: "*PNP030b"


## PowerManagementCapabilities
***

- Data type: *uint16* array
- Access type: Read-only

Array of the specific power-related capabilities of a logical device.

This property is inherited from
       *CIM_LogicalDevice*.

0.    *Unknown* (0)
1.    *Not Supported* (1)
2.    *Disabled* (2)
3.    *Enabled* (3)
The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.
4.    *Power Saving Modes Entered Automatically* (4)
The device can change its power state based on usage or other criteria.
5.    *Power State Settable* (5)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method is supported. This method is found on the parent *CIM_LogicalDevice* class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.
6.    *Power Cycling Supported* (6)
The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState*</a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).
7.    *Timed Power On Supported* (7)
Timed Power-On Supported

## PowerManagementSupported
***

- Data type: *boolean*
- Access type: Read-only

If *TRUE*, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.


## ProtocolSupported
***

- Data type: *uint16*
- Access type: Read-only

Protocol used by the controller to access "controlled" devices.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *EISA* (3)
4.    *ISA* (4)
5.    *PCI* (5)
6.    *ATA/ATAPI* (6)
7.    *Flexible Diskette* (7)
8.    *1496* (8)
9.    *SCSI Parallel Interface* (9)
10.    *SCSI Fibre Channel Protocol* (10)
11.    *SCSI Serial Bus Protocol* (11)
12.    *SCSI Serial Bus Protocol-2 (1394)* (12)
13.    *SCSI Serial Storage Architecture* (13)
14.    *VESA* (14)
15.    *PCMCIA* (15)
16.    *Universal Serial Bus* (16)
17.    *Parallel Protocol* (17)
18.    *ESCON* (18)
19.    *Diagnostic* (19)
20.    *I2C* (20)
21.    *Power* (21)
22.    *HIPPI* (22)
23.    *MultiBus* (23)
24.    *VME* (24)
25.    *IPI* (25)
26.    *IEEE-488* (26)
27.    *RS232* (27)
28.    *IEEE 802.3 10BASE5* (28)
29.    *IEEE 802.3 10BASE2* (29)
30.    *IEEE 802.3 1BASE5* (30)
31.    *IEEE 802.3 10BROAD36* (31)
32.    *IEEE 802.3 100BASEVG* (32)
33.    *IEEE 802.5 Token-Ring* (33)
34.    *ANSI X3T9.5 FDDI* (34)
35.    *MCA* (35)
36.    *ESDI* (36)
37.    *IDE* (37)
38.    *CMD* (38)
39.    *ST506* (39)
40.    *DSSI* (40)
41.    *QIC2* (41)
42.    *Enhanced ATA/IDE* (42)
43.    *AGP* (43)
44.    *TWIRP (two-way infrared)* (44)
45.    *FIR (fast infrared)* (45)
46.    *SIR (serial infrared)* (46)
47.    *IrBus* (47)

## Status
***

- Data type: *string*
- Access type: Read-only

Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.


Values include the following:

- *OK* ("OK")
- *Error* ("Error")
- *Degraded* ("Degraded")
- *Unknown* ("Unknown")
- *Pred Fail* ("Pred Fail")
- *Starting* ("Starting")
- *Stopping* ("Stopping")
- *Service* ("Service")
- *Stressed* ("Stressed")
- *NonRecover* ("NonRecover")
- *No Contact* ("No Contact")
- *Lost Comm* ("Lost Comm")

## StatusInfo
***

- Data type: *uint16*
- Access type: Read-only

State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.

1.    *Other* (1)
2.    *Unknown* (2)
3.    *Enabled* (3)
4.    *Disabled* (4)
5.    *Not Applicable* (5)

## SystemCreationClassName
***

- Data type: *string*
- Access type: Read-only

Value for the scoping computer's *CreationClassName* property.


## SystemName
***

- Data type: *string*
- Access type: Read-only

Name of the scoping system.


## TimeOfLastReset
***

- Data type: *datetime*
- Access type: Read-only

Date and time the controller was last reset. This could mean the controller was powered down, or reinitialized.

</md>
'''

