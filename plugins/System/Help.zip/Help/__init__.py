# -*- coding: utf-8 -*-
#
# This file is part of EventGhost.
# Copyright © 2005-2016 EventGhost Project <http://www.eventghost.org/>
#
# EventGhost is free software: you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 2 of the License, or (at your option)
# any later version.
#
# EventGhost is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along
# with EventGhost. If not, see <http://www.gnu.org/licenses/>.

START = u'''
<!DOCTYPE html>

<title>Get Device Action</title>
<h3>Get Device Action</h3>

<dt><strong>Description</strong></dt>
<dd>
<dl class="indent">
<dt><p>This action searches all devices on you computer for one of the following.</p></dt>
<dl class="indent">
<dt><strong>Name</strong></dt>
<dt><strong>Description</strong></dt>
<dt><strong>HardwareId</strong></dt>
<dt><strong>DeviceId</strong></dt>
<dt><strong>DeviceID</strong></dt>
</dl></dl>
<dl class="indent">
<dl class="indent">
<dt><p>It will return a list (tuple) of WMI instances that represent devices that can be iterated over. If no devices are found the list is empty.</p></dt>
<dt><p>These instances have different attributes (information pieces) that can be accessed. There are different attribute names for different device types so be sure to read the help for each of the various device types to find out the attribyte names for the different device types.</p></dt>
</dl>
</dl></dd>

<dt><strong>Using GetDevices in a Python Script</strong></dt>
<dd>
<dl class="indent">
<dt><strong>eg.plugins.System.GetDevices()</strong></dt>
<dl class="indent">
<dt><p>There are 2 ways to use the action. You can simply pass the text being searched for into the action.</p></dt>
<dt><p>eg.plugins.System.GetDevices("The device Name")</p></dt>
<dt><p>This process takes some time to perform. and the more devices you have in your system the longer it takes. It will take even longer if you use any wildcards. The next example will target a specific device grouping or type. These device types can be gotten from this dialog.. They are the names of the groups of devices. You will need to remove the spaces from the name.</p></dt>
<dt><p>eg.plugins.System.GetDevices(DiskDrives="Some Hard Drive Name")</p></dt>
</dl>
</dl></dd>

<dt><strong>Wildcards</strong></dt>
<dd>
<dl class="indent">
<dl class="indent">
<dt><p>In order to make use of wildcarding you will need to use a python script to pass the wildcard to the action. It is strongly recommended that you also pass the device type along with what you are searching for. The combination of using wildcarding without having a device type and having alot of devices on your system is very expensive and is going to take a while to compile the data.</p></dt>
<dt><p>We are going to use "Some Device Name" as out search string in the examples below</p></dt>
<dt><p><strong>? Wildcard</strong></p></dt>
<dl class="indent">
<dt><p>The ? wildcard represents a single character in your search. "Som? Dev?ce N?me" will return the device if it finds a device called "Some Device Name" </p></dt>
</dl>
<dt><p><strong>* Wildcard</strong></p></dt>
<dl class="indent">
<dt><p>The * wildcard represents multiple characters. So if you know the begining of the search string but not the end you would do "Some Dev*" and this will return all devices that have "Some Dev" in the begining. You can also put the * in the begining if you know the end. It can even be used in the middle so if the begining and the end match no matter what is in the middle it will return the device.</p></dt>
</dl>
</dl></dl></dd>

<dt><strong>Code Example</strong></dt>
<dd>
<dl class="indent">
<dt><p>for device in eg.plugins.System.GetDevice(DiskDrives="*Seagate*"):</p></dt>
<dl class="indent">
<dl class="indent">
<dt><p>if device.FreeSpace < 56874956125:</p></dt>
<dl class="indent">
<dt><p>print device.Name, "Is runnung low in space: ", device.FreeSpace</p></dt>
</dl></dl></dl>
</dl></dd>

</html>
'''
# https://msdn.microsoft.com/en-us/library/aa394059(v=vs.85).aspx
CONTROLLER1394 = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394059(v=vs.85).aspx" />
    <title>Win32_1394Controller class (Windows)</title>
<h3>1394  Controller</h3>
<p>The <strong>Win32_1394Controller</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but is still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of this controller.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information on any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer of the controller.</p>
</dd>
<dt><strong>MaxNumberControlled</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em> parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProtocolSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Protocol used by the controller to access "controlled" devices.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>EISA</strong> (3)</p></dt>
<dt><p><strong>ISA</strong> (4)</p></dt>
<dt><p><strong>PCI</strong> (5)</p></dt>
<dt><p><strong>ATA/ATAPI</strong> (6)</p></dt>
<dt><p><strong>Flexible Diskette</strong> (7)</p></dt>
<dt><p><strong>1496</strong> (8)</p></dt>
<dt><p><strong>SCSI Parallel Interface</strong> (9)</p></dt>
<dt><p><strong>SCSI Fibre Channel Protocol</strong> (10)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol</strong> (11)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol-2 (1394)</strong> (12)</p></dt>
<dt><p><strong>SCSI Serial Storage Architecture</strong> (13)</p></dt>
<dt><p><strong>VESA</strong> (14)</p></dt>
<dt><p><strong>PCMCIA</strong> (15)</p></dt>
<dt><p><strong>Universal Serial Bus</strong> (16)</p></dt>
<dt><p><strong>Parallel Protocol</strong> (17)</p></dt>
<dt><p><strong>ESCON</strong> (18)</p></dt>
<dt><p><strong>Diagnostic</strong> (19)</p></dt>
<dt><p><strong>I2C</strong> (20)</p></dt>
<dt><p><strong>Power</strong> (21)</p></dt>
<dt><p><strong>HIPPI</strong> (22)</p></dt>
<dt><p><strong>MultiBus</strong> (23)</p></dt>
<dt><p><strong>VME</strong> (24)</p></dt>
<dt><p><strong>IPI</strong> (25)</p></dt>
<dt><p><strong>IEEE-488</strong> (26)</p></dt>
<dt><p><strong>RS232</strong> (27)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE5</strong> (28)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE2</strong> (29)</p></dt>
<dt><p><strong>IEEE 802.3 1BASE5</strong> (30)</p></dt>
<dt><p><strong>IEEE 802.3 10BROAD36</strong> (31)</p></dt>
<dt><p><strong>IEEE 802.3 100BASEVG</strong> (32)</p></dt>
<dt><p><strong>IEEE 802.5 Token-Ring</strong> (33)</p></dt>
<dt><p><strong>ANSI X3T9.5 FDDI</strong> (34)</p></dt>
<dt><p><strong>MCA</strong> (35)</p></dt>
<dt><p><strong>ESDI</strong> (36)</p></dt>
<dt><p><strong>IDE</strong> (37)</p></dt>
<dt><p><strong>CMD</strong> (38)</p></dt>
<dt><p><strong>ST506</strong> (39)</p></dt>
<dt><p><strong>DSSI</strong> (40)</p></dt>
<dt><p><strong>QIC2</strong> (41)</p></dt>
<dt><p><strong>Enhanced ATA/IDE</strong> (42)</p></dt>
<dt><p><strong>AGP</strong> (43)</p></dt>
<dt><p><strong>TWIRP (two-way infrared)</strong> (44)</p></dt>
<dt><p><strong>FIR (fast infrared)</strong> (45)</p></dt>
<dt><p><strong>SIR (serial infrared)</strong> (46)</p></dt>
<dt><p><strong>IrBus</strong> (47)</p></dt>
</dl>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value for the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time controller was last reset. This could mean the controller was powered down or reinitialized.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394060(v=vs.85).aspx
CONTROLLERDEVICE1394 = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394060(v=vs.85).aspx" />
    <title>Win32_1394ControllerDevice class (Windows)</title>
<h3>1394  Controller Device</h3>
<p>The <strong>Win32_1394ControllerDevice</strong> class has these properties.</p>
<dl>
<dt><strong>AccessState</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Indicates whether the controller is actively commanding or accessing the device.  This information is necessary when a logical device can be commanded by, or accessed through, multiple controllers.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Active</strong> (1)</p></dt>
<dt><p><strong>Inactive</strong> (2)</p></dt>
</dl>
</dd>
<dt><strong>Antecedent</strong></dt>
<dd><dl>
<dt>Data type: <strong>Win32_1394Controller</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The Win32_1394Controller antecedent reference represents the 1394 controller associated with this device.</p>
</dd>
<dt><strong>Dependent</strong></dt>
<dd><dl>
<dt>Data type: <strong>CIM_LogicalDevice</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The CIM_LogicalDevice dependent reference represents the CIM_LogicalDevice connected to the 1394 controller.</p>
</dd>
<dt><strong>NegotiatedDataWidth</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>When several bus or connection-data widths are possible, this  property defines the one in use between the devices.  Data width is specified in bits.  If data width is not negotiated, or if this information is not available or important to device management, the property should be set to 0 (zero).</p>
</dd>
<dt><strong>NegotiatedSpeed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>When several bus or connection speeds are possible, this  property defines the one being  used between the devices.  Speed is specified in bits-per-second.  If connection or bus speeds are not negotiated, or if this information is not available or important to device management, the property should be set to 0 (zero).</p>
</dd>
<dt><strong>NumberOfHardResets</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of hard resets issued by the controller. A hard reset returns the device to its initialization or boot-up state. All internal device state information and data are lost.</p>
</dd>
<dt><strong>NumberOfSoftResets</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of soft resets issued by the controller. A soft reset does not completely clear current device state and data. Exact semantics are dependent on the device and on the protocols and mechanisms used to communicate to it.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394074(v=vs.85).aspx
BATTERY = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394074(v=vs.85).aspx" />
    <title>Win32_Battery class (Windows)</title>
<h3> Battery</h3>
<p>The <strong>Win32_Battery</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>BatteryRechargeTime</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Time required to fully charge the battery. This property is not supported. <strong>BatteryRechargeTime</strong>  does not have a replacement property, and is now considered obsolete.</p>
</dd>
<dt><strong>BatteryStatus</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Status of the battery. The value 10 (Undefined) is not valid in the CIM schema because in DMI it represents that no battery is installed. In this case, the object should not be instantiated.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dd><p>The battery is discharging.</p></dd>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dd><p>The system has access to AC so no battery is being discharged. However, the battery is not necessarily charging.</p></dd>
<dt><p><strong>Fully Charged</strong> (3)</p></dt>
<dt><p><strong>Low</strong> (4)</p></dt>
<dt><p><strong>Critical</strong> (5)</p></dt>
<dt><p><strong>Charging</strong> (6)</p></dt>
<dt><p><strong>Charging and High</strong> (7)</p></dt>
<dt><p><strong>Charging and Low</strong> (8)</p></dt>
<dt><p><strong>Charging and Critical</strong> (9)</p></dt>
<dt><p><strong>Undefined</strong> (10)</p></dt>
<dt><p><strong>Partially Charged</strong> (11)</p></dt>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of the object—a one-line string.</p>
</dd>
<dt><strong>Chemistry</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Enumeration that describes the battery's chemistry.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Lead Acid</strong> (3)</p></dt>
<dt><p><strong>Nickel Cadmium</strong> (4)</p></dt>
<dt><p><strong>Nickel Metal Hydride</strong> (5)</p></dt>
<dt><p><strong>Lithium-ion</strong> (6)</p></dt>
<dt><p><strong>Zinc air</strong> (7)</p></dt>
<dt><p><strong>Lithium Polymer</strong> (8)</p></dt>
</dl>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DesignCapacity</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Design capacity of the battery in milliwatt-hours. If the property is not supported, enter 0 (zero).</p>
</dd>
<dt><strong>DesignVoltage</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Design voltage of the battery in millivolts. If the attribute is not supported, enter 0 (zero).</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Identifies the battery.</p>
<p>Example: "Internal Battery"</p>
<p></p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the error reported in the <strong>LastErrorCode</strong> property is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string that supplies more information about the error recorded in <strong>LastErrorCode</strong> property, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>EstimatedChargeRemaining</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Estimate of the percentage of full charge remaining.</p>
</dd>
<dt><strong>EstimatedRunTime</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Estimate in minutes of the time to battery charge depletion under the present load conditions if the utility power is off, or lost and remains off, or a laptop is disconnected from a power source.</p>
</dd>
<dt><strong>ExpectedBatteryLife</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Amount of time it takes to completely drain the battery after it is fully charged. This property is no longer used and is considered obsolete.</p>
</dd>
<dt><strong>ExpectedLife</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Battery's expected lifetime in minutes, assuming that the battery is fully charged. The property represents the total expected life of the battery, not its current remaining life, which is indicated by the <strong>EstimatedRunTime</strong> property.</p>
</dd>
<dt><strong>FullChargeCapacity</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Full charge capacity of the battery in milliwatt-hours. Comparison of the value to the <strong>DesignCapacity</strong> property determines when the battery requires replacement. A battery's end of life is typically when the <strong>FullChargeCapacity</strong> property falls below 80% of the <strong>DesignCapacity</strong> property. If the property is not supported, enter 0 (zero).</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>MaxRechargeTime</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum time, in minutes, to fully charge the battery. The property represents the time to recharge a fully depleted battery, not the current remaining charge time, which is indicated in the <strong>TimeToFullCharge</strong> property.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Defines the label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <a href="https://msdn.microsoft.com/en-us/library/aa387884(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CIM_LogicalDevice</strong></a> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>SmartBatteryVersion</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Data Specification version number supported by the battery. If the battery does not support this function, the value should be left blank.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOnBattery</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Elapsed time in seconds since the computer system's UPS last switched to battery power, or the time since the system or UPS was last restarted, whichever is less. If the battery is "on line", 0 (zero) is returned.</p>
</dd>
<dt><strong>TimeToFullCharge</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Remaining time to charge the battery fully in minutes at the current charging rate and usage.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394081(v=vs.85).aspx
CDROMDRIVE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394081(v=vs.85).aspx" />
    <title>Win32_CDROMDrive class (Windows)</title>
<h3>CDROM Drive</h3>
<p>The <strong>Win32_CDROMDrive</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Capabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of capabilities of the media access device. For example, the device may support random access (3),
       removable media (7), and automatic cleaning (9).</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Sequential Access</strong> (2)</p></dt>
<dt><p><strong>Random Access</strong> (3)</p></dt>
<dt><p><strong>Supports Writing</strong> (4)</p></dt>
<dt><p><strong>Encryption</strong> (5)</p></dt>
<dt><p><strong>Compression</strong> (6)</p></dt>
<dt><p><strong>Supports Removeable Media</strong> (7)</p></dt>
<dd><p>Supports Removable Media</p></dd>
<dt><p><strong>Manual Cleaning</strong> (8)</p></dt>
<dt><p><strong>Automatic Cleaning</strong> (9)</p></dt>
<dt><p><strong>SMART Notification</strong> (10)</p></dt>
<dt><p><strong>Supports Dual Sided Media</strong> (11)</p></dt>
<dd><p>Supports Dual-Sided Media</p></dd>
<dt><p><strong>Predismount Eject Not Required</strong> (12)</p></dt>
</dl>
</dd>
<dt><strong>CapabilityDescriptions</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of more detailed explanations for any of the access device features indicated in the
       <strong>Capabilities</strong> array. Each entry of this array is related to the entry in the
       <strong>Capabilities</strong> array that is located at the same index.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of the object—a one-line string.</p>
</dd>
<dt><strong>CompressionMethod</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Algorithm or tool used by the device to support compression. If it is not possible or not desired to describe the compression scheme (perhaps because it is not known), use the following words: "Unknown" to represent that it is not known whether the device supports compression capabilities; "Compressed" to represent that the device supports compression capabilities but either its compression scheme is not known or not disclosed; and "Not Compressed" to represent that the device does not support compression capabilities.</p>
<dl class="indent">
<dt><p><strong></strong> ("Unknown")</p></dt>
<dd><p>The compression scheme is unknown or not described.</p></dd>
<dt><p><strong></strong> ("Compressed")</p></dt>
<dd><p>The logical file is compressed, but the compression scheme is unknown or not described</p></dd>
<dt><p><strong></strong> ("Not Compressed")</p></dt>
<dd><p>If the logical file is not compressed</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>DefaultBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Default block size, in bytes, for this device.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier for a CD-ROM drive.</p>
</dd>
<dt><strong>Drive</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Drive letter of the CD-ROM drive.</p>
<p>Example: "d:\"</p>
</dd>
<dt><strong>DriveIntegrity</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, files can be accurately read from the CD device. This is achieved by reading a block of data twice and comparing the data against itself.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information about  corrective actions that can be taken.</p>
</dd>
<dt><strong>ErrorMethodology</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of error detection and correction supported by this device.</p>
</dd>
<dt><strong>FileSystemFlags</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>This property is obsolete. In place of this property, use <strong>FileSystemFlagsEx</strong>.</p>
</dd>
<dt><strong>FileSystemFlagsEx</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>File system flags associated with the Windows CD-ROM drive. This parameter can be any combination of flags, but <strong>FS_FILE_COMPRESSION</strong> and <strong>FS_VOL_IS_COMPRESSED</strong> are mutually exclusive.</p>
<dl class="indent">
<dt><p><strong>Case Sensitive Search</strong> (1)</p></dt>
<dd><p>The file system supports case-sensitive file names.</p></dd>
<dt><p><strong>Case Preserved Names</strong> (2)</p></dt>
<dd><p>The file system preserves the case of file names when it places a name on a disk.</p></dd>
<dt><p><strong>Unicode On Disk</strong> (4)</p></dt>
<dd><p>The file system supports Unicode in file names as they appear on the disk.</p></dd>
<dt><p><strong>Persistent ACLs</strong> (8)</p></dt>
<dd><p>The file system preserves and enforces access control lists (ACLs). For example, the NTFS file system preserves and enforces ACLs and the FAT file system does not.</p></dd>
<dt><p><strong>File Compression</strong> (16)</p></dt>
<dd><p>The file system supports file-based compression.</p></dd>
<dt><p><strong>Volume Quotas</strong> (32)</p></dt>
<dd><p>The file system supports disk quotas.</p></dd>
<dt><p><strong>Supports Sparse Files</strong> (64)</p></dt>
<dd><p>The file system supports spare files.</p></dd>
<dt><p><strong>Supports Reparse Points</strong> (128)</p></dt>
<dd><p>The file system supports reparse points.</p></dd>
<dt><p><strong>Supports Remote Storage</strong> (256)</p></dt>
<dd><p>The file system supports the remote storage of files.</p></dd>
<dt><p><strong>Supports Long Names</strong> (16384)</p></dt>
<dd><p>The file system supports file names that are longer than eight characters.</p></dd>
<dt><p><strong>Volume Is Compressed</strong> (32768)</p></dt>
<dd><p>The specified disk volume is a compressed volume, for example, a DoubleSpace volume.</p></dd>
<dt><p><strong>Read Only Volume</strong> (524289)</p></dt>
<dd><p>The specified volume is read-only.</p></dd>
<dt><p><strong>Supports Object IDS</strong> (65536)</p></dt>
<dd><p>The file system supports object identifiers.</p></dd>
<dt><p><strong>Supports Encryption</strong> (131072)</p></dt>
<dd><p>The file system supports the Encrypted File System (EFS).</p></dd>
<dt><p><strong>Supports Named Streams</strong> (262144)</p></dt>
<dd><p>The file system supports named streams.</p></dd>
</dl>
<p>Example: 0</p>
</dd>
<dt><strong>Id</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Drive letter that uniquely identifies this CD-ROM drive.</p>
<p>Example: "d:\"</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object is installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer of the Windows CD-ROM drive.</p>
<p>Example: "PLEXTOR"</p>
</dd>
<dt><strong>MaxBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum block size, in bytes, for media accessed by this device.</p>
</dd>
<dt><strong>MaximumComponentLength</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum length of a filename component supported by the Windows CD-ROM drive. A file name component the portion of a file name between backslashes. The value can be used to indicate that long names are supported by the specified file system. For example, for a FAT file system supporting long names, the function stores the value 255, rather than the previous 8.3 indicator. Long names can also be supported on systems that use the NTFS file system.</p>
<p>Example: 255</p>
</dd>
<dt><strong>MaxMediaSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum size, in kilobytes, of media supported by this device.</p>
</dd>
<dt><strong>MediaLoaded</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, a CD-ROM is in the drive.</p>
</dd>
<dt><strong>MediaType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of media that can be used or accessed by this device.  Possible values are:</p>
<dl class="indent">
<dt><p><strong>Random Access</strong> ("Random Access")</p></dt>
<dt><p><strong>Supports Writing</strong> ("Supports Writing")</p></dt>
<dt><p><strong>Removable Media</strong> ("Removable Media")</p></dt>
<dt><p><strong>CD-ROM</strong> ("CD-ROM")</p></dt>
</dl>
</dd>
<dt><strong>MfrAssignedRevisionLevel</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Firmware revision level that is assigned by the manufacturer.</p>
</dd>
<dt><strong>MinBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Minimum block size, in bytes, for media accessed by this device.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label for the object. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>NeedsCleaning</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the media access device needs cleaning. Whether manual or automatic cleaning is possible is indicated in the <strong>Capabilities</strong> property.</p>
</dd>
<dt><strong>NumberOfMediaSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of media that can be supported or inserted, when the media access device supports multiple individual media.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dd><p>Power-related capacities are not supported for this device.</p></dd>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState</em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device can be power-managed, which means that it can be put into suspend mode, and so on. The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>RevisionLevel</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Firmware revision level of the Windows CD-ROM drive.</p>
</dd>
<dt><strong>SCSIBus</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SCSI bus number for the disk drive.</p>
<p>Example: 0</p>
</dd>
<dt><strong>SCSILogicalUnit</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SCSI logical unit number (LUN) of the disk drive. The LUN is used to designate which SCSI controller is being accessed in a system with more than one controller being used. The SCSI device identifier is similar, but is the designation for multiple devices on one controller.</p>
<p>Example: 0</p>
</dd>
<dt><strong>SCSIPort</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SCSI port number of the disk drive.</p>
<p>Example: 1</p>
</dd>
<dt><strong>SCSITargetId</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SCSI identifier number of the Windows CD-ROM drive.</p>
<p>Example: 0</p>
</dd>
<dt><strong>SerialNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number supplied by the manufacturer that identifies the physical media.  Example: WD-WM3493798728.</p>
</dd>
<dt><strong>Size</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Size of the disk drive.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TransferRate</strong></dt>
<dd><dl>
<dt>Data type: <strong>real64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Transfer rate of the CD-ROM drive. A value of -1 indicates that the rate cannot be determined. When this happens,   the CD is not in the drive.</p>
</dd>
<dt><strong>VolumeName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Volume name of the Windows CD-ROM drive.</p>
</dd>
<dt><strong>VolumeSerialNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Volume serial number of the media in the CD-ROM drive.</p>
<p>Example: A8C3-D032</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394080(v=vs.85).aspx
CACHEMEMORY = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394080(v=vs.85).aspx" />
    <title>Win32_CacheMemory class (Windows)</title>
<h3> Cache Memory</h3>
<p>The <strong>Win32_CacheMemory</strong> class has these properties.</p>
<dl>
<dt><strong>Access</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of access.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Readable</strong> (1)</p></dt>
<dt><p><strong>Writeable</strong> (2)</p></dt>
<dd><p>Writable</p></dd>
<dt><p><strong>Read/Write Supported</strong> (3)</p></dt>
<dt><p><strong>Write Once</strong> (4)</p></dt>
</dl>
</dd>
<dt><strong>AdditionalErrorData</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of octets that hold additional error information. An example is ECC Syndrome or the return of the check bits if a CRC-based error methodology is used. In the latter case, if a single-bit error is recognized and the CRC algorithm is known, it is possible to determine the exact bit that failed. This type of data (ECC Syndrome, Check Bit, Parity Bit data, or other vendor supplied information) is included in this field. If the <strong>ErrorInfo</strong> property is equal to 3 (OK), then this property has no meaning.</p>
</dd>
<dt><strong>Associativity</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>An integer enumeration that defines the system cache associativity.</p>
<p>This value comes from the <strong>Associativity</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Direct Mapped</strong> (3)</p></dt>
<dt><p><strong>2-way Set-Associative</strong> (4)</p></dt>
<dt><p><strong>4-way Set-Associative</strong> (5)</p></dt>
<dt><p><strong>Fully Associative</strong> (6)</p></dt>
<dt><p><strong>8-way Set-Associative</strong> (7)</p></dt>
<dt><p><strong>16-way Set-Associative</strong> (8)</p></dt>
</dl>
</dd>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<p>This value comes from the <strong>Cache Configuration</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>BlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Size in bytes of the blocks that form this storage extent. If unknown or if a block concept is not valid (for example, for aggregate extents, memory, or logical disks), enter a 1.</p>
</dd>
<dt><strong>CacheSpeed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Speed of the cache.</p>
<p>This value comes from the <strong>Cache Speed</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>CacheType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of cache.</p>
<p>This value comes from the <strong>System Cache Type</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Instruction</strong> (3)</p></dt>
<dt><p><strong>Data</strong> (4)</p></dt>
<dt><p><strong>Unified</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CorrectableError</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the most recent error was correctable. If the <strong>ErrorInfo</strong> property is equal to 3 (OK), then this property has no meaning.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>CurrentSRAM</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of types of Static Random Access Memory (SRAM) being used for the cache memory.</p>
<p>This value comes from the <strong>Current SRAM Type</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (0)</p></dt>
<dt><p><strong>Unknown</strong> (1)</p></dt>
<dt><p><strong>Non-Burst</strong> (2)</p></dt>
<dt><p><strong>Burst</strong> (3)</p></dt>
<dt><p><strong>Pipeline Burst</strong> (4)</p></dt>
<dt><p><strong>Synchronous</strong> (5)</p></dt>
<dt><p><strong>Asynchronous</strong> (6)</p></dt>
</dl>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the cache represented by an instance of  <strong>Win32_CacheMemory</strong>.</p>
<p>Example: "Cache Memory 1"</p>
</dd>
<dt><strong>EndingAddress</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Ending address, referenced by an application or operating system and mapped by a memory controller, for this memory object. The ending address is specified in kilobytes.</p>
</dd>
<dt><strong>ErrorAccess</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Memory access operation that caused the last error. The type of error is described by the <strong>ErrorInfo</strong> property. If <strong>ErrorInfo</strong> is equal to 3 (OK), then this property has no meaning.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Read</strong> (3)</p></dt>
<dt><p><strong>Write</strong> (4)</p></dt>
<dt><p><strong>Partial Write</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>ErrorAddress</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Address of the last memory error. The type of error is described by the <strong>ErrorInfo</strong> property. If <strong>ErrorInfo</strong> is equal to 3 (OK), then this property has no meaning.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorCorrectType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Error correction method used by the cache memory.</p>
<p>This value comes from the <strong>Error Correction Type</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Reserved</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>None</strong> (3)</p></dt>
<dt><p><strong>Parity</strong> (4)</p></dt>
<dt><p><strong>Single-bit ECC</strong> (5)</p></dt>
<dt><p><strong>Multi-bit ECC</strong> (6)</p></dt>
</dl>
</dd>
<dt><strong>ErrorData</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of data captured during the last erroneous memory access. The data occupies the first <em>n</em> octets of the array necessary to hold the number of bits specified by the <strong>ErrorTransferSize</strong> property. If <strong>ErrorTransferSize</strong> is 0 (zero), then this property has no meaning.</p>
</dd>
<dt><strong>ErrorDataOrder</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Ordering for data stored in the <strong>ErrorData</strong> property. If <strong>ErrorTransferSize</strong> is 0 (zero), then this property has no meaning.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Least Significant Byte First</strong> (1)</p></dt>
<dt><p><strong>Most Significant Byte First</strong> (2)</p></dt>
</dl>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information on any corrective actions that may be taken.</p>
</dd>
<dt><strong>ErrorInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of error that occurred most recently. The values 12-14 are undefined in the CIM schema because in DMI they mix the semantics of the type of error and whether it was correctable or not. The latter is indicated in the property <strong>CorrectableError</strong>.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>OK</strong> (3)</p></dt>
<dt><p><strong>Bad Read</strong> (4)</p></dt>
<dt><p><strong>Parity Error</strong> (5)</p></dt>
<dt><p><strong>Single-Bit Error</strong> (6)</p></dt>
<dt><p><strong>Double-Bit Error</strong> (7)</p></dt>
<dt><p><strong>Multi-Bit Error</strong> (8)</p></dt>
<dt><p><strong>Nibble Error</strong> (9)</p></dt>
<dt><p><strong>Checksum Error</strong> (10)</p></dt>
<dt><p><strong>CRC Error</strong> (11)</p></dt>
<dt><p><strong>Undefined</strong> (12)</p></dt>
<dt><p><strong>Undefined</strong> (13)</p></dt>
<dt><p><strong>Undefined</strong> (14)</p></dt>
</dl>
</dd>
<dt><strong>ErrorMethodology</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Details on the parity or CRC algorithms, ECC, or other mechanisms used.</p>
</dd>
<dt><strong>ErrorResolution</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Range, in bytes, to which the last error can be resolved. For example, if error addresses are resolved to bit 11 (that is, on a typical page basis), then errors can be resolved to 4 KB boundaries and this property is set to 4000. If the <strong>ErrorInfo</strong> property is equal to 3 (OK), then this property has no meaning.</p>
</dd>
<dt><strong>ErrorTime</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Time that the last memory error occurred. The type of error is described by the <strong>ErrorInfo</strong> property. If the <strong>ErrorInfo</strong> property is equal to 3 (OK), then this property has no meaning.</p>
</dd>
<dt><strong>ErrorTransferSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Size of the data transfer in bits that caused the last error. 0 (zero) indicates no error. If the <strong>ErrorInfo</strong> property is equal to 3 (OK), then this property should be set to 0 (zero).</p>
</dd>
<dt><strong>FlushTimer</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum amount of time, in seconds, dirty lines or buckets may remain in the cache before they are flushed. A value of 0 (zero) indicates that a cache flush is not controlled by a flushing timer.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>InstalledSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current size of the installed cache memory.</p>
<p>This value comes from the <strong>Installed Size</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Level</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Level of the cache.</p>
<p>This value comes from the <strong>Cache Configuration</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Primary</strong> (3)</p></dt>
<dt><p><strong>Secondary</strong> (4)</p></dt>
<dt><p><strong>Tertiary</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
</dl>
</dd>
<dt><strong>LineSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Size, in bytes, of a single cache bucket or line.</p>
</dd>
<dt><strong>Location</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Physical location of the cache memory.</p>
<p>This value comes from the <strong>Cache Configuration</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Internal</strong> (0)</p></dt>
<dt><p><strong>External</strong> (1)</p></dt>
<dt><p><strong>Reserved</strong> (2)</p></dt>
<dt><p><strong>Unknown</strong> (3)</p></dt>
</dl>
</dd>
<dt><strong>MaxCacheSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum cache size installable to this particular cache memory.</p>
<p>This value comes from the <strong>Maximum Cache Size</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>NumberOfBlocks</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Total number of consecutive blocks, each block the size of the value contained in the <strong>BlockSize</strong> property, which form this storage extent. Total size of the storage extent can be calculated by multiplying the value of the <strong>BlockSize</strong> property by the value of this property. If the value of <strong>BlockSize</strong> is 1, this property is the total size of the storage extent.</p>
</dd>
<dt><strong>OtherErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string providing more information if the <strong>ErrorType</strong> property is set to 1, Other. Otherwise, this string has no meaning.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>Purpose</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string describing the media and its use.</p>
<p>This value comes from the <strong>Socket Designation</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>ReadPolicy</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Policy that shall be employed by the cache for handling read requests.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Read</strong> (3)</p></dt>
<dt><p><strong>Read-Ahead</strong> (4)</p></dt>
<dt><p><strong>Read and Read-Ahead</strong> (5)</p></dt>
<dt><p><strong>Determination Per I/O</strong> (6)</p></dt>
</dl>
</dd>
<dt><strong>ReplacementPolicy</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Algorithm to determine which cache lines or buckets should be reused.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Least Recently Used (LRU)</strong> (3)</p></dt>
<dt><p><strong>First In First Out (FIFO)</strong> (4)</p></dt>
<dt><p><strong>Last In First Out (LIFO)</strong> (5)</p></dt>
<dt><p><strong>Least Frequently Used (LFU)</strong> (6)</p></dt>
<dt><p><strong>Most Frequently Used (MFU)</strong> (7)</p></dt>
<dt><p><strong>Data Dependent Multiple Algorithms</strong> (8)</p></dt>
</dl>
</dd>
<dt><strong>StartingAddress</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Beginning address, referenced by an application or operating system and mapped by a memory controller, for this memory object. The starting address is specified in kilobytes.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<p>This value comes from the <strong>Cache Configuration</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SupportedSRAM</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of supported types of Static Random Access Memory (SRAM) that can be used for the cache memory.</p>
<p>This value comes from the <strong>Supported SRAM Type</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (0)</p></dt>
<dt><p><strong>Unknown</strong> (1)</p></dt>
<dt><p><strong>Non-Burst</strong> (2)</p></dt>
<dt><p><strong>Burst</strong> (3)</p></dt>
<dt><p><strong>Pipeline Burst</strong> (4)</p></dt>
<dt><p><strong>Synchronous</strong> (5)</p></dt>
<dt><p><strong>Asynchronous</strong> (6)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemLevelAddress</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the address information in the property <strong>ErrorAddress</strong> is a system-level address. If <strong>False</strong>, it is a physical address. If the <strong>ErrorInfo</strong> property is equal to 3, then this property has no meaning.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>WritePolicy</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Write policy definition.</p>
<p>This value comes from the <strong>Cache Configuration</strong> member of the <strong>Cache Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Write Back</strong> (3)</p></dt>
<dt><p><strong>Write Through</strong> (4)</p></dt>
<dt><p><strong>Varies with Address</strong> (5)</p></dt>
<dt><p><strong>Determination Per I/O</strong> (6)</p></dt>
</dl>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394122(v=vs.85).aspx
DESKTOPMONITOR = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394122(v=vs.85).aspx" />
    <title>Win32_DesktopMonitor class (Windows)</title>
<h3> Desktop Monitor</h3>
<p>The <strong>Win32_DesktopMonitor</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Bandwidth</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Monitor's bandwidth in megahertz. If unknown, enter 0 (zero).</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of a desktop monitor.</p>
</dd>
<dt><strong>DisplayType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of desktop monitor or CRT.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Multiscan Color</strong> (2)</p></dt>
<dt><p><strong>Multiscan Monochrome</strong> (3)</p></dt>
<dt><p><strong>Fixed Frequency Color</strong> (4)</p></dt>
<dt><p><strong>Fixed Frequency Monochrome</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string supplying more information about the error recorded in <strong>LastErrorCode</strong>, and information on any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>IsLocked</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is locked, preventing user input or output.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>MonitorManufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the monitor manufacturer.</p>
<p>Example: "NEC"</p>
</dd>
<dt><strong>MonitorType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of monitor.</p>
<p>Example: "NEC 5FGp"</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PixelsPerXLogicalInch</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Resolution along the x-axis (horizontal direction) of the monitor.</p>
</dd>
<dt><strong>PixelsPerYLogicalInch</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Resolution along the y-axis (vertical direction) of the monitor.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dd><p>Power-related capacities are not supported for this device.</p></dd>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState</em> parameter set to 5 (Power Cycle) and <em>Time</em> set to a specific date and time, or interval, for power-on.</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ScreenHeight</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Logical height of the display in screen coordinates.</p>
</dd>
<dt><strong>ScreenWidth</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Logical width of the display in screen coordinates.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational
       statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may
       be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error",
       "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk,
       reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed
       element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394132(v=vs.85).aspx
DISKDRIVE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394132(v=vs.85).aspx" />
    <title>Win32_DiskDrive class (Windows)</title>
<h3> Disk Drive</h3>
<p>The <strong>Win32_DiskDrive</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The disk drive is unavailable.</p></dd>
</dl>
</dd>
<dt><strong>BytesPerSector</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of bytes in each sector for the physical disk drive.</p>
<p>Example: 512</p>
</dd>
<dt><strong>Capabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of capabilities of the media access device. For example, the device may support random access (3), removable media (7), and automatic cleaning (9).</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Sequential Access</strong> (2)</p></dt>
<dt><p><strong>Random Access</strong> (3)</p></dt>
<dt><p><strong>Supports Writing</strong> (4)</p></dt>
<dt><p><strong>Encryption</strong> (5)</p></dt>
<dt><p><strong>Compression</strong> (6)</p></dt>
<dt><p><strong>Supports Removeable Media</strong> (7)</p></dt>
<dd><p>Supports Removable Media</p></dd>
<dt><p><strong>Manual Cleaning</strong> (8)</p></dt>
<dt><p><strong>Automatic Cleaning</strong> (9)</p></dt>
<dt><p><strong>SMART Notification</strong> (10)</p></dt>
<dt><p><strong>Supports Dual Sided Media</strong> (11)</p></dt>
<dd><p>Supports Dual-Sided Media</p></dd>
<dt><p><strong>Predismount Eject Not Required</strong> (12)</p></dt>
<dd><p>Ejection Prior to Drive Dismount Not Required</p></dd>
</dl>
</dd>
<dt><strong>CapabilityDescriptions</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>List of more detailed explanations for any of the access device features indicated in the <strong>Capabilities</strong> array. Note, each entry of this array is related to the entry in the <strong>Capabilities</strong> array that is located at the same index.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>CompressionMethod</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
<p>
</p><p>The name of the compression algorithm or one of the following values.</p>

<dl class="indent">
<dt><p><strong></strong> ("Unknown")</p></dt>
<dd><p>Whether the device supports compression capabilities or not is not known.</p></dd>
<dt><p><strong></strong> ("Compressed")</p></dt>
<dd><p>The device supports compression capabilities but its compression scheme is not known or not disclosed.</p></dd>
<dt><p><strong></strong> ("Not Compressed")</p></dt>
<dd><p>The device does not support compression.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>DefaultBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Default block size, in bytes, for this device.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the disk drive with other devices on the system.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information on any corrective actions that may be taken.</p>
</dd>
<dt><strong>ErrorMethodology</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of error detection and correction supported by this device.</p>
</dd>
<dt><strong>FirmwareRevision</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Revision for the disk drive firmware that is assigned by the manufacturer.</p>
</dd>
<dt><strong>Index</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
       control code. A value of 0xffffffff indicates that the given drive does not map to a physical drive.</p>
<p>Example: 1</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>InterfaceType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Interface type of physical disk drive.</p>
<p>
</p><p>The values are:</p>

<p class="indent">SCSI</p>
<p class="indent">HDC</p>
<p class="indent">IDE</p>
<p class="indent">USB</p>
<p class="indent">1394</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the disk drive manufacturer.</p>
<p>Example: "Seagate"</p>
</dd>
<dt><strong>MaxBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum block size, in bytes, for media accessed by this device.</p>
</dd>
<dt><strong>MaxMediaSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum media size, in kilobytes, of media supported by this device.</p>
</dd>
<dt><strong>MediaLoaded</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the media for a disk drive is loaded, which means that the device has a readable file system and is accessible. For fixed disk drives, this property will always be <strong>TRUE</strong>.</p>
</dd>
<dt><strong>MediaType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of media used or accessed by this device.</p>
<p>
</p><p>Possible values are:</p>

<dl class="indent">
<dt><p><strong>External hard disk media</strong></p></dt>
<dt><p><strong>Removable media</strong> ("Removable media other than floppy")</p></dt>
<dt><p><strong>Fixed hard disk</strong> ("Fixed hard disk media")</p></dt>
<dt><p><strong>Unknown</strong> ("Format is unknown")</p></dt>
</dl>
</dd>
<dt><strong>MinBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Minimum block size, in bytes, for media accessed by this device.</p>
</dd>
<dt><strong>Model</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer's model number of the disk drive.</p>
<p>Example: "ST32171W"</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>NeedsCleaning</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the media access device needs cleaning. Whether manual or automatic cleaning is possible is indicated in the <strong>Capabilities</strong> property.</p>
</dd>
<dt><strong>NumberOfMediaSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of media which can be supported or inserted (when the media access device supports multiple individual media).</p>
</dd>
<dt><strong>Partitions</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of partitions on this physical disk drive that are recognized by the operating system.</p>
<p>Example: 2</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dd><p>Power-related capacities are not supported for this device.</p></dd>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <a href="https://msdn.microsoft.com/en-us/library/aa387884(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CIM_LogicalDevice</strong></a> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>SCSIBus</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SCSI bus number of the disk drive.</p>
<p>Example: 0</p>
</dd>
<dt><strong>SCSILogicalUnit</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SCSI logical unit number (LUN) of the disk drive.</p>
<p>Example: 0</p>
</dd>
<dt><strong>SCSIPort</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SCSI port number of the disk drive.</p>
<p>Example: 0</p>
</dd>
<dt><strong>SCSITargetId</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SCSI identifier number of the disk drive.</p>
<p>Example: 0</p>
</dd>
<dt><strong>SectorsPerTrack</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of sectors in each track for this physical disk drive.</p>
<p>Example: 63</p>
</dd>
<dt><strong>SerialNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number allocated by the manufacturer to identify the physical media.</p>
<p>Example: WD-WM3493798728</p>
</dd>
<dt><strong>Signature</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Disk identification. This property can be used to identify a shared resource.</p>
</dd>
<dt><strong>Size</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Size of the disk drive. It is calculated by multiplying the total number of cylinders, tracks in each cylinder, sectors in each track, and bytes in each sector.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational
       statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may
       be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error",
       "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk,
       reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed
       element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values are:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TotalCylinders</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Total number of cylinders on the physical disk drive. Note: the value for this property is obtained through extended functions of BIOS interrupt 13h. The value may be inaccurate if the drive uses a translation scheme to support high-capacity disk sizes. Consult the manufacturer for accurate drive specifications.</p>
<p>Example: 657</p>
</dd>
<dt><strong>TotalHeads</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Total number of heads on the disk drive. Note: the value for this property is obtained through extended functions of BIOS interrupt 13h. The value may be inaccurate if the drive uses a translation scheme to support high-capacity disk sizes. Consult the manufacturer for accurate drive specifications.</p>
</dd>
<dt><strong>TotalSectors</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Total number of sectors on the physical disk drive. Note: the value for this property is obtained through extended functions of BIOS interrupt 13h. The value may be inaccurate if the drive uses a translation scheme to support high-capacity disk sizes. Consult the manufacturer for accurate drive specifications.</p>
<p>Example: 2649024</p>
</dd>
<dt><strong>TotalTracks</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Total number of tracks on the physical disk drive. Note: the value for this property is obtained through extended functions of BIOS interrupt 13h. The value may be inaccurate if the drive uses a translation scheme to support high-capacity disk sizes. Consult the manufacturer for accurate drive specifications.</p>
<p>Example: 42048</p>
</dd>
<dt><strong>TracksPerCylinder</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of tracks in each cylinder on the physical disk drive. Note: the value for this property is obtained through extended functions of BIOS interrupt 13h. The value may be inaccurate if the drive uses a translation scheme to support high-capacity disk sizes. Consult the manufacturer for accurate drive specifications.</p>
<p>Example: 64</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394146(v=vs.85).aspx
FAN = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394146(v=vs.85).aspx" />
    <title>Win32_Fan class (Windows)</title>
<h3> Fan</h3>
<p>The <strong>Win32_Fan</strong> class has these properties.</p>
<dl>
<dt><strong>ActiveCooling</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the cooling device provides active (as opposed to passive) cooling.</p>
</dd>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DesiredSpeed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Identifies the fan device.
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the error reported in the <strong>LastErrorCode</strong> property is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string supplying more information about the error recorded in <strong>LastErrorCode</strong> property, and information on any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dd><p>Power-related capacities are not supported for this device.</p></dd>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>VariableSpeed</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the fan supports variable speeds.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394148(v=vs.85).aspx
FLOPPYCONTROLLER = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394148(v=vs.85).aspx" />
    <title>Win32_FloppyController class (Windows)</title>
<h3> Floppy Controller</h3>
<p>The <strong>Win32_FloppyController</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>Power Save - Unknown</p>
<p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>Power Save - Low Power Mode</p>
<p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>Power Save - Standby</p>
<p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>Power Save - Warning</p>
<p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the
        device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is
        removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance.
       When used with the other key properties of the class, the property allows all instances of this class and its
       subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Unique identifier of the floppy controller.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is
       now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information
       about any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object is installed. This property does not need a value to indicate that the object is
       installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the floppy controller manufacturer.</p>
<p>Example: "Microsoft"</p>
</dd>
<dt><strong>MaxNumberControlled</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of directly addressable entities that this controller supports. A value of 0 (zero) should be
       used if the number is unknown.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label for the object. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier for the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information
         is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The
         method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong>
         class and can be implemented. For more information, see </dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The
         method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>The
         method can be invoked with the <em>PowerState</em> parameter set to 5 (Power Cycle) and
         <em>Time</em> set to a specific date and time, or interval, for power-on.</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed, which means that it can be put into
       suspend mode, and so on. The property does not indicate that power management features are currently enabled,
       only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProtocolSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Protocol used by the controller to access "controlled" devices.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>EISA</strong> (3)</p></dt>
<dt><p><strong>ISA</strong> (4)</p></dt>
<dt><p><strong>PCI</strong> (5)</p></dt>
<dt><p><strong>ATA/ATAPI</strong> (6)</p></dt>
<dt><p><strong>Flexible Diskette</strong> (7)</p></dt>
<dt><p><strong>1496</strong> (8)</p></dt>
<dt><p><strong>SCSI Parallel Interface</strong> (9)</p></dt>
<dt><p><strong>SCSI Fibre Channel Protocol</strong> (10)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol</strong> (11)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol-2 (1394)</strong> (12)</p></dt>
<dt><p><strong>SCSI Serial Storage Architecture</strong> (13)</p></dt>
<dt><p><strong>VESA</strong> (14)</p></dt>
<dt><p><strong>PCMCIA</strong> (15)</p></dt>
<dt><p><strong>Universal Serial Bus</strong> (16)</p></dt>
<dt><p><strong>Parallel Protocol</strong> (17)</p></dt>
<dt><p><strong>ESCON</strong> (18)</p></dt>
<dt><p><strong>Diagnostic</strong> (19)</p></dt>
<dt><p><strong>I2C</strong> (20)</p></dt>
<dt><p><strong>Power</strong> (21)</p></dt>
<dt><p><strong>HIPPI</strong> (22)</p></dt>
<dt><p><strong>MultiBus</strong> (23)</p></dt>
<dt><p><strong>VME</strong> (24)</p></dt>
<dt><p><strong>IPI</strong> (25)</p></dt>
<dt><p><strong>IEEE-488</strong> (26)</p></dt>
<dt><p><strong>RS232</strong> (27)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE5</strong> (28)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE2</strong> (29)</p></dt>
<dt><p><strong>IEEE 802.3 1BASE5</strong> (30)</p></dt>
<dt><p><strong>IEEE 802.3 10BROAD36</strong> (31)</p></dt>
<dt><p><strong>IEEE 802.3 100BASEVG</strong> (32)</p></dt>
<dt><p><strong>IEEE 802.5 Token-Ring</strong> (33)</p></dt>
<dt><p><strong>ANSI X3T9.5 FDDI</strong> (34)</p></dt>
<dt><p><strong>MCA</strong> (35)</p></dt>
<dt><p><strong>ESDI</strong> (36)</p></dt>
<dt><p><strong>IDE</strong> (37)</p></dt>
<dt><p><strong>CMD</strong> (38)</p></dt>
<dt><p><strong>ST506</strong> (39)</p></dt>
<dt><p><strong>DSSI</strong> (40)</p></dt>
<dt><p><strong>QIC2</strong> (41)</p></dt>
<dt><p><strong>Enhanced ATA/IDE</strong> (42)</p></dt>
<dt><p><strong>AGP</strong> (43)</p></dt>
<dt><p><strong>TWIRP (two-way infrared)</strong> (44)</p></dt>
<dt><p><strong>FIR (fast infrared)</strong> (45)</p></dt>
<dt><p><strong>SIR (serial infrared)</strong> (46)</p></dt>
<dt><p><strong>IrBus</strong> (47)</p></dt>
</dl>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational
       statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may
       be functioning properly but predicting a failure in the near future). Nonoperational statuses include:
       "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of
       a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the
       managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>The values are:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5
       (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the controller was last reset. This could mean the controller was powered down or
       reinitialized.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394149(v=vs.85).aspx
FLOPPYDRIVE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394149(v=vs.85).aspx" />
    <title>Win32_FloppyDrive class (Windows)</title>
<h3> Floppy Drive</h3>
<p>The <strong>Win32_FloppyDrive</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Status of the device.</p>
</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>Power Save - Unknown</p>
<p>The device in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>Power Save - Low Power Mode</p>
<p>The device is in a power save state, but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>Power Save - Standby</p>
<p>The device is not functioning, but can be quickly restored to full-power.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>Power Save - Warning</p>
<p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Capabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of capabilities of the media access device. For example, the device may support Random Access, Removable Media, and Automatic Cleaning. In this case, the values 3, 7, and 9 would be written to the array.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Sequential Access</strong> (2)</p></dt>
<dt><p><strong>Random Access</strong> (3)</p></dt>
<dt><p><strong>Supports Writing</strong> (4)</p></dt>
<dt><p><strong>Encryption</strong> (5)</p></dt>
<dt><p><strong>Compression</strong> (6)</p></dt>
<dt><p><strong>Supports Removeable Media</strong> (7)</p></dt>
<dd><p>Supports Removable Media</p></dd>
<dt><p><strong>Manual Cleaning</strong> (8)</p></dt>
<dt><p><strong>Automatic Cleaning</strong> (9)</p></dt>
<dt><p><strong>SMART Notification</strong> (10)</p></dt>
<dt><p><strong>Supports Dual Sided Media</strong> (11)</p></dt>
<dd><p>Supports Dual-Sided Media</p></dd>
<dt><p><strong>Predismount Eject Not Required</strong> (12)</p></dt>
</dl>
</dd>
<dt><strong>CapabilityDescriptions</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of free-form strings providing more detailed explanations for any of the serial controller features indicated in the <strong>Capabilities</strong> array. Note, each entry of this array is related to the entry in the <strong>Capabilities</strong> array that is located at the same index.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>CompressionMethod</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free form string indicating the algorithm or tool used by the device to support compression. If it is not possible or not desired to describe the compression scheme (perhaps because it is not known), use  "Unknown" to represent that it is not known whether the device supports compression capabilities or not; "Compressed" to represent that the device supports compression capabilities, but either its compression scheme is not known or not disclosed; and "Not Compressed" to represent that the device does not support compression capabilities.</p>
<dl class="indent">
<dt><p><strong></strong> ("Unknown")</p></dt>
<dd><p>The compression scheme is unknown or not described.</p></dd>
<dt><p><strong></strong> ("Compressed")</p></dt>
<dd><p>The logical file is compressed, but the compression scheme is unknown or not described</p></dd>
<dt><p><strong></strong> ("Not Compressed")</p></dt>
<dd><p>If the logical file is not compressed</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Configuration Manager error code.</p>
</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>DefaultBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Default block size, in bytes, for this device.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Unique identifier of the floppy disk drive with other devices on the system.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string that supplies more information about the error recorded in <strong>LastErrorCode</strong>, and information on any corrective actions that may be taken.</p>
</dd>
<dt><strong>ErrorMethodology</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string that describes the type of error detection and correction supported by this device.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the manufacturer of the floppy disk drive.</p>
<p>Example: "Acme"</p>
</dd>
<dt><strong>MaxBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum block size, in bytes, for media accessed by this device.</p>
</dd>
<dt><strong>MaxMediaSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum size, in kilobytes, of media supported by this device.</p>
</dd>
<dt><strong>MinBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Minimum block size, in bytes, for media accessed by this device.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>NeedsCleaning</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the media access device requires cleaning. Whether manual or automatic cleaning is possible is indicated in the <strong>Capabilities</strong> property.</p>
</dd>
<dt><strong>NumberOfMediaSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of individual media which can be supported or inserted in the media access device (when supported).</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>Enabled</p>
<p>The power management features are currently enabled, but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>Power Saving Modes Entered Automatically</p>
<p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>Power State Settable</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>Power Cycling Supported</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational
       statuses include: "OK", "Degraded", and "Pred Fail" (an
       element, such as a SMART-enabled hard disk drive, may be functioning properly, but predicting a failure in the
       near future). Nonoperational statuses include: "Error", "Starting",
       "Stopping", and "Service". The latter, "Service", could
       apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not
       all such work is online, yet the managed element is neither "OK" nor in one of the other
       states.</p>
<p>
</p><p>The values are:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5
       ("Not Applicable") should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer <strong>CreationClassName</strong> property. This property is
</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394154(v=vs.85).aspx
HEATPIPE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394154(v=vs.85).aspx" />
    <title>Win32_HeatPipe class (Windows)</title>
<h3> Heat Pipe</h3>
<p>The <strong>Win32_HeatPipe</strong> class has these properties.</p>
<dl>
<dt><strong>ActiveCooling</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the cooling device provides active  cooling—not passive.</p>
</dd>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the heat pipe.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error that is recorded in <strong>LastErrorCode</strong>, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dd><p>Power-related capacities are not supported for this device.</p></dd>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed—put into suspend mode, and so on. The property does not indicate that power management features are  enabled currently, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value for the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394155(v=vs.85).aspx
IDECONTROLLER = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394155(v=vs.85).aspx" />
    <title>Win32_IDEController class (Windows)</title>
<h3>IDE Controller</h3>
<p>The <strong>Win32_IDEController</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the IDE controller—with other devices on the system.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong> property, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer of the IDE controller device.</p>
</dd>
<dt><strong>MaxNumberControlled</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device ID of the logical device.</p>
<p>Example: *PNP030b</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed—put into suspend mode, and so on. The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProtocolSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Protocol used by the controller to access "controlled" devices.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>EISA</strong> (3)</p></dt>
<dt><p><strong>ISA</strong> (4)</p></dt>
<dt><p><strong>PCI</strong> (5)</p></dt>
<dt><p><strong>ATA/ATAPI</strong> (6)</p></dt>
<dt><p><strong>Flexible Diskette</strong> (7)</p></dt>
<dt><p><strong>1496</strong> (8)</p></dt>
<dt><p><strong>SCSI Parallel Interface</strong> (9)</p></dt>
<dt><p><strong>SCSI Fibre Channel Protocol</strong> (10)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol</strong> (11)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol-2 (1394)</strong> (12)</p></dt>
<dt><p><strong>SCSI Serial Storage Architecture</strong> (13)</p></dt>
<dt><p><strong>VESA</strong> (14)</p></dt>
<dt><p><strong>PCMCIA</strong> (15)</p></dt>
<dt><p><strong>Universal Serial Bus</strong> (16)</p></dt>
<dt><p><strong>Parallel Protocol</strong> (17)</p></dt>
<dt><p><strong>ESCON</strong> (18)</p></dt>
<dt><p><strong>Diagnostic</strong> (19)</p></dt>
<dt><p><strong>I2C</strong> (20)</p></dt>
<dt><p><strong>Power</strong> (21)</p></dt>
<dt><p><strong>HIPPI</strong> (22)</p></dt>
<dt><p><strong>MultiBus</strong> (23)</p></dt>
<dt><p><strong>VME</strong> (24)</p></dt>
<dt><p><strong>IPI</strong> (25)</p></dt>
<dt><p><strong>IEEE-488</strong> (26)</p></dt>
<dt><p><strong>RS232</strong> (27)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE5</strong> (28)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE2</strong> (29)</p></dt>
<dt><p><strong>IEEE 802.3 1BASE5</strong> (30)</p></dt>
<dt><p><strong>IEEE 802.3 10BROAD36</strong> (31)</p></dt>
<dt><p><strong>IEEE 802.3 100BASEVG</strong> (32)</p></dt>
<dt><p><strong>IEEE 802.5 Token-Ring</strong> (33)</p></dt>
<dt><p><strong>ANSI X3T9.5 FDDI</strong> (34)</p></dt>
<dt><p><strong>MCA</strong> (35)</p></dt>
<dt><p><strong>ESDI</strong> (36)</p></dt>
<dt><p><strong>IDE</strong> (37)</p></dt>
<dt><p><strong>CMD</strong> (38)</p></dt>
<dt><p><strong>ST506</strong> (39)</p></dt>
<dt><p><strong>DSSI</strong> (40)</p></dt>
<dt><p><strong>QIC2</strong> (41)</p></dt>
<dt><p><strong>Enhanced ATA/IDE</strong> (42)</p></dt>
<dt><p><strong>AGP</strong> (43)</p></dt>
<dt><p><strong>TWIRP (two-way infrared)</strong> (44)</p></dt>
<dt><p><strong>FIR (fast infrared)</strong> (45)</p></dt>
<dt><p><strong>SIR (serial infrared)</strong> (46)</p></dt>
<dt><p><strong>IrBus</strong> (47)</p></dt>
</dl>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value for the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time this controller was last reset. This could mean the controller was powered down or reinitialized.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394158(v=vs.85).aspx
INFRAREDDEVICE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394158(v=vs.85).aspx" />
    <title>Win32_InfraredDevice class (Windows)</title>
<h3> Infrared Device</h3>
<p>The <strong>Win32_InfraredDevice</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the infrared device.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer of the device.</p>
</dd>
<dt><strong>MaxNumberControlled</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of directly addressable entities supportable by this device. A value of 0 (zero) should be used if the number is unknown.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProtocolSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Protocol used by the controller to access "controlled" devices.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>EISA</strong> (3)</p></dt>
<dt><p><strong>ISA</strong> (4)</p></dt>
<dt><p><strong>PCI</strong> (5)</p></dt>
<dt><p><strong>ATA/ATAPI</strong> (6)</p></dt>
<dt><p><strong>Flexible Diskette</strong> (7)</p></dt>
<dt><p><strong>1496</strong> (8)</p></dt>
<dt><p><strong>SCSI Parallel Interface</strong> (9)</p></dt>
<dt><p><strong>SCSI Fibre Channel Protocol</strong> (10)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol</strong> (11)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol-2 (1394)</strong> (12)</p></dt>
<dt><p><strong>SCSI Serial Storage Architecture</strong> (13)</p></dt>
<dt><p><strong>VESA</strong> (14)</p></dt>
<dt><p><strong>PCMCIA</strong> (15)</p></dt>
<dt><p><strong>Universal Serial Bus</strong> (16)</p></dt>
<dt><p><strong>Parallel Protocol</strong> (17)</p></dt>
<dt><p><strong>ESCON</strong> (18)</p></dt>
<dt><p><strong>Diagnostic</strong> (19)</p></dt>
<dt><p><strong>I2C</strong> (20)</p></dt>
<dt><p><strong>Power</strong> (21)</p></dt>
<dt><p><strong>HIPPI</strong> (22)</p></dt>
<dt><p><strong>MultiBus</strong> (23)</p></dt>
<dt><p><strong>VME</strong> (24)</p></dt>
<dt><p><strong>IPI</strong> (25)</p></dt>
<dt><p><strong>IEEE-488</strong> (26)</p></dt>
<dt><p><strong>RS232</strong> (27)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE5</strong> (28)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE2</strong> (29)</p></dt>
<dt><p><strong>IEEE 802.3 1BASE5</strong> (30)</p></dt>
<dt><p><strong>IEEE 802.3 10BROAD36</strong> (31)</p></dt>
<dt><p><strong>IEEE 802.3 100BASEVG</strong> (32)</p></dt>
<dt><p><strong>IEEE 802.5 Token-Ring</strong> (33)</p></dt>
<dt><p><strong>ANSI X3T9.5 FDDI</strong> (34)</p></dt>
<dt><p><strong>MCA</strong> (35)</p></dt>
<dt><p><strong>ESDI</strong> (36)</p></dt>
<dt><p><strong>IDE</strong> (37)</p></dt>
<dt><p><strong>CMD</strong> (38)</p></dt>
<dt><p><strong>ST506</strong> (39)</p></dt>
<dt><p><strong>DSSI</strong> (40)</p></dt>
<dt><p><strong>QIC2</strong> (41)</p></dt>
<dt><p><strong>Enhanced ATA/IDE</strong> (42)</p></dt>
<dt><p><strong>AGP</strong> (43)</p></dt>
<dt><p><strong>TWIRP (two-way infrared)</strong> (44)</p></dt>
<dt><p><strong>FIR (fast infrared)</strong> (45)</p></dt>
<dt><p><strong>SIR (serial infrared)</strong> (46)</p></dt>
<dt><p><strong>IrBus</strong> (47)</p></dt>
</dl>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value for the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the controller was last reset. This could mean the controller was powered down, or reinitialized.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394166(v=vs.85).aspx
KEYBOARD = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394166(v=vs.85).aspx" />
    <title>Win32_Keyboard class (Windows)</title>
<h3> Keyboard</h3>
<p>The <strong>Win32_Keyboard</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Address or other identifying information to uniquely name the logical device.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and   corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>IsLocked</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is locked, preventing user input or output.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Layout</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string indicating the layout of the keyboard.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>NumberOfFunctionKeys</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of function keys on the keyboard.</p>
</dd>
<dt><strong>Password</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Status of hardware-level password enabled at the keyboard (value=4), preventing local input.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Disabled</strong> (3)</p></dt>
<dt><p><strong>Enabled</strong> (4)</p></dt>
<dt><p><strong>Not Implemented</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394204(v=vs.85).aspx
MOTHERBOARDDEVICE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394204(v=vs.85).aspx" />
    <title>Win32_MotherboardDevice class (Windows)</title>
<h3> Motherboard Device</h3>
<p>The <strong>Win32_MotherboardDevice</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of this motherboard.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>PrimaryBusType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Primary bus type of the motherboard.</p>
<p>Example: "PCI"</p>
</dd>
<dt><strong>RevisionNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Revision number of the motherboard.</p>
<p>Example: "00"</p>
</dd>
<dt><strong>SecondaryBusType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Secondary bus type of the motherboard.</p>
<p>Example: "ISA"</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394216(v=vs.85).aspx
NETWORKADAPTER = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394216(v=vs.85).aspx" />
    <title>Win32_NetworkAdapter class (Windows)</title>
<h3> Network Adapter</h3>
<p>The <strong>Win32_NetworkAdapter</strong> class has these properties.</p>
<dl>
<dt><strong>AdapterType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Network medium in use.

     The network adapters are as follows:</p>
<dl class="indent">
<dt><p><strong>Ethernet 802.3</strong> ("Ethernet 802.3")</p></dt>
<dt><p><strong>Token Ring 802.5</strong> ("Token Ring 802.5")</p></dt>
<dt><p><strong>Fiber Distributed Data Interface (FDDI)</strong> ("Fiber Distributed Data Interface (FDDI)")</p></dt>
<dt><p><strong>Wide Area Network (WAN)</strong> ("Wide Area Network (WAN)")</p></dt>
<dt><p><strong>LocalTalk</strong> ("LocalTalk")</p></dt>
<dt><p><strong>Ethernet using DIX header format</strong> ("Ethernet using DIX header format")</p></dt>
<dt><p><strong>ARCNET</strong> ("ARCNET")</p></dt>
<dt><p><strong>ARCNET (878.2)</strong> ("ARCNET (878.2)")</p></dt>
<dt><p><strong>ATM</strong> ("ATM")</p></dt>
<dt><p><strong>Wireless</strong> ("Wireless")</p></dt>
<dt><p><strong>Infrared Wireless</strong> ("Infrared Wireless")</p></dt>
<dt><p><strong>Bpc</strong> ("Bpc")</p></dt>
<dt><p><strong>CoWan</strong> ("CoWan")</p></dt>
<dt><p><strong>1394</strong> ("1394")</p></dt>
</dl>
</dd>
<dt><strong>AdapterTypeID</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Network medium in use. Returns the same information as the <strong>AdapterType</strong> property, except that the information is in the form of an integer.</p>
<dl class="indent">
<dt><p><strong>Ethernet 802.3</strong> (0)</p></dt>
<dt><p><strong>Token Ring 802.5</strong> (1)</p></dt>
<dt><p><strong>Fiber Distributed Data Interface (FDDI)</strong> (2)</p></dt>
<dt><p><strong>Wide Area Network (WAN)</strong> (3)</p></dt>
<dt><p><strong>LocalTalk</strong> (4)</p></dt>
<dt><p><strong>Ethernet using DIX header format</strong> (5)</p></dt>
<dt><p><strong>ARCNET</strong> (6)</p></dt>
<dt><p><strong>ARCNET (878.2)</strong> (7)</p></dt>
<dt><p><strong>ATM</strong> (8)</p></dt>
<dt><p><strong>Wireless</strong> (9)</p></dt>
<dt><p><strong>Infrared Wireless</strong> (10)</p></dt>
<dt><p><strong>Bpc</strong> (11)</p></dt>
<dt><p><strong>CoWan</strong> (12)</p></dt>
<dt><p><strong>1394</strong> (13)</p></dt>
</dl>
</dd>
<dt><strong>AutoSense</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the network adapter can automatically determine the speed of the attached or network media.</p>
<p>This property has not been implemented yet. It returns a <strong>NULL</strong> value by default.</p>
</dd>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save state, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state, but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save state.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the network adapter from other devices on the system.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>GUID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Globally unique identifier for the connection.</p>
</dd>
<dt><strong>Index</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Index number of the network adapter, stored in the system registry.</p>
<p>Example: 0</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
<p>This property has not been implemented yet. It returns a <strong>NULL</strong> value by default.</p>
</dd>
<dt><strong>Installed</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the network adapter is installed in the system.</p>
</dd>
<dt><strong>InterfaceIndex</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>MACAddress</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Media access control address for this network adapter. A MAC address is a unique 48-bit number assigned to the network adapter by the manufacturer. It uniquely identifies this network adapter and is used for mapping TCP/IP network communications.</p>
<p></p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the network adapter's manufacturer.</p>
<p>Example: "3COM"</p>
</dd>
<dt><strong>MaxNumberControlled</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of directly addressable ports supported by this network adapter. A value of 0 (zero) should be used if the number is unknown.</p>
</dd>
<dt><strong>MaxSpeed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum speed, in bits per second, for the network adapter.</p>
<p>This property has not been implemented yet. It returns a <strong>NULL</strong> value by default.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>NetConnectionID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Name of the network connection as it appears in the <strong>Network Connections</strong> Control Panel program.</p>
</dd>
<dt><strong>NetConnectionStatus</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the network adapter connection to the network.</p>
<dl class="indent">
<dt><p><strong>Disconnected</strong> (0)</p></dt>
<dt><p><strong>Connecting</strong> (1)</p></dt>
<dt><p><strong>Connected</strong> (2)</p></dt>
<dt><p><strong>Disconnecting</strong> (3)</p></dt>
<dt><p><strong>Hardware Not Present</strong> (4)</p></dt>
<dt><p><strong>Hardware Disabled</strong> (5)</p></dt>
<dt><p><strong>Hardware Malfunction</strong> (6)</p></dt>
<dt><p><strong>Media Disconnected</strong> (7)</p></dt>
<dt><p><strong>Authenticating</strong> (8)</p></dt>
<dt><p><strong>Authentication Succeeded</strong> (9)</p></dt>
<dt><p><strong>Authentication Failed</strong> (10)</p></dt>
<dt><p><strong>Invalid Address</strong> (11)</p></dt>
<dt><p><strong>Credentials Required</strong> (12)</p></dt>
<dt><p><strong>Other</strong></p></dt>
<dd>13–65535</dd>
</dl>
</dd>
<dt><strong>NetEnabled</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>NetworkAddresses</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of network addresses for an adapter.</p>
<p>This property has not been implemented yet. It returns a <strong>NULL</strong> value by default.</p>
</dd>
<dt><strong>PermanentAddress</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Network address hard-coded into an adapter. This hard-coded address may be changed by firmware upgrade or software configuration. If so, this field should be updated when the change is made. The property should be left blank if no hard-coded address exists for the network adapter.</p>
<p>This property has not been implemented yet. It returns a <strong>NULL</strong> value by default.</p>
</dd>
<dt><strong>PhysicalAdapter</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Indicates whether the adapter is a physical or a logical adapter. If <strong>True</strong>, the adapter is physical.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <a href="https://msdn.microsoft.com/en-us/library/aa387884(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CIM_LogicalDevice</strong></a> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProductName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Product name of the network adapter.</p>
<p>Example: "Fast EtherLink XL"</p>
</dd>
<dt><strong>ServiceName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Service name of the network adapter. This name is usually shorter than the full product name.</p>
<p>Example: "Elnkii"</p>
</dd>
<dt><strong>Speed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Estimate of the current bandwidth in bits per second. For endpoints which vary in bandwidth or for those where no accurate estimation can be made, this property should contain the nominal bandwidth.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the network adapter was last reset.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394238(v=vs.85).aspx
ONBOARDDEVICE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394238(v=vs.85).aspx" />
    <title>Win32_OnBoardDevice class (Windows)</title>
<h3> On Board Device</h3>
<p>The <strong>Win32_OnBoardDevice</strong> class has these properties.</p>
<dl>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of device being represented.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Video</strong> (3)</p></dt>
<dt><p><strong>SCSI Controller</strong> (4)</p></dt>
<dt><p><strong>Ethernet</strong> (5)</p></dt>
<dt><p><strong>Token Ring</strong> (6)</p></dt>
<dt><p><strong>Sound</strong> (7)</p></dt>
</dl>
</dd>
<dt><strong>Enabled</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the on-board device is available for use.</p>
</dd>
<dt><strong>HotSwappable</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, a physical package can be hot-swapped (if it is possible to replace the element with a physically different but equivalent one while the containing package has power applied to it). For example, a disk drive package inserted using SCA connectors is removable and can be hot-swapped. All packages that can be hot-swapped are inherently removable and replaceable.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the organization responsible for producing the physical element.</p>
</dd>
<dt><strong>Model</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name by which the physical element is generally known.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>OtherIdentifyingInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Additional data, beyond asset tag information, that could be used to identify a physical element. One example is bar code data associated with an element that also has an asset tag. Note that if only bar code data is available and is unique or able to be used as an element key, this property would be <strong>NULL</strong> and the bar code data is used as the class key in the tag property.</p>
</dd>
<dt><strong>PartNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Part number assigned by the organization responsible for producing or manufacturing the physical element.</p>
</dd>
<dt><strong>PoweredOn</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the physical element is powered on.</p>
</dd>
<dt><strong>Removable</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, a physical package is removable (if it is designed to be taken in and out of the physical container in which it is normally found, without impairing the function of the overall packaging). A package can still be removable if power must be "off" to perform the removal. If power can be "on" and the package removed, then the element is removable and can be hot-swapped. For example, an extra battery in a laptop is removable, as is a disk drive package inserted using SCA connectors. However, the latter can be hot-swapped. A laptop's display is not removable, nor is a nonredundant power supply. Removing these components would affect the function of the overall packaging or is impossible due to the tight integration of the package.</p>
</dd>
<dt><strong>Replaceable</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, a physical package is replaceable (if it is possible to replace, FRU or upgrade, the element with a physically different one). For example, some computer systems allow the main processor chip to be upgraded to one of a higher clock rating. In this case, the processor is said to be replaceable. Another example is a power supply package mounted on sliding rails. All removable packages are inherently replaceable.</p>
</dd>
<dt><strong>SerialNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer-allocated number used to identify the physical element.</p>
</dd>
<dt><strong>SKU</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Stock-keeping unit number for the physical element.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>Tag</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the on-board device connected to the system.</p>
<p>Example: "On Board Device 1"</p>
</dd>
<dt><strong>Version</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Version of the physical element.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394251(v=vs.85).aspx
PCMCIACONTROLLER = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394251(v=vs.85).aspx" />
    <title>Win32_PCMCIAController class (Windows)</title>
<h3>PCMCIA Controller</h3>
<p>The <strong>Win32_PCMCIAController</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>Paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>Not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>Not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>Quiesced.</p>
<p>The PCMCIA controller is unavailable.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information on any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the PCMCIA controller manufacturer.</p>
<p>Example: "Acme"</p>
</dd>
<dt><strong>MaxNumberControlled</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProtocolSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Protocol used by the controller to access "controlled" devices.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>EISA</strong> (3)</p></dt>
<dt><p><strong>ISA</strong> (4)</p></dt>
<dt><p><strong>PCI</strong> (5)</p></dt>
<dt><p><strong>ATA/ATAPI</strong> (6)</p></dt>
<dt><p><strong>Flexible Diskette</strong> (7)</p></dt>
<dt><p><strong>1496</strong> (8)</p></dt>
<dt><p><strong>SCSI Parallel Interface</strong> (9)</p></dt>
<dt><p><strong>SCSI Fibre Channel Protocol</strong> (10)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol</strong> (11)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol-2 (1394)</strong> (12)</p></dt>
<dt><p><strong>SCSI Serial Storage Architecture</strong> (13)</p></dt>
<dt><p><strong>VESA</strong> (14)</p></dt>
<dt><p><strong>PCMCIA</strong> (15)</p></dt>
<dt><p><strong>Universal Serial Bus</strong> (16)</p></dt>
<dt><p><strong>Parallel Protocol</strong> (17)</p></dt>
<dt><p><strong>ESCON</strong> (18)</p></dt>
<dt><p><strong>Diagnostic</strong> (19)</p></dt>
<dt><p><strong>I2C</strong> (20)</p></dt>
<dt><p><strong>Power</strong> (21)</p></dt>
<dt><p><strong>HIPPI</strong> (22)</p></dt>
<dt><p><strong>MultiBus</strong> (23)</p></dt>
<dt><p><strong>VME</strong> (24)</p></dt>
<dt><p><strong>IPI</strong> (25)</p></dt>
<dt><p><strong>IEEE-488</strong> (26)</p></dt>
<dt><p><strong>RS232</strong> (27)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE5</strong> (28)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE2</strong> (29)</p></dt>
<dt><p><strong>IEEE 802.3 1BASE5</strong> (30)</p></dt>
<dt><p><strong>IEEE 802.3 10BROAD36</strong> (31)</p></dt>
<dt><p><strong>IEEE 802.3 100BASEVG</strong> (32)</p></dt>
<dt><p><strong>IEEE 802.5 Token-Ring</strong> (33)</p></dt>
<dt><p><strong>ANSI X3T9.5 FDDI</strong> (34)</p></dt>
<dt><p><strong>MCA</strong> (35)</p></dt>
<dt><p><strong>ESDI</strong> (36)</p></dt>
<dt><p><strong>IDE</strong> (37)</p></dt>
<dt><p><strong>CMD</strong> (38)</p></dt>
<dt><p><strong>ST506</strong> (39)</p></dt>
<dt><p><strong>DSSI</strong> (40)</p></dt>
<dt><p><strong>QIC2</strong> (41)</p></dt>
<dt><p><strong>Enhanced ATA/IDE</strong> (42)</p></dt>
<dt><p><strong>AGP</strong> (43)</p></dt>
<dt><p><strong>TWIRP (two-way infrared)</strong> (44)</p></dt>
<dt><p><strong>FIR (fast infrared)</strong> (45)</p></dt>
<dt><p><strong>SIR (serial infrared)</strong> (46)</p></dt>
<dt><p><strong>IrBus</strong> (47)</p></dt>
</dl>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the controller was last reset. This could mean the controller was powered down or reinitialized.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394360(v=vs.85).aspx
POTSMODEM = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394360(v=vs.85).aspx" />
    <title>Win32_POTSModem class (Windows)</title>
<h3>POTS Modem</h3>
<p>The <strong>Win32_POTSModem</strong> class has these properties.</p>
<dl>
<dt><strong>AnswerMode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current auto-answer or callback setting for the modem.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Manual Answer</strong> (3)</p></dt>
<dt><p><strong>Auto Answer</strong> (4)</p></dt>
<dt><p><strong>Auto Answer with Call-Back</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>AttachedTo</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Port to which the POTS modem is attached.</p>
<p>Example: "COM1"</p>
</dd>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>BlindOff</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to detect a dial tone before dialing.</p>
<p>Example: "X4"</p>
</dd>
<dt><strong>BlindOn</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to dial whether or not there is a dial tone.</p>
<p>Example: "X3"</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>CompatibilityFlags</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>All modem connection protocols with which this modem device is compatible.</p>
</dd>
<dt><strong>CompressionInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Data compression characteristics of the modem.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dd><p>Unknown</p></dd>
<dt><p><strong>No Compression</strong> (2)</p></dt>
<dd><p>Other</p></dd>
<dt><p><strong>MNP 5</strong> (3)</p></dt>
<dd><p>No Compression</p></dd>
<dt><p><strong>V.42bis</strong> (4)</p></dt>
<dd><p>MNP 5</p></dd>
<dt><p><strong>5</strong></p></dt>
<dd><p>V.42bis</p></dd>
</dl>
</dd>
<dt><strong>CompressionOff</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to disable hardware data compression.</p>
<p>Example: "S46=136"</p>
</dd>
<dt><strong>CompressionOn</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to enable hardware data compression.</p>
<p>Example: "S46=138"</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>ConfigurationDialog</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Modem initialization string. This property is made up of command strings from other properties of this class.</p>
</dd>
<dt><strong>CountriesSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of countries/regions in which the modem can operate.</p>
</dd>
<dt><strong>CountrySelected</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Country/region for which the modem is currently programmed. When multiple countries/regions are supported, this property defines which one is currently selected for use.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>CurrentPasswords</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>List of currently defined passwords for the modem. This array may be left blank for security reasons.</p>
</dd>
<dt><strong>DCB</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Control settings for a serial communications device, in this case, the modem device.</p>
</dd>
<dt><strong>Default</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, this POTS modem is the default modem on the  computer system running Windows.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of this POTS modem from other devices on the system.</p>
</dd>
<dt><strong>DeviceLoader</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the device loader for the modem. A device loader loads and manages device drivers and enumerators for a given device.</p>
</dd>
<dt><strong>DeviceType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Physical type of the modem.</p>
<p>The values are:</p>
<dl>
<dd>"Null Modem"</dd>
<dd>"Internal Modem"</dd>
<dd>"External Modem"</dd>
<dd>"PCMCIA Modem"</dd>
<dd>"Unknown"</dd>
</dl>
<dl class="indent">
<dt><p><strong>Null Modem</strong> ("Null Modem")</p></dt>
<dt><p><strong>Internal Modem</strong> ("Internal Modem")</p></dt>
<dt><p><strong>External Modem</strong> ("External Modem")</p></dt>
<dt><p><strong>PCMCIA Modem</strong> ("PCMCIA Modem")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
</dl>
</dd>
<dt><strong>DialType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of dialing method used.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Tone</strong> (1)</p></dt>
<dt><p><strong>Pulse</strong> (2)</p></dt>
</dl>
</dd>
<dt><strong>DriverDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date of the modem driver.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorControlForced</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to enable error correction control when establishing a connection. This increases the reliability of the connection.</p>
<p>Example: "+Q5S36=4S48=7"</p>
</dd>
<dt><strong>ErrorControlInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Error correction characteristics of the modem.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>No Error Correction</strong> (2)</p></dt>
<dt><p><strong>MNP 4</strong> (3)</p></dt>
<dt><p><strong>LAPM</strong> (4)</p></dt>
</dl>
</dd>
<dt><strong>ErrorControlOff</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to disable error control.</p>
<p>Example: "+Q6S36=3S48=128"</p>
</dd>
<dt><strong>ErrorControlOn</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to enable error control.</p>
<p>Example: "+Q5S36=7S48=7"</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information on any corrective actions that may be taken.</p>
</dd>
<dt><strong>FlowControlHard</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to enable hardware flow control. Flow control consists of signals sent between computers that verify that both computers are ready to transmit or receive data.</p>
<p>Example: "&amp;K1"</p>
</dd>
<dt><strong>FlowControlOff</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to disable flow control. Flow control consists of signals sent between computers that verify that both computers are ready to transmit or receive data.</p>
<p>Example: "&amp;K0"</p>
</dd>
<dt><strong>FlowControlSoft</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to enable software flow control. Flow control consists of signals sent between computers that verify that both computers are ready to transmit or receive data.</p>
<p>Example: "&amp;K2"</p>
</dd>
<dt><strong>InactivityScale</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Multiplier used with the <strong>InactivityTimeout</strong> property to calculate the timeout period of a connection.</p>
</dd>
<dt><strong>InactivityTimeout</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Time limit (in seconds) for automatic disconnection of the phone line, if no data is exchanged. A value of 0 (zero) indicates that this feature is present but not enabled.</p>
</dd>
<dt><strong>Index</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Index number for this POTS modem.</p>
<p>Example: 0</p>
</dd>
<dt><strong>IndexEx</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The device instance ID for this POTS modem.</p>
<p>Example: "1&amp;08"</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is available beginning with Windows Server 2016 Technical Preview and Windows 10.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>MaxBaudRateToPhone</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum settable communication speed for accessing the phone system.</p>
</dd>
<dt><strong>MaxBaudRateToSerialPort</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum settable communication speed to the COM port for an external modem. Enter 0 (zero) if not applicable.</p>
</dd>
<dt><strong>MaxNumberOfPasswords</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of passwords definable in the modem itself. If this feature is not supported, enter 0 (zero).</p>
</dd>
<dt><strong>Model</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Model of this POTS modem.</p>
<p>Example: "Sportster 56K External"</p>
</dd>
<dt><strong>ModemInfPath</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Path to this modem's .inf file. This file contains initialization information for the modem and its driver.</p>
<p>Example: "C:\Windows\INF"</p>
</dd>
<dt><strong>ModemInfSection</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the section in the modem's .inf file that contains information about the modem.</p>
</dd>
<dt><strong>ModulationBell</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to instruct the modem to use Bell modulations for 300 and 1200 bps.</p>
<p>Example: "B1"</p>
</dd>
<dt><strong>ModulationCCITT</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to instruct the modem to use CCITT modulations for 300 and 1200 bps.</p>
<p>Example: "B0"</p>
</dd>
<dt><strong>ModulationScheme</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Modulation scheme of the modem.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Not Supported</strong> (2)</p></dt>
<dt><p><strong>Bell 103</strong> (3)</p></dt>
<dt><p><strong>Bell 212A</strong> (4)</p></dt>
<dt><p><strong>V.22bis</strong> (5)</p></dt>
<dt><p><strong>V.32</strong> (6)</p></dt>
<dt><p><strong>V.32bis</strong> (7)</p></dt>
<dt><p><strong>V.turbo</strong> (8)</p></dt>
<dt><p><strong>V.FC</strong> (9)</p></dt>
<dt><p><strong>V.34</strong> (10)</p></dt>
<dt><p><strong>V.34bis</strong> (11)</p></dt>
</dl>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PortSubClass</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Definition of the port used for this modem.</p>
<dl class="indent">
<dt><p><strong></strong> ("00")</p></dt>
<dd><p>Parallel Port</p></dd>
<dt><p><strong></strong> ("01")</p></dt>
<dd><p>Serial Port</p></dd>
<dt><p><strong></strong> ("02")</p></dt>
<dd><p>Modem</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>Prefix</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Dialing prefix used to access an outside line.</p>
</dd>
<dt><strong>Properties</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>List of all the properties (and their values) for this modem.</p>
</dd>
<dt><strong>ProviderName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Network path to the computer that provides the modem services.</p>
</dd>
<dt><strong>Pulse</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to instruct the modem to use pulse mode for dialing. Pulse dialing is necessary for phone lines that are unable to handle tone dialing.</p>
<p>Example: "P"</p>
</dd>
<dt><strong>Reset</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to reset the modem for the next call.</p>
<p>Example: "AT&amp;F"</p>
</dd>
<dt><strong>ResponsesKeyName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Response this modem might report to the operating system during the connection process. The first two characters specify the type of response. The second two characters specify information about the connection being made. The second two characters are used only for Negotiation Progress or Connect response codes. The next eight characters specify the modem-to-modem line speed negotiated in bits per second (bps). The characters represent a 32-bit unsigned long integer format (byte and word reversed). The last eight characters indicate that the modem is changing to a different port or Data Terminal Equipment (DTE) speed. Usually this field is not used because modems make connections at a locked port speed regardless of the modem-to-modem or Data Communications Equipment (DCE) speed.</p>
</dd>
<dt><strong>RingsBeforeAnswer</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of rings before the modem answers an incoming call.</p>
</dd>
<dt><strong>SpeakerModeDial</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to turn the modem speaker on after dialing a number, and turning the speaker off when a connection has been established.</p>
<p>Example: "M1"</p>
</dd>
<dt><strong>SpeakerModeOff</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to turn the modem speaker off.</p>
<p>Example: "M0"</p>
</dd>
<dt><strong>SpeakerModeOn</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to turn the modem speaker on.</p>
<p>Example: "M2"</p>
</dd>
<dt><strong>SpeakerModeSetup</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to instruct the modem to turn the speaker on (until a connection is established).</p>
<p>Example: "M3"</p>
</dd>
<dt><strong>SpeakerVolumeHigh</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to set the modem speaker to the highest volume.</p>
<p>Example: "L3"</p>
</dd>
<dt><strong>SpeakerVolumeInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Describes the volume level of the audible tones from the modem.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Not Supported</strong> (2)</p></dt>
<dt><p><strong>High</strong> (3)</p></dt>
<dt><p><strong>Medium</strong> (4)</p></dt>
<dt><p><strong>Low</strong> (5)</p></dt>
<dt><p><strong>Off</strong> (6)</p></dt>
<dt><p><strong>Auto</strong> (7)</p></dt>
</dl>
</dd>
<dt><strong>SpeakerVolumeLow</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to set the modem speaker to the lowest volume.</p>
<p>Example: "L1"</p>
</dd>
<dt><strong>SpeakerVolumeMed</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string used to set the modem speaker to a medium volume.</p>
<p>Example: "L2"</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>StringFormat</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of characters used for text passed through the modem.</p>
<p>The values are:</p>
<dl>
<dd>"ASCII string format"</dd>
<dd>"DBCS string format"</dd>
<dd>"UNICODE string format"</dd>
</dl>
<dl class="indent">
<dt><p><strong>ASCII string format</strong> ("ASCII string format")</p></dt>
<dt><p><strong>DBCS string format</strong> ("DBCS string format")</p></dt>
<dt><p><strong>UNICODE string format</strong> ("UNICODE string format")</p></dt>
</dl>
</dd>
<dt><strong>SupportsCallback</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the modem supports callback.</p>
</dd>
<dt><strong>SupportsSynchronousConnect</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, synchronous, as well as asynchronous, communication is supported.</p>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>Terminator</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>String that marks the end of a command string.</p>
<p>Example: "&lt;cr"</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the modem was last reset.</p>
</dd>
<dt><strong>Tone</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command string that instructs the modem to use tone mode for dialing. The phone line must support tone dialing.</p>
<p>Example: "T"</p>
</dd>
<dt><strong>VoiceSwitchFeature</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Command strings used to activate the voice capabilities of a voice modem.</p>
<p>Example: "AT+V"</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394247(v=vs.85).aspx
PARALLELPORT = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394247(v=vs.85).aspx" />
    <title>Win32_ParallelPort class (Windows)</title>
<h3> Parallel Port</h3>
<p>The <strong>Win32_ParallelPort</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Capabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the capabilities of the parallel controller.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>XT/AT Compatible</strong> (2)</p></dt>
<dt><p><strong>PS/2 Compatible</strong> (3)</p></dt>
<dt><p><strong>ECP</strong> (4)</p></dt>
<dt><p><strong>EPP</strong> (5)</p></dt>
<dt><p><strong>PC-98</strong> (6)</p></dt>
<dt><p><strong>PC-98-Hireso</strong> (7)</p></dt>
<dt><p><strong>PC-H98</strong> (8)</p></dt>
</dl>
</dd>
<dt><strong>CapabilityDescriptions</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of more detailed explanations for any of the parallel controller features indicated in the <strong>Capabilities</strong> array. Each entry of this array is related to the entry in the <strong>Capabilities</strong> array that is located at the same index.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Identifier of the parallel port.</p>
</dd>
<dt><strong>DMASupport</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the parallel port supports DMA.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is  cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information about  corrective actions that might be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>MaxNumberControlled</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>OSAutoDiscovered</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the parallel port was automatically detected by the operating system. If <strong>FALSE</strong>, the port was detected by other means (such as being manually added through the Control Panel).</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed, which means that it can be put into suspend mode, and so on. The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProtocolSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Protocol used by the controller to access "controlled" devices.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>EISA</strong> (3)</p></dt>
<dt><p><strong>ISA</strong> (4)</p></dt>
<dt><p><strong>PCI</strong> (5)</p></dt>
<dt><p><strong>ATA/ATAPI</strong> (6)</p></dt>
<dt><p><strong>Flexible Diskette</strong> (7)</p></dt>
<dt><p><strong>1496</strong> (8)</p></dt>
<dt><p><strong>SCSI Parallel Interface</strong> (9)</p></dt>
<dt><p><strong>SCSI Fibre Channel Protocol</strong> (10)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol</strong> (11)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol-2 (1394)</strong> (12)</p></dt>
<dt><p><strong>SCSI Serial Storage Architecture</strong> (13)</p></dt>
<dt><p><strong>VESA</strong> (14)</p></dt>
<dt><p><strong>PCMCIA</strong> (15)</p></dt>
<dt><p><strong>Universal Serial Bus</strong> (16)</p></dt>
<dt><p><strong>Parallel Protocol</strong> (17)</p></dt>
<dt><p><strong>ESCON</strong> (18)</p></dt>
<dt><p><strong>Diagnostic</strong> (19)</p></dt>
<dt><p><strong>I2C</strong> (20)</p></dt>
<dt><p><strong>Power</strong> (21)</p></dt>
<dt><p><strong>HIPPI</strong> (22)</p></dt>
<dt><p><strong>MultiBus</strong> (23)</p></dt>
<dt><p><strong>VME</strong> (24)</p></dt>
<dt><p><strong>IPI</strong> (25)</p></dt>
<dt><p><strong>IEEE-488</strong> (26)</p></dt>
<dt><p><strong>RS232</strong> (27)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE5</strong> (28)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE2</strong> (29)</p></dt>
<dt><p><strong>IEEE 802.3 1BASE5</strong> (30)</p></dt>
<dt><p><strong>IEEE 802.3 10BROAD36</strong> (31)</p></dt>
<dt><p><strong>IEEE 802.3 100BASEVG</strong> (32)</p></dt>
<dt><p><strong>IEEE 802.5 Token-Ring</strong> (33)</p></dt>
<dt><p><strong>ANSI X3T9.5 FDDI</strong> (34)</p></dt>
<dt><p><strong>MCA</strong> (35)</p></dt>
<dt><p><strong>ESDI</strong> (36)</p></dt>
<dt><p><strong>IDE</strong> (37)</p></dt>
<dt><p><strong>CMD</strong> (38)</p></dt>
<dt><p><strong>ST506</strong> (39)</p></dt>
<dt><p><strong>DSSI</strong> (40)</p></dt>
<dt><p><strong>QIC2</strong> (41)</p></dt>
<dt><p><strong>Enhanced ATA/IDE</strong> (42)</p></dt>
<dt><p><strong>AGP</strong> (43)</p></dt>
<dt><p><strong>TWIRP (two-way infrared)</strong> (44)</p></dt>
<dt><p><strong>FIR (fast infrared)</strong> (45)</p></dt>
<dt><p><strong>SIR (serial infrared)</strong> (46)</p></dt>
<dt><p><strong>IrBus</strong> (47)</p></dt>
</dl>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the controller was last reset. This could mean the controller was powered down or reinitialized.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394346(v=vs.85).aspx
PHYSICALMEDIA = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394346(v=vs.85).aspx" />
    <title>Win32_PhysicalMedia class (Windows)</title>
<h3> Physical Media</h3>
<p>The <strong>Win32_PhysicalMedia</strong> class has these properties.</p>
<dl>
<dt><strong>Capacity</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of bytes that can be read from or written to this physical media component. This property does not apply to "Hard Copy" or cleaner media. Data compression should not be assumed as it would increase the value of this property. For tapes, it should be assumed that no filemarks or blank space areas are recorded on the media.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short, one-line textual description of the object.</p>
</dd>
<dt><strong>CleanerMedia</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the physical media is used for cleaning purposes and not data storage.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the class or subclass used in the creation of an instance. When used with other key properties of this class, <strong>CreationClassName</strong> allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Textual description of the object.</p>
</dd>
<dt><strong>HotSwappable</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, this physical media component can be replaced with a physically different but equivalent one while the containing package has the power applied. For example, a fan component may be designed to be hot-swapped. All components that can be hot-swapped are inherently removable and replaceable.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>When the object was installed. This property does not require a value to indicate that the object is installed.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the organization responsible for producing the physical element. This can be the entity from whom the element is purchased, but this is not necessarily the case as this information is contained in the <strong>Vendor</strong> property.</p>
</dd>
<dt><strong>MediaDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Additional detail related to the <strong>MediaType</strong> property. For example, if <strong>MediaType</strong> has the value 3 (QIC Cartridge) the <strong>MediaDescription</strong> property can indicate whether the tape is wide or quarter inch.</p>
</dd>
<dt><strong>MediaType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The type of the media, as an enumerated integer. The <strong>MediaDescription</strong> property provides a more explicit definition of the media type.</p>
<p>
</p><p>The following list lists the possible values.</p>

<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Tape Cartridge</strong> (2)</p></dt>
<dt><p><strong>QIC Cartridge</strong> (3)</p></dt>
<dt><p><strong>AIT Cartridge</strong> (4)</p></dt>
<dt><p><strong>DTF Cartridge</strong> (5)</p></dt>
<dt><p><strong>DAT Cartridge</strong> (6)</p></dt>
<dt><p><strong>8mm Tape Cartridge</strong> (7)</p></dt>
<dt><p><strong>19mm Tape Cartridge</strong> (8)</p></dt>
<dt><p><strong>DLT Cartridge</strong> (9)</p></dt>
<dt><p><strong>Half-Inch Magnetic Tape Cartridge</strong> (10)</p></dt>
<dt><p><strong>Cartridge Disk</strong> (11)</p></dt>
<dt><p><strong>JAZ Disk</strong> (12)</p></dt>
<dt><p><strong>ZIP Disk</strong> (13)</p></dt>
<dt><p><strong>SyQuest Disk</strong> (14)</p></dt>
<dt><p><strong>Winchester Removable Disk</strong> (15)</p></dt>
<dt><p><strong>CD-ROM</strong> (16)</p></dt>
<dd><p>CD ROM</p></dd>
<dt><p><strong>CD-ROM/XA</strong> (17)</p></dt>
<dd><p>CD ROM/XA</p></dd>
<dt><p><strong>CD-I</strong> (18)</p></dt>
<dt><p><strong>CD Recordable</strong> (19)</p></dt>
<dt><p><strong>WORM</strong> (20)</p></dt>
<dt><p><strong>Magneto-Optical</strong> (21)</p></dt>
<dt><p><strong>DVD</strong> (22)</p></dt>
<dt><p><strong>DVD+RW</strong> (23)</p></dt>
<dt><p><strong>DVD-RAM</strong> (24)</p></dt>
<dt><p><strong>DVD-ROM</strong> (25)</p></dt>
<dt><p><strong>DVD-Video</strong> (26)</p></dt>
<dt><p><strong>Divx</strong> (27)</p></dt>
<dt><p><strong>Floppy/Diskette</strong> (28)</p></dt>
<dt><p><strong>Hard Disk</strong> (29)</p></dt>
<dt><p><strong>Memory Card</strong> (30)</p></dt>
<dt><p><strong>Hard Copy</strong> (31)</p></dt>
<dt><p><strong>Clik Disk</strong> (32)</p></dt>
<dt><p><strong>CD-RW</strong> (33)</p></dt>
<dt><p><strong>CD-DA</strong> (34)</p></dt>
<dt><p><strong>CD+</strong> (35)</p></dt>
<dt><p><strong>DVD Recordable</strong> (36)</p></dt>
<dt><p><strong>DVD-RW</strong> (37)</p></dt>
<dt><p><strong>DVD-Audio</strong> (38)</p></dt>
<dt><p><strong>DVD-5</strong> (39)</p></dt>
<dt><p><strong>DVD-9</strong> (40)</p></dt>
<dt><p><strong>DVD-10</strong> (41)</p></dt>
<dt><p><strong>DVD-18</strong> (42)</p></dt>
<dt><p><strong>Magneto-Optical Rewriteable</strong> (43)</p></dt>
<dt><p><strong>Magneto-Optical Write Once</strong> (44)</p></dt>
<dt><p><strong>Magneto-Optical Rewriteable (LIMDOW)</strong> (45)</p></dt>
<dt><p><strong>Phase Change Write Once</strong> (46)</p></dt>
<dt><p><strong>Phase Change Rewriteable</strong> (47)</p></dt>
<dt><p><strong>Phase Change Dual Rewriteable</strong> (48)</p></dt>
<dt><p><strong>Ablative Write Once</strong> (49)</p></dt>
<dt><p><strong>Near Field Recording</strong> (50)</p></dt>
<dt><p><strong>MiniQic</strong> (51)</p></dt>
<dt><p><strong>Travan</strong> (52)</p></dt>
<dt><p><strong>8mm Metal Particle</strong> (53)</p></dt>
<dt><p><strong>8mm Advanced Metal Evaporate</strong> (54)</p></dt>
<dt><p><strong>NCTP</strong> (55)</p></dt>
<dt><p><strong>LTO Ultrium</strong> (56)</p></dt>
<dt><p><strong>LTO Accelis</strong> (57)</p></dt>
<dt><p><strong>9 Track Tape</strong> (58)</p></dt>
<dt><p><strong>18 Track Tape</strong> (59)</p></dt>
<dt><p><strong>36 Track Tape</strong> (60)</p></dt>
<dt><p><strong>Magstar 3590</strong> (61)</p></dt>
<dt><p><strong>Magstar MP</strong> (62)</p></dt>
<dt><p><strong>D2 Tape</strong> (63)</p></dt>
<dt><p><strong>Tape - DST Small</strong> (64)</p></dt>
<dt><p><strong>Tape - DST Medium</strong> (65)</p></dt>
<dt><p><strong>Tape - DST Large</strong> (66)</p></dt>
</dl>
</dd>
<dt><strong>Model</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name by which the physical element is generally known.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>OtherIdentifyingInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Additional data, beyond asset tag information, that can be used to identify a physical element. One example is bar code data associated with an element that also has an asset tag. Note that if only bar code data is available, is unique, and  it can be used as an element key, this property is <strong>NULL</strong> and the bar code data used is the class key in the <strong>Tag</strong> property.</p>
</dd>
<dt><strong>PartNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Part number assigned by the manufacturer of the physical element.</p>
</dd>
<dt><strong>PoweredOn</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong> the physical element is powered on.</p>
</dd>
<dt><strong>Removable</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the physical component is designed to be taken in and out of the physical container in which it is normally found, without impairing the function of the overall packaging. A component can still be removable if the power must be "off" to perform the removal. If power can be "on" and the component removed, the element is removable and can be hot-swapped.</p>
</dd>
<dt><strong>Replaceable</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, this physical media component can be replaced  with a physically different one. For example, some computer systems allow the main processor chip to be upgraded to one of a higher clock rating. In this case, the processor is said to be replaceable. All removable components are inherently replaceable.</p>
</dd>
<dt><strong>SerialNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer-allocated number used to identify the physical media. The default value is <strong>NULL</strong>.</p>
<p>Example: WD-WM3493798728</p>
</dd>
<dt><strong>SKU</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Stock keeping unit number for this physical element.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses are "OK", "Degraded", and "Pred Fail". "Pred Fail" indicates that an element may  function properly at the present, but predicts a failure in the near future. For example, a SMART-enabled hard disk drive. Nonoperational statuses can also be specified.  These are, "Error", "Starting", "Stopping," and "Service". The "Service" status applies to administrative work, such as mirror-resilvering of a disk or reload of a user permissions list. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>The values are:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>Tag</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Uniquely identifies the physical media in the system.</p>
<p>Example: PHYSICALDRIVE0</p>
</dd>
<dt><strong>Version</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Version of the physical element.</p>
</dd>
<dt><strong>WriteProtectOn</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the media is currently write protected by some kind of physical mechanism, such as a protect tab on a floppy disk.</p>
</dd>
</dl>
<h2>Requirements</h2>
<table summary="table">
<tr><th scope="row">
<p>Minimum supported client</p>
</th><td>
<p>Windows Vista</p>
</td></tr>
<tr><th scope="row">
<p>Minimum supported server</p>
</th><td>
<p>Windows Server 2008</p>
</td></tr>
<tr><th scope="row">
<p>Namespace</p>
</th><td>
<p>Root\CIMV2</p>
</td></tr>
<tr><th scope="row">
<p>MOF</p>
</th><td>
<dl>
<dt>Wmipcima.mof</dt>
</dl>
</td></tr>
<tr><th scope="row">
<p>DLL</p>
</th><td>
<dl>
<dt>Wmipcima.dll</dt>
</dl>
</td></tr>
</table>
<h2>See also</h2>
<dl>
<dt></dt>
<dt></dt>
</dl>
<p> </p>
<p> </p>
</div>
</div>






<div class="libraryMemberFilter">
    <div class="filterContainer">
        <span>Show:</span>
        <label>
            <input type="checkbox" class="libraryFilterInherited" checked="checked" value="Inherit" />Inherited
        </label>
        <label>
            <input type="checkbox" class="libraryFilterProtected" checked="checked" value="Protected" />Protected
        </label>
    </div>
</div>

<input type="hidden" id="libraryMemberFilterEmptyWarning" value="There are no members available with your current filter settings." />



    </div>
<div id="rightNavigationMenu" ms.cmpgrp="right nav">
    <div id="mobileButtons">
        <div id="navigationButtons">

            <a id="isd_printABook" href="/en-us/library/export/help/?returnurl=%2fen-us%2flibrary%2faa394346(v%3dvs.85).aspx">
                <ins class="export"></ins>Export (<span class="count">0</span>)
            </a>
        </div>
    </div>
    <div id="navMain">
        <div id="closeNavigation">
            <a class="tocCloseSmall" id="closeButton"></a>
        </div>
        <div id="navigationButtons">

            <a id="isd_printABook2" href="/en-us/library/export/help/?returnurl=%2fen-us%2flibrary%2faa394346(v%3dvs.85).aspx">
                <ins class="export"></ins>Export (<span class="count">0</span>)
            </a>
            <a id="isdShare" href="#" role="button" aria-expanded="false">
                <ins class="share"></ins>Share
            </a>
            <div id="socials" style="display: none">
                <a class="isdFacebook" href="#" aria-label="Share on Facebook">
                    <ins class="facebook"></ins>
                </a>
                <a class="isdTwitter" href="#" aria-label="Share on Twitter">
                    <ins class="twitter"></ins>
                </a>
                <a class="isdGooglePlus" href="#" aria-label="Share on Google+">
                    <ins class="googlePlus"></ins>
                </a>
            </div>
        </div>
        <div id="indoc_toc" style="display: none" ms.cmpgrp="indoc toc">
            <div id="indoc_title">IN THIS ARTICLE</div>
            <ul id="indoc_toclist"></ul>
        </div>
    </div>
</div>
<div id="rightNavigationMenuThumbnail" class="rightNavigationMenuThumbnail">
</div>





        </div>
        <div class="clear"></div>



<input name="__RequestVerificationToken" type="hidden" value="OFDdh5ALYS93z4atXgokQ1VQ6fiot-qWXbTbw5W6PqaaWuRm7uQM57_lly8Rtsn6M_Uv6306P_69VPcVhoo_w0GfJW01" />
<input id="ratingValueSubmitUrl" type="hidden" value="https://msdn.microsoft.com/en-us/library/feedback/rate/aa394346(v=vs.85).aspx" />
<input id="ratingAdditionalSubmitUrl" type="hidden" value="https://msdn.microsoft.com/en-us/library/feedback/additional/aa394346(v=vs.85).aspx" />
<input id="isTopicRated" type="hidden" value="false" />




    <div id="lib-footer">



    <link type="text/css" rel="stylesheet" />


    <div id="ux-footer" class="" style="" dir="ltr" ms.pgarea="footer">


    <div id="standardRatingBefore" class="clear stdr-container-before"></div>
    <div id="standardRating" class="stdr-container" ms.pgarea="body">
        <div class="stdr-close"></div>
        <div class="stdr-vote stdr-content">
            <div class="stdr-content">
                <span class="stdr-votetitle">Is this page helpful?</span>
                <button class="stdr-yes" aria-label="Yes, this page was helpful">Yes</button>
                <button class="stdr-no" aria-label="No, this page was not helpful">No</button>
                <input id="s_ratingValue" type="hidden" value="" />
            </div>
        </div>
        <div class="stdr-feedback" style="display: none">
            <div class="stdr-form">
                <div class="stdr-fieldtitle">Additional feedback?</div>
                <textarea class="stdr-detail" rows="6" maxlength="1500"></textarea>
                <div>
                    <span class="stdr-count"><span class="stdr-charcnt">1500</span> characters remaining</span>
                    <div class="stdr-buttons">
                        <button class="stdr-provide" aria-label="Submit my additional feedback">Submit</button>
                        <button class="stdr-skip" aria-label="Skip additional feedback">Skip this</button>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="stdr-thanks" style="display: none">
            <div class="stdr-content">
                <span class="stdr-thankyou">Thank you!</span>
                <span class="stdr-appreciate">We appreciate your feedback.</span>
            </div>
        </div>


        <div id="contentFeedbackQAContainer" style="display: none;"></div>
    </div>
    <div id="standardRatingPlaceholder" style="display: none"></div>


        <footer class="top" role="navigation" aria-label="footer">
            <div data-fragmentName="LeftLinks" id="Fragment_LeftLinks" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <h4 class="linkListTitle">Dev centers</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            <div id="rightLinks">
                <div data-fragmentName="CenterLinks1" id="Fragment_CenterLinks1" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <h4 class="linkListTitle">Learning resources</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks2" id="Fragment_CenterLinks2" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <h4 class="linkListTitle">Community</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks3" id="Fragment_CenterLinks3" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <h4 class="linkListTitle">Support</h4>
    <ul class="links">
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks4" id="Fragment_CenterLinks4" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <h4 class="linkListTitle">Programs</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            </div>
        </footer>

        <footer class="bottom" role="contentinfo">
            <span class="localeContainer">

    <form class="selectLocale" id="selectLocaleForm" action="https://msdn.microsoft.com/en-us/selectlocale-dmc">
        <input type="hidden" name="fromPage" value="https%3a%2f%2fmsdn.microsoft.com%2fen-us%2flibrary%2faa394346(v%3dvs.85).aspx" />
    </form>


            </span>

            <div data-fragmentName="BottomLinks" id="Fragment_BottomLinks" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <ul class="links horizontal">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            <span class="logoLegal">
                <span class="logoSpan clip67x13" role="img" tabindex="0" aria-label="microsoft logo">
                    <img alt="logo" class="logo" src="https://i-msdn.sec.s-msft.com/Areas/Centers/Themes/StandardDevCenter/Content/HeaderFooterSprite.png?v=636221982560760644" />
                </span>
                <span class="copyright">© 2017 Microsoft</span>
            </span>
        </footer>
    </div>


    </div>


        <div class="footerPrintView">
            <div class="footerCopyrightPrintView">© 2017 Microsoft</div>
        </div>








    <input id="tocPaddingPerLevel" type="hidden" value="17" />



        <input id="MtpsDevice" type="hidden" value="Default" />


<![CDATA[ Third party scripts and code linked to or referenced from this website are licensed to you by the parties that own such code, not by Microsoft.  See ASP.NET Ajax CDN Terms of Use – http://www.asp.net/ajaxlibrary/CDN.ashx. ]]>







<![CDATA[ WebTrends view model not available or IncludeLegacyWebTrendsScriptInGlobal feature flag is off]]>




<div id="globalRequestVerification">
    <input name="__RequestVerificationToken" type="hidden" value="lGq3MlE2SC4hiDXe4FDv-1RYKUfZQBYtED6Q9_lrG2oEM9ZFAWF4OdPkNK-3ho1WWcgK1uksrhfjseJRQZBee_2rPnU1" />
</div>


    </div>







<script type="text/javascript" class="mtps-injected">
/*<![CDATA[*/
(function(window,document){"use strict";function preload(scripts){for(var result=[],script,e,i=0;i<scripts.length;i++)script=scripts[i],script.hasOwnProperty("url")&&(e=document.createElement("script"),e.src=script.url,script.throwaway=e),result.push(script);return result}function inject(scripts,index){var script,elem;if(index>=scripts.length){delete mtps.injectScripts;return}script=scripts[index];elem=document.createElement("script");elem.className="mtps-injected";elem.async=!1;var isLoaded=!1,timeoutId=0,injectNextFnName="",injectNext=elem.onerror=function(){isLoaded||(isLoaded=!0,inject(scripts,index+1),window.clearTimeout(timeoutId),elem.onload=elem.onerror=elem.onreadystatechange=null,injectNextFnName&&delete mtps[injectNextFnName],elem.removeEventListener&&elem.removeEventListener("load",injectNext,!1))};elem.addEventListener?elem.addEventListener("load",injectNext,!1):elem.readyState==="uninitialized"?elem.onreadystatechange=function(){(this.readyState==="loaded"||this.readyState==="complete")&&injectNext()}:elem.onload=injectNext;script.hasOwnProperty("url")?(timeoutId=window.setTimeout(injectNext,12e4),elem.src=script.url):(injectNextFnName="_injectNextScript_"+index,mtps[injectNextFnName]=injectNext,timeoutId=window.setTimeout(injectNext,2e3),elem.text="try {\n"+script.txt+"\n} finally { MTPS."+injectNextFnName+" && MTPS."+injectNextFnName+"(); }");parent.appendChild(elem)}var mtps=window.MTPS||(window.MTPS={}),parent=document.getElementsByTagName("head")[0];mtps.injectScripts=function(scripts){inject(preload(scripts),0)}})(window,document);
MTPS.injectScripts([
	{ txt: "/**/\r\n(window.MTPS || (window.MTPS = {})).cdnDomains || (window.MTPS.cdnDomains = { \r\n\t\"image\": \"https://i-msdn.sec.s-msft.com\", \r\n\t\"js\": \"https://i2-msdn.sec.s-msft.com\", \r\n\t\"css\": \"https://i-msdn.sec.s-msft.com\", \r\n\t\"ttf\": \"https://i-msdn.sec.s-msft.com\"\r\n});\r\n/**/" },
	{ txt: "//\n\n        window.appInsightsId = \u00275eb1b2eb-c47a-497a-a7ac-a1c230b2882f\u0027;\n        //" },
	{ url: "https://i2-msdn.sec.s-msft.com/Combined.js?resources=0:Utilities,1:Layout,2:Header,3:Breadcrumbs,4:LibraryRightNavigationMenu,4:PrintExportButton,5:StandardRating,2:Footer,0:Topic,3:ResponsiveSupport,0:AppInsightsPerf,3:ResponsiveToc,0:ABTestControl,4:WEDCS,3:CmpgrpForHeader,1:SearchBox;/Areas/Epx/Content/Scripts:0,/Areas/Epx/Themes/Base/Content:1,/Areas/Centers/Themes/StandardDevCenter/Content:2,/Areas/Library/Content:3,/Areas/Library/Themes/Base/Content:4,/Areas/Global/Content:5\u0026amp;hashKey=380CB181B38C487101990C8F514C8659\u0026amp;v=F314B163E8B6FD251181E3EA43E44BD3" },
	{ url: "https://i1.services.social.microsoft.com/search/Widgets/SearchBox.jss?boxid=HeaderSearchTextBox\u0026btnid=HeaderSearchButton\u0026minimumTermLength=2\u0026pgArea=header\u0026brand=Msdn\u0026loc=en-us\u0026focusOnInit=false\u0026emptyWatermark=true\u0026searchButtonTooltip=Search MSDN" },
	{ url: "https://i2-msdn.sec.s-msft.com/Combined.js?resources=0:JumpRedirect,1:LibraryMemberFilter,2:Toc_Fixed,2:CodeSnippet,2:TopicNotInScope,2:VersionSelector,2:SurveyBroker;/Areas/Epx/Themes/Base/Content:0,/Areas/Library/Content:1,/Areas/Epx/Content/Scripts:2\u0026amp;hashKey=8B88EB517137869CDE8F8A6DFD775854\u0026amp;v=F314B163E8B6FD251181E3EA43E44BD3" },
	{ txt: "$(document).ready(function() {\n        try {\n            var token = $(\"#globalRequestVerification input[name=\u0027__RequestVerificationToken\u0027]\").clone();\n            $(\"#siteFeedbackForm\").append(token);\n        } catch(err) {\n            \n        }\n    });" }
]);

/*]]>*/
</script></body>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394347(v=vs.85).aspx
PHYSICALMEMORY = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394347(v=vs.85).aspx" />
    <title>Win32_PhysicalMemory class (Windows)</title>
<h3> Physical Memory</h3>
<p>The <strong>Win32_PhysicalMemory</strong> class has these properties.</p>
<dl>
<dt><strong>Attributes</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SMBIOS - Type 17 - Attributes. Represents the RANK.</p>
<p>This value comes from the <strong>Attributes</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>BankLabel</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Physically labeled bank where the memory is located.</p>
<p>Examples: "Bank 0", "Bank A"</p>
<p>This value comes from the <strong>Bank Locator</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>Capacity</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Total capacity of the physical memory—in bytes.</p>
<p>This value comes from the <strong>Memory Device</strong> structure in the SMBIOS version
       information. For SMBIOS versions 2.1 thru 2.6 the value comes from the <strong>Size</strong> member.
       For SMBIOS version 2.7+ the value comes from the <strong>Extended Size</strong> member.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of the object—a one-line string.</p>
</dd>
<dt><strong>ConfiguredClockSpeed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The configured clock speed of the memory device, in megahertz (MHz), or 0, if the speed is unknown.</p>
<p>This value comes from the <strong>Configured Memory Clock Speed</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>ConfiguredVoltage</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Configured voltage for this device, in millivolts, or 0, if the voltage is unknown.</p>
<p>This value comes from the <strong>Configured voltage</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the first concrete class that  appears in the inheritance chain used in the creation of an instance.
       When used with the other key properties of the class, the property allows all instances of this class and its
       subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>DataWidth</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Data width of the physical memory—in bits. A data width of 0 (zero) and a total width of
       8 (eight) indicates that the memory is  used solely to provide error correction bits.</p>
<p>This value comes from the <strong>Data Width</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of an object.</p>
</dd>
<dt><strong>DeviceLocator</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label of the socket or circuit board that holds the memory.</p>
<p>Example: "SIMM 3"</p>
<p>This value comes from the <strong>Device Locator</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>FormFactor</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Implementation form factor for the chip.</p>
<p>This value comes from the <strong>Form Factor</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong></strong> (0)</p></dt>
<dd><p>Unknown</p></dd>
<dt><p><strong></strong> (1)</p></dt>
<dd><p>Other</p></dd>
<dt><p><strong></strong> (2)</p></dt>
<dd><p>SIP</p></dd>
<dt><p><strong></strong> (3)</p></dt>
<dd><p>DIP</p></dd>
<dt><p><strong></strong> (4)</p></dt>
<dd><p>ZIP</p></dd>
<dt><p><strong></strong> (5)</p></dt>
<dd><p>SOJ</p></dd>
<dt><p><strong></strong> (6)</p></dt>
<dd><p>Proprietary</p></dd>
<dt><p><strong></strong> (7)</p></dt>
<dd><p>SIMM</p></dd>
<dt><p><strong></strong> (8)</p></dt>
<dd><p>DIMM</p></dd>
<dt><p><strong></strong> (9)</p></dt>
<dd><p>TSOP</p></dd>
<dt><p><strong></strong> (10)</p></dt>
<dd><p>PGA</p></dd>
<dt><p><strong></strong> (11)</p></dt>
<dd><p>RIMM</p></dd>
<dt><p><strong></strong> (12)</p></dt>
<dd><p>SODIMM</p></dd>
<dt><p><strong></strong> (13)</p></dt>
<dd><p>SRIMM</p></dd>
<dt><p><strong></strong> (14)</p></dt>
<dd><p>SMD</p></dd>
<dt><p><strong></strong> (15)</p></dt>
<dd><p>SSMP</p></dd>
<dt><p><strong></strong> (16)</p></dt>
<dd><p>QFP</p></dd>
<dt><p><strong></strong> (17)</p></dt>
<dd><p>TQFP</p></dd>
<dt><p><strong></strong> (18)</p></dt>
<dd><p>SOIC</p></dd>
<dt><p><strong></strong> (19)</p></dt>
<dd><p>LCC</p></dd>
<dt><p><strong></strong> (20)</p></dt>
<dd><p>PLCC</p></dd>
<dt><p><strong></strong> (21)</p></dt>
<dd><p>BGA</p></dd>
<dt><p><strong></strong> (22)</p></dt>
<dd><p>FPBGA</p></dd>
<dt><p><strong></strong> (23)</p></dt>
<dd><p>LGA</p></dd>
</dl>
</dd>
<dt><strong>HotSwappable</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, this physical media component can be replaced with a physically different
       but equivalent one while the containing package has the power applied. For example, a fan component may be
       designed to be hot-swapped. All components that can be hot-swapped are inherently removable and replaceable.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object is installed. This property does not need a value to indicate that the object is
       installed.</p>
</dd>
<dt><strong>InterleaveDataDepth</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unsigned 16-bit integer maximum number of consecutive rows of data that are accessed in a single interleaved
       transfer from the memory device. If the value is 0 (zero), the memory is not interleaved.</p>
</dd>
<dt><strong>InterleavePosition</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Position of the physical memory in an interleave. For example, in a 2:1 interleave, a value of "1"  indicates
       that the memory is in the "even" position.</p>
<dl class="indent">
<dt>0</dt>
<dd><p>Noninterleaved</p></dd>
<dt>1</dt>
<dd><p>First position</p></dd>
<dt>2</dt>
<dd><p>Second position</p></dd>
</dl>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the organization responsible for producing the physical element.</p>
<p>This value comes from the <strong>Manufacturer</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>MaxVoltage</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The maximum operating voltage for this device, in millivolts, or 0, if the voltage is unknown.</p>
<p>This value comes from the <strong>Maximum voltage</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>MemoryType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of physical memory. This is a CIM value that is mapped to the SMBIOS value. The
       <strong>SMBIOSMemoryType</strong> property contains the raw SMBIOS memory type.</p>
<p>This value comes from the <strong>Memory Type</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>DRAM</strong> (2)</p></dt>
<dt><p><strong>Synchronous DRAM</strong> (3)</p></dt>
<dt><p><strong>Cache DRAM</strong> (4)</p></dt>
<dt><p><strong>EDO</strong> (5)</p></dt>
<dt><p><strong>EDRAM</strong> (6)</p></dt>
<dt><p><strong>VRAM</strong> (7)</p></dt>
<dt><p><strong>SRAM</strong> (8)</p></dt>
<dt><p><strong>RAM</strong> (9)</p></dt>
<dt><p><strong>ROM</strong> (10)</p></dt>
<dt><p><strong>Flash</strong> (11)</p></dt>
<dt><p><strong>EEPROM</strong> (12)</p></dt>
<dt><p><strong>FEPROM</strong> (13)</p></dt>
<dt><p><strong>EPROM</strong> (14)</p></dt>
<dt><p><strong>CDRAM</strong> (15)</p></dt>
<dt><p><strong>3DRAM</strong> (16)</p></dt>
<dt><p><strong>SDRAM</strong> (17)</p></dt>
<dt><p><strong>SGRAM</strong> (18)</p></dt>
<dt><p><strong>RDRAM</strong> (19)</p></dt>
<dt><p><strong>DDR</strong> (20)</p></dt>
<dt><p><strong>DDR2</strong> (21)</p></dt>
<dd><p>DDR2—May not be available; see note above.</p></dd>
<dt><p><strong>DDR2 FB-DIMM</strong> (22)</p></dt>
<dd><p>DDR2—FB-DIMM,May not be available; see note above.</p></dd>
<dt>24</dt>
<dd><p>DDR3—May not be available; see note above.</p></dd>
<dt>25</dt>
<dd><p>FBD2</p></dd>
</dl>
</dd>
<dt><strong>MinVoltage</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The minimum operating voltage for this device, in millivolts, or 0, if the voltage is unknown.</p>
<p>This value comes from the <strong>Minimum voltage</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>Model</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name for the physical element.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label for the object. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>OtherIdentifyingInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Additional data, beyond asset tag information, that can be used to identify a physical element. One example
       is bar code data associated with an element that also has an asset tag. If only bar code data is available and
       unique or able to be used as an element key, this property is be <strong>NULL</strong> and the bar
       code data is used as the class key in the tag property.</p>
</dd>
<dt><strong>PartNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Part number assigned by the organization responsible for producing or manufacturing the physical element.</p>
<p>This value comes from the <strong>Part Number</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>PositionInRow</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Position of the physical memory in a row. For example, if it takes two 8-bit memory devices to form a 16-bit
       row, then a value of 2 (two) means that this memory is the second device—0 (zero) is an
       invalid value for this property.</p>
</dd>
<dt><strong>PoweredOn</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the physical element is powered on.</p>
</dd>
<dt><strong>Removable</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, a physical component is removable (if it is designed to be taken in and
       out of the physical container in which it is normally found, without impairing the function of the overall
       packaging). A component can still be removable if power must be "off" to perform the removal. If power can be
       "on" and the component removed, then the element is removable and can be hot-swapped. For example, an
       upgradable processor chip is removable.</p>
</dd>
<dt><strong>Replaceable</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, this physical media component can be replaced  with a physically different
       one. For example, some computer systems allow the main processor chip to be upgraded to one of a higher clock
       rating. In this case, the processor is said to be replaceable. All removable components are inherently
       replaceable.</p>
</dd>
<dt><strong>SerialNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer-allocated number  to identify the physical element.</p>
<p>This value comes from the <strong>Serial Number</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>SKU</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Stock keeping unit number for the physical element.</p>
</dd>
<dt><strong>SMBIOSMemoryType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The raw SMBIOS memory type. The value of the <strong>MemoryType</strong> property is a CIM
       value that is mapped to the SMBIOS value.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>Speed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Speed of the physical memory—in nanoseconds.</p>
<p>This value comes from the <strong>Speed</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational
       statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may
       be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error",
       "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk,
       reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed
       element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>The possible values are.</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>Tag</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier for the physical memory device that is represented by an instance of
       <strong>Win32_PhysicalMemory</strong>. This property is
<p>Example: "Physical Memory 1"</p>
</dd>
<dt><strong>TotalWidth</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Total width, in bits, of the physical memory, including check or error correction bits. If there are no error
       correction bits, the value in this property should match what is specified for the
       <strong>DataWidth</strong> property.</p>
<p>This value comes from the <strong>Total Width</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>TypeDetail</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of physical memory represented.</p>
<p>This value comes from the <strong>Type Detail</strong> member of the
       <strong>Memory Device</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Reserved</strong> (1)</p></dt>
<dt><p><strong>Other</strong> (2)</p></dt>
<dt><p><strong>Unknown</strong> (4)</p></dt>
<dt><p><strong>Fast-paged</strong> (8)</p></dt>
<dt><p><strong>Static column</strong> (16)</p></dt>
<dt><p><strong>Pseudo-static</strong> (32)</p></dt>
<dt><p><strong>RAMBUS</strong> (64)</p></dt>
<dt><p><strong>Synchronous</strong> (128)</p></dt>
<dt><p><strong>CMOS</strong> (256)</p></dt>
<dt><p><strong>EDO</strong> (512)</p></dt>
<dt><p><strong>Window DRAM</strong> (1024)</p></dt>
<dt><p><strong>Cache DRAM</strong> (2048)</p></dt>
<dt><p><strong>Non-volatile</strong> (4096)</p></dt>
<dd><p>Nonvolatile</p></dd>
</dl>
</dd>
<dt><strong>Version</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Version of the physical element.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394356(v=vs.85).aspx
POINTINGDEVICE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394356(v=vs.85).aspx" />
    <title>Win32_PointingDevice class (Windows)</title>
<h3> Pointing Device</h3>
<p>The <strong>Win32_PointingDevice</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the pointing device with other devices on the system.</p>
</dd>
<dt><strong>DeviceInterface</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of interface used for the pointing device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Serial</strong> (3)</p></dt>
<dt><p><strong>PS/2</strong> (4)</p></dt>
<dt><p><strong>Infrared</strong> (5)</p></dt>
<dt><p><strong>HP-HIL</strong> (6)</p></dt>
<dt><p><strong>Bus mouse</strong> (7)</p></dt>
<dt><p><strong>ADB (Apple Desktop Bus)</strong> (8)</p></dt>
<dt><p><strong>Bus mouse DB-9</strong> (160)</p></dt>
<dt><p><strong>Bus mouse micro-DIN</strong> (161)</p></dt>
<dt><p><strong>USB</strong> (162)</p></dt>
</dl>
</dd>
<dt><strong>DoubleSpeedThreshold</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>One of two acceleration values. The sensitivity of the pointing device doubles (toggles from the first to the second value) when the pointing device moves a distance greater than this threshold value.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information on any corrective actions that may be taken.</p>
</dd>
<dt><strong>Handedness</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Configuration of the pointing device for left-hand or right-hand operation.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Applicable</strong> (1)</p></dt>
<dt><p><strong>Right Handed Operation</strong> (2)</p></dt>
<dd><p>Right-Handed Operation</p></dd>
<dt><p><strong>Left Handed Operation</strong> (3)</p></dt>
<dd><p>Left-Handed Operation</p></dd>
</dl>
</dd>
<dt><strong>HardwareType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of hardware used for the Windows pointing device.</p>
<p>Example: "MICROSOFT PS2 MOUSE"</p>
</dd>
<dt><strong>InfFileName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the .inf file for the Windows pointing device.</p>
<p>Example: "ab.inf"</p>
</dd>
<dt><strong>InfSection</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Section of the .inf file that holds configuration information for the Windows pointing device.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>IsLocked</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is locked, preventing user input or output.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the processor's manufacturer.</p>
<p>Example: "GenuineSilicon"</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>NumberOfButtons</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of buttons on the pointing device.</p>
<p>Example: 2</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PointingType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of pointing device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Mouse</strong> (3)</p></dt>
<dt><p><strong>Track Ball</strong> (4)</p></dt>
<dd><p>Trackball</p></dd>
<dt><p><strong>Track Point</strong> (5)</p></dt>
<dt><p><strong>Glide Point</strong> (6)</p></dt>
<dt><p><strong>Touch Pad</strong> (7)</p></dt>
<dt><p><strong>Touch Screen</strong> (8)</p></dt>
<dt><p><strong>Mouse - Optical Sensor</strong> (9)</p></dt>
</dl>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>QuadSpeedThreshold</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>One of two acceleration threshold values. The system doubles the speed of the pointer movement when the pointer device moves a distance greater than this value. Because this speed increase occurs after the <strong>DoubleSpeedThreshold</strong> value has been met, the pointer effectively moves at four times its original speed.</p>
</dd>
<dt><strong>Resolution</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Tracking resolution.</p>
<p>Example: 0</p>
</dd>
<dt><strong>SampleRate</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Rate at which the pointing device is polled for input information.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>Synch</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Length of time after which the next interrupt is assumed to indicate the start of a new device packet (partial packets are discarded). In the event that an interrupt is lost, this allows the pointing device driver to synchronize its internal representation of the packet state with the hardware state.</p>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394357(v=vs.85).aspx
PORTABLEBATTERY = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394357(v=vs.85).aspx" />
    <title>Win32_PortableBattery class (Windows)</title>
<h3> Portable Battery</h3>
<p>The <strong>Win32_PortableBattery</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>BatteryStatus</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the battery's charge status. The value 10 (Undefined) is not valid in the Common Information Model (CIM) schema because in Desktop Management Interface (DMI) it indicates that no battery is installed. In this case, this object should not be instantiated.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Fully Charged</strong> (3)</p></dt>
<dt><p><strong>Low</strong> (4)</p></dt>
<dt><p><strong>Critical</strong> (5)</p></dt>
<dt><p><strong>Charging</strong> (6)</p></dt>
<dt><p><strong>Charging and High</strong> (7)</p></dt>
<dt><p><strong>Charging and Low</strong> (8)</p></dt>
<dt><p><strong>Charging and Critical</strong> (9)</p></dt>
<dt><p><strong>Undefined</strong> (10)</p></dt>
<dt><p><strong>Partially Charged</strong> (11)</p></dt>
</dl>
</dd>
<dt><strong>CapacityMultiplier</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Multiplication factor of the <strong>DesignCapacity</strong> value to ensure that the milliwatt hour value does not overflow for Smart Battery Data Specification (SBDS) implementations.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of the object—a one-line string.</p>
</dd>
<dt><strong>Chemistry</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Chemistry of the battery.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Lead Acid</strong> (3)</p></dt>
<dt><p><strong>Nickel Cadmium</strong> (4)</p></dt>
<dt><p><strong>Nickel Metal Hydride</strong> (5)</p></dt>
<dt><p><strong>Lithium-ion</strong> (6)</p></dt>
<dt><p><strong>Zinc air</strong> (7)</p></dt>
<dt><p><strong>Lithium Polymer</strong> (8)</p></dt>
</dl>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DesignCapacity</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Design capacity of the battery in milliwatt-hours. If this property is not supported, enter 0 (zero).</p>
</dd>
<dt><strong>DesignVoltage</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Design voltage of the battery in millivolts. If this attribute is not supported, enter 0 (zero).</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Battery identifier.</p>
<p>Example: "Internal Battery"</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and any corrective actions that may be taken.</p>
</dd>
<dt><strong>EstimatedChargeRemaining</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Estimate of the percentage of full charge remaining.</p>
</dd>
<dt><strong>EstimatedRunTime</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Estimate in minutes of the time to battery charge depletion under the present load conditions if the utility power is off, or lost and remains off, or a laptop is disconnected from a power source.</p>
</dd>
<dt><strong>ExpectedBatteryLife</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Not supported.</p>
</dd>
<dt><strong>ExpectedLife</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Battery's expected lifetime in minutes, assuming that the battery is fully charged. This property represents the total expected life of the battery, not its current remaining life, which is indicated by the <strong>EstimatedRunTime</strong> property.</p>
</dd>
<dt><strong>FullChargeCapacity</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Full charge capacity of the battery in milliwatt-hours. Comparison of this value to the <strong>DesignCapacity</strong> property determines when the battery requires replacement. A battery's end of life is typically when the <strong>FullChargeCapacity</strong> property falls below 80% of the <strong>DesignCapacity</strong> property. If this property is not supported, enter 0 (zero).</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Location</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Physical location of the battery. This property is filled by the computer manufacturer.</p>
<p>Example: "In the back, on the left"</p>
</dd>
<dt><strong>ManufactureDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date when the battery was manufactured.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer of the battery.</p>
</dd>
<dt><strong>MaxBatteryError</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Difference between the highest estimated amount of energy left in the battery and the current amount reported by the battery.</p>
</dd>
<dt><strong>MaxRechargeTime</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum time, in minutes, to fully charge the battery. This property represents the time to recharge a fully depleted battery, not the current remaining charge time, which is indicated in the <strong>TimeToFullCharge</strong> property.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>SmartBatteryVersion</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Smart Battery Data Specification version number supported by this battery. If the battery does not support this function, the value should be left blank.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOnBattery</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Elapsed time in seconds since the computer system's UPS last switched to battery power, or the time since the system or UPS was last restarted, whichever is less. If the battery is online, 0 (zero) is returned.</p>
</dd>
<dt><strong>TimeToFullCharge</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Remaining time in minutes to charge the battery fully at the current charge rate and usage.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394363(v=vs.85).aspx
PRINTER = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394363(v=vs.85).aspx" />
    <title>Win32_Printer class (Windows)</title>
<h3> Printer</h3>
<p>The <strong>Win32_Printer</strong> class has these properties.</p>
<dl>
<dt><strong>Attributes</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Bitmap of attributes for a Windows-based printing device.</p>
<dl class="indent">
<dt><p><strong>PRINTER_ATTRIBUTE_QUEUED</strong> (1 (0x1))</p></dt>
<dd><p>Queued</p>
<p>Print jobs are buffered and queued.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_DIRECT</strong> (2 (0x2))</p></dt>
<dd><p>Direct</p>
<p>Document to  be sent directly to the printer. This value is used if print jobs are not queued correctly.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_DEFAULT</strong> (4 (0x4))</p></dt>
<dd><p>Default</p>
<p>Default printer on a  computer.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_SHARED</strong> (8 (0x8))</p></dt>
<dd><p>Shared</p>
<p>Available as a shared network resource.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_NETWORK</strong> (16 (0x10))</p></dt>
<dd><p>Network</p>
<p>Attached to a network. If both Local and Network bits are set, this indicates a network printer.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_HIDDEN</strong> (32 (0x20))</p></dt>
<dd><p>Hidden</p>
<p>Hidden from some users on the network.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_LOCAL</strong> (64 (0x40))</p></dt>
<dd><p>Local</p>
<p>Directly connected to a  computer.
        If both Local and Network bits are set, this indicates a network printer.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_ENABLEDEVQ</strong> (128 (0x80))</p></dt>
<dd><p>EnableDevQ</p>
<p>Enable the queue on the printer if available.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_KEEPPRINTEDJOBS</strong> (256 (0x100))</p></dt>
<dd><p>KeepPrintedJobs</p>
<p>Spooler should not delete documents after they are printed.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_DO_COMPLETE_FIRST</strong> (512 (0x200))</p></dt>
<dd><p>DoCompleteFirst</p>
<p>Start jobs that are finished spooling first.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_WORK_OFFLINE</strong> (1024 (0x400))</p></dt>
<dd><p>WorkOffline</p>
<p>Queue print jobs when  a printer is not available.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_ENABLE_BIDI</strong> (2048 (0x800))</p></dt>
<dd><p>EnableBIDI</p>
<p>Enable bidirectional printing.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_RAW_ONLY</strong> (4096 (0x1000))</p></dt>
<dd><p>Allow only raw data type jobs to be spooled.</p></dd>
<dt><p><strong>PRINTER_ATTRIBUTE_PUBLISHED</strong> (8192 (0x2000))</p></dt>
<dd><p>Published</p>
<p>Published in the network directory service.</p></dd>
</dl>
</dd>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but is still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>AvailableJobSheets</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of all  the job sheets available on a  printer. Can also be used to describe the banner that a printer might provide at the beginning of each job, or other user-specified options.</p>
</dd>
<dt><strong>AveragePagesPerMinute</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Printing rate, in average number of pages per minute,  that a  printer  can produce output.</p>
</dd>
<dt><strong>Capabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of printer capabilities.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Color Printing</strong> (2)</p></dt>
<dt><p><strong>Duplex Printing</strong> (3)</p></dt>
<dt><p><strong>Copies</strong> (4)</p></dt>
<dt><p><strong>Collation</strong> (5)</p></dt>
<dt><p><strong>Stapling</strong> (6)</p></dt>
<dt><p><strong>Transparency Printing</strong> (7)</p></dt>
<dt><p><strong>Punch</strong> (8)</p></dt>
<dt><p><strong>Cover</strong> (9)</p></dt>
<dt><p><strong>Bind</strong> (10)</p></dt>
<dt><p><strong>Black and White Printing</strong> (11)</p></dt>
<dt><p><strong>One Sided</strong> (12)</p></dt>
<dd><p>One-Sided</p></dd>
<dt><p><strong>Two Sided Long Edge</strong> (13)</p></dt>
<dd><p>Two-Sided Long Edge</p></dd>
<dt><p><strong>Two Sided Short Edge</strong> (14)</p></dt>
<dd><p>Two-Sided Short Edge</p></dd>
<dt><p><strong>Portrait</strong> (15)</p></dt>
<dt><p><strong>Landscape</strong> (16)</p></dt>
<dt><p><strong>Reverse Portrait</strong> (17)</p></dt>
<dt><p><strong>Reverse Landscape</strong> (18)</p></dt>
<dt><p><strong>Quality High</strong> (19)</p></dt>
<dt><p><strong>Quality Normal</strong> (20)</p></dt>
<dt><p><strong>Quality Low</strong> (21)</p></dt>
</dl>
</dd>
<dt><strong>CapabilityDescriptions</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of free-form strings that provide  detailed explanations for  the printer features indicated in the <strong>Capabilities</strong> array. Each  entry of this array is related to an  entry in the <strong>Capabilities</strong> array that is located in  the same index.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of an  object—a one-line string.</p>
</dd>
<dt><strong>CharSetsSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of available character sets for  output. Strings provided in this property must  conform to the semantics and syntax specified by section 4.1.2 ("Charset parameters") in RFC 2046 (MIME Part 2) and contained in the IANA character-set registry. Examples include, "UTF-8", "us-ASCII", and "iso-8859-1".</p>
</dd>
<dt><strong>Comment</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Comment for a print queue.</p>
<p>Example: Color printer</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have a valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used to create  an instance. When used with  other key properties of the class, the property allows all instances of this class and its subclasses to be identified uniquely.</p>
</dd>
<dt><strong>CurrentCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of printer capabilities that are  being used currently. An entry in this property must also be listed in the <strong>Capabilities</strong> array.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Color Printing</strong> (2)</p></dt>
<dt><p><strong>Duplex Printing</strong> (3)</p></dt>
<dt><p><strong>Copies</strong> (4)</p></dt>
<dt><p><strong>Collation</strong> (5)</p></dt>
<dt><p><strong>Stapling</strong> (6)</p></dt>
<dt><p><strong>Transparency Printing</strong> (7)</p></dt>
<dt><p><strong>Punch</strong> (8)</p></dt>
<dt><p><strong>Cover</strong> (9)</p></dt>
<dt><p><strong>Bind</strong> (10)</p></dt>
<dt><p><strong>Black and White Printing</strong> (11)</p></dt>
<dt><p><strong>One Sided</strong> (12)</p></dt>
<dd><p>One-Sided</p></dd>
<dt><p><strong>Two Sided Long Edge</strong> (13)</p></dt>
<dd><p>Two-Sided Long Edge</p></dd>
<dt><p><strong>Two Sided Short Edge</strong> (14)</p></dt>
<dd><p>Two-Sided Short Edge</p></dd>
<dt><p><strong>Portrait</strong> (15)</p></dt>
<dt><p><strong>Landscape</strong> (16)</p></dt>
<dt><p><strong>Reverse Portrait</strong> (17)</p></dt>
<dt><p><strong>Reverse Landscape</strong> (18)</p></dt>
<dt><p><strong>Quality High</strong> (19)</p></dt>
<dt><p><strong>Quality Normal</strong> (20)</p></dt>
<dt><p><strong>Quality Low</strong> (21)</p></dt>
</dl>
</dd>
<dt><strong>CurrentCharSet</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The character set currently  used for output. Strings provided in this property must conform to the semantics and syntax specified by section 4.1.2 ("Charset parameters") in RFC 2046 (MIME Part 2) and contained in the IANA character-set registry. Examples include "utf-8", "us-ASCII", and iso-8859-1.</p>
</dd>
<dt><strong>CurrentLanguage</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Printer language currently  used. The language used must  be listed in the <strong>LanguagesSupported</strong> property.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>PCL</strong> (3)</p></dt>
<dt><p><strong>HPGL</strong> (4)</p></dt>
<dt><p><strong>PJL</strong> (5)</p></dt>
<dt><p><strong>PS</strong> (6)</p></dt>
<dt><p><strong>PSPrinter</strong> (7)</p></dt>
<dt><p><strong>IPDS</strong> (8)</p></dt>
<dt><p><strong>PPDS</strong> (9)</p></dt>
<dt><p><strong>EscapeP</strong> (10)</p></dt>
<dt><p><strong>Epson</strong> (11)</p></dt>
<dt><p><strong>DDIF</strong> (12)</p></dt>
<dt><p><strong>Interpress</strong> (13)</p></dt>
<dt><p><strong>ISO6429</strong> (14)</p></dt>
<dt><p><strong>Line Data</strong> (15)</p></dt>
<dd><p>LineData</p></dd>
<dt><p><strong>MODCA</strong> (16)</p></dt>
<dd><p>DODCA</p></dd>
<dt><p><strong>REGIS</strong> (17)</p></dt>
<dt><p><strong>SCS</strong> (18)</p></dt>
<dt><p><strong>SPDL</strong> (19)</p></dt>
<dt><p><strong>TEK4014</strong> (20)</p></dt>
<dt><p><strong>PDS</strong> (21)</p></dt>
<dt><p><strong>IGP</strong> (22)</p></dt>
<dt><p><strong>CodeV</strong> (23)</p></dt>
<dt><p><strong>DSCDSE</strong> (24)</p></dt>
<dt><p><strong>WPS</strong> (25)</p></dt>
<dt><p><strong>LN03</strong> (26)</p></dt>
<dt><p><strong>CCITT</strong> (27)</p></dt>
<dt><p><strong>QUIC</strong> (28)</p></dt>
<dt><p><strong>CPAP</strong> (29)</p></dt>
<dt><p><strong>DecPPL</strong> (30)</p></dt>
<dt><p><strong>Simple Text</strong> (31)</p></dt>
<dd><p>SimpleText</p></dd>
<dt><p><strong>NPAP</strong> (32)</p></dt>
<dt><p><strong>DOC</strong> (33)</p></dt>
<dt><p><strong>imPress</strong> (34)</p></dt>
<dt><p><strong>Pinwriter</strong> (35)</p></dt>
<dt><p><strong>NPDL</strong> (36)</p></dt>
<dt><p><strong>NEC201PL</strong> (37)</p></dt>
<dt><p><strong>Automatic</strong> (38)</p></dt>
<dt><p><strong>Pages</strong> (39)</p></dt>
<dt><p><strong>LIPS</strong> (40)</p></dt>
<dt><p><strong>TIFF</strong> (41)</p></dt>
<dt><p><strong>Diagnostic</strong> (42)</p></dt>
<dt><p><strong>CaPSL</strong> (43)</p></dt>
<dt><p><strong>EXCL</strong> (44)</p></dt>
<dt><p><strong>LCDS</strong> (45)</p></dt>
<dt><p><strong>XES</strong> (46)</p></dt>
<dt><p><strong>MIME</strong> (47)</p></dt>
<dt>48</dt>
<dd><p>XPS</p></dd>
<dt>49</dt>
<dd><p>HPGL2</p></dd>
<dt>50</dt>
<dd><p>PCLXL</p></dd>
</dl>
</dd>
<dt><strong>CurrentMimeType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>MIME type currently  being used if the <strong>CurrentLanguage</strong> is a MIME type (value = 47).</p>
</dd>
<dt><strong>CurrentNaturalLanguage</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Language that  the printer is using for management currently. The language listed here must also be listed in the <strong>NaturalLanguagesSupported</strong> property.</p>
</dd>
<dt><strong>CurrentPaperType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of paper the printer is  using. Must be expressed in the form specified by the ISO/IEC 10175 Document Printing Application  (DPA), which is summarized in Appendix C of RFC 1759 (Printer MIB).</p>
</dd>
<dt><strong>Default</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the printer is the default printer.</p>
</dd>
<dt><strong>DefaultCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the printer capabilities  used by default. Each entry in the <strong>DefaultCapabilities</strong> array must also be listed in the <strong>Capabilities</strong> array.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Color Printing</strong> (2)</p></dt>
<dt><p><strong>Duplex Printing</strong> (3)</p></dt>
<dt><p><strong>Copies</strong> (4)</p></dt>
<dt><p><strong>Collation</strong> (5)</p></dt>
<dt><p><strong>Stapling</strong> (6)</p></dt>
<dt><p><strong>Transparency Printing</strong> (7)</p></dt>
<dt><p><strong>Punch</strong> (8)</p></dt>
<dt><p><strong>Cover</strong> (9)</p></dt>
<dt><p><strong>Bind</strong> (10)</p></dt>
<dt><p><strong>Black and White Printing</strong> (11)</p></dt>
<dt><p><strong>One Sided</strong> (12)</p></dt>
<dd><p>One-Sided</p></dd>
<dt><p><strong>Two Sided Long Edge</strong> (13)</p></dt>
<dd><p>Two-Sided Long Edge</p></dd>
<dt><p><strong>Two Sided Short Edge</strong> (14)</p></dt>
<dd><p>Two-Sided Short Edge</p></dd>
<dt><p><strong>Portrait</strong> (15)</p></dt>
<dt><p><strong>Landscape</strong> (16)</p></dt>
<dt><p><strong>Reverse Portrait</strong> (17)</p></dt>
<dt><p><strong>Reverse Landscape</strong> (18)</p></dt>
<dt><p><strong>Quality High</strong> (19)</p></dt>
<dt><p><strong>Quality Normal</strong> (20)</p></dt>
<dt><p><strong>Quality Low</strong> (21)</p></dt>
</dl>
</dd>
<dt><strong>DefaultCopies</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of copies produced for one  job—unless otherwise specified.</p>
</dd>
<dt><strong>DefaultLanguage</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Default printer language. The language listed here must also be listed in the <strong>LanguagesSupported</strong> property.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>PCL</strong> (3)</p></dt>
<dt><p><strong>HPGL</strong> (4)</p></dt>
<dt><p><strong>PJL</strong> (5)</p></dt>
<dt><p><strong>PS</strong> (6)</p></dt>
<dt><p><strong>PSPrinter</strong> (7)</p></dt>
<dt><p><strong>IPDS</strong> (8)</p></dt>
<dt><p><strong>PPDS</strong> (9)</p></dt>
<dt><p><strong>EscapeP</strong> (10)</p></dt>
<dt><p><strong>Epson</strong> (11)</p></dt>
<dt><p><strong>DDIF</strong> (12)</p></dt>
<dt><p><strong>Interpress</strong> (13)</p></dt>
<dt><p><strong>ISO6429</strong> (14)</p></dt>
<dt><p><strong>Line Data</strong> (15)</p></dt>
<dd><p>LineData</p></dd>
<dt><p><strong>MODCA</strong> (16)</p></dt>
<dd><p>DODCA</p></dd>
<dt><p><strong>REGIS</strong> (17)</p></dt>
<dt><p><strong>SCS</strong> (18)</p></dt>
<dt><p><strong>SPDL</strong> (19)</p></dt>
<dt><p><strong>TEK4014</strong> (20)</p></dt>
<dt><p><strong>PDS</strong> (21)</p></dt>
<dt><p><strong>IGP</strong> (22)</p></dt>
<dt><p><strong>CodeV</strong> (23)</p></dt>
<dt><p><strong>DSCDSE</strong> (24)</p></dt>
<dt><p><strong>WPS</strong> (25)</p></dt>
<dt><p><strong>LN03</strong> (26)</p></dt>
<dt><p><strong>CCITT</strong> (27)</p></dt>
<dt><p><strong>QUIC</strong> (28)</p></dt>
<dt><p><strong>CPAP</strong> (29)</p></dt>
<dt><p><strong>DecPPL</strong> (30)</p></dt>
<dt><p><strong>Simple Text</strong> (31)</p></dt>
<dd><p>SimpleText</p></dd>
<dt><p><strong>NPAP</strong> (32)</p></dt>
<dt><p><strong>DOC</strong> (33)</p></dt>
<dt><p><strong>imPress</strong> (34)</p></dt>
<dt><p><strong>Pinwriter</strong> (35)</p></dt>
<dt><p><strong>NPDL</strong> (36)</p></dt>
<dt><p><strong>NEC201PL</strong> (37)</p></dt>
<dt><p><strong>Automatic</strong> (38)</p></dt>
<dt><p><strong>Pages</strong> (39)</p></dt>
<dt><p><strong>LIPS</strong> (40)</p></dt>
<dt><p><strong>TIFF</strong> (41)</p></dt>
<dt><p><strong>Diagnostic</strong> (42)</p></dt>
<dt><p><strong>CaPSL</strong> (43)</p></dt>
<dt><p><strong>EXCL</strong> (44)</p></dt>
<dt><p><strong>LCDS</strong> (45)</p></dt>
<dt><p><strong>XES</strong> (46)</p></dt>
<dt><p><strong>MIME</strong> (47)</p></dt>
<dt>48</dt>
<dd><p>XPS</p></dd>
<dt>49</dt>
<dd><p>HPGL2</p></dd>
<dt>50</dt>
<dd><p>PCLXL</p></dd>
</dl>
</dd>
<dt><strong>DefaultMimeType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>MIME type currently being used, if the <strong>DefaultLanguage</strong> value is a MIME type (value = 47).</p>
</dd>
<dt><strong>DefaultNumberUp</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of print-stream pages that the printer renders on one  media sheet—unless a job specifies otherwise.</p>
</dd>
<dt><strong>DefaultPaperType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>DefaultPriority</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Default priority value assigned to each print job.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of an object.</p>
</dd>
<dt><strong>DetectedErrorState</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Printer error information.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>No Error</strong> (2)</p></dt>
<dt><p><strong>Low Paper</strong> (3)</p></dt>
<dt><p><strong>No Paper</strong> (4)</p></dt>
<dt><p><strong>Low Toner</strong> (5)</p></dt>
<dt><p><strong>No Toner</strong> (6)</p></dt>
<dt><p><strong>Door Open</strong> (7)</p></dt>
<dt><p><strong>Jammed</strong> (8)</p></dt>
<dt><p><strong>Offline</strong> (9)</p></dt>
<dt><p><strong>Service Requested</strong> (10)</p></dt>
<dt><p><strong>Output Bin Full</strong> (11)</p></dt>
</dl>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Unique identifier of the printer  on a  system.</p>
</dd>
<dt><strong>Direct</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the print job is  sent directly to the printer. If <strong>FALSE</strong>, the print job is  spooled.</p>
</dd>
<dt><strong>DoCompleteFirst</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the printer starts  jobs that are finished spooling. If  <strong>FALSE</strong>, the printer starts jobs in the order that the jobs are  received.</p>
</dd>
<dt><strong>DriverName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Name of the Windows printer driver.</p>
<p>Example: Windows Fax Driver</p>
</dd>
<dt><strong>EnableBIDI</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the printer can  print bidirectionally.</p>
</dd>
<dt><strong>EnableDevQueryPrint</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the printer holds documents in the queue when document and printer setups do not match.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> has been cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Information  about the error recorded in <strong>LastErrorCode</strong>, and information about corrective actions  that can be taken.</p>
</dd>
<dt><strong>ErrorInformation</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Array of supplemental information for the current error state indicated in <strong>DetectedErrorState</strong>.</p>
</dd>
<dt><strong>ExtendedDetectedErrorState</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Reports standard error information. Additional information should be recorded in <strong>DetectedErrorState</strong>.</p>
<p>Values are:</p>
<dl class="indent">
<dt>0 (0x0)</dt>
<dd><p>Unknown</p></dd>
<dt>1 (0x1)</dt>
<dd><p>Other</p></dd>
<dt>2 (0x2)</dt>
<dd><p>No Error</p></dd>
<dt>3 (0x3)</dt>
<dd><p>Low Paper</p></dd>
<dt>4 (0x4)</dt>
<dd><p>No Paper</p></dd>
<dt>5 (0x5)</dt>
<dd><p>Low Toner</p></dd>
<dt>6 (0x6)</dt>
<dd><p>No Toner</p></dd>
<dt>7 (0x7)</dt>
<dd><p>Door Open</p></dd>
<dt>8 (0x8)</dt>
<dd><p>Jammed</p></dd>
<dt>9 (0x9)</dt>
<dd><p>Service Requested</p></dd>
<dt>10 (0xA)</dt>
<dd><p>Output Bin Full</p></dd>
<dt>11 (0xB)</dt>
<dd><p>Paper Problem</p></dd>
<dt>12 (0xC)</dt>
<dd><p>Cannot Print Page</p></dd>
<dt>13 (0xD)</dt>
<dd><p>User Intervention Required</p></dd>
<dt>14 (0xE)</dt>
<dd><p>Out of Memory</p></dd>
<dt>15 (0xF)</dt>
<dd><p>Server Unknown</p></dd>
</dl>
</dd>
<dt><strong>ExtendedPrinterStatus</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Status information for a printer that is different from information specified in the <strong>Availability</strong> property.</p>
<dl class="indent">
<dt>1 (0x1)</dt>
<dd><p>Other</p></dd>
<dt>2 (0x2)</dt>
<dd><p>Unknown</p></dd>
<dt>3 (0x3)</dt>
<dd><p>Idle</p></dd>
<dt>4 (0x4)</dt>
<dd><p>Printing</p></dd>
<dt>5 (0x5)</dt>
<dd><p>Warming Up</p></dd>
<dt>6 (0x6)</dt>
<dd><p>Stopped Printing</p></dd>
<dt>7</dt>
<dd><p>Offline</p></dd>
<dt>8 (0x8)</dt>
<dd><p>Paused</p></dd>
<dt>9 (0x9)</dt>
<dd><p>Error</p></dd>
<dt>10 (0xA)</dt>
<dd><p>Busy</p></dd>
<dt>11 (0xB)</dt>
<dd><p>Not Available</p></dd>
<dt>12 (0xC)</dt>
<dd><p>Waiting</p></dd>
<dt>13 (0xD)</dt>
<dd><p>Processing</p></dd>
<dt>14 (0xE)</dt>
<dd><p>Initialization</p></dd>
<dt>15</dt>
<dd><p>Power Save</p></dd>
<dt>16 (0x10)</dt>
<dd><p>Pending Deletion</p></dd>
<dt>17 (0x11)</dt>
<dd><p>I/O Active</p></dd>
<dt>18 (0x12)</dt>
<dd><p>Manual Feed</p></dd>
</dl>
</dd>
<dt><strong>Hidden</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the printer is hidden from network users.</p>
</dd>
<dt><strong>HorizontalResolution</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Horizontal  resolution of the printer—in pixels per inch.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>JobCountSinceLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
<dt>Qualifiers: <strong>Counter</strong></dt>
</dl>
<p>
</p><p>Number of print jobs since the printer was last reset.</p>
</dd>
<dt><strong>KeepPrintedJobs</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the print spooler does  not delete the completed jobs.</p>
</dd>
<dt><strong>LanguagesSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the print languages natively supported.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>PCL</strong> (3)</p></dt>
<dt><p><strong>HPGL</strong> (4)</p></dt>
<dt><p><strong>PJL</strong> (5)</p></dt>
<dt><p><strong>PS</strong> (6)</p></dt>
<dt><p><strong>PSPrinter</strong> (7)</p></dt>
<dt><p><strong>IPDS</strong> (8)</p></dt>
<dt><p><strong>PPDS</strong> (9)</p></dt>
<dt><p><strong>EscapeP</strong> (10)</p></dt>
<dt><p><strong>Epson</strong> (11)</p></dt>
<dt><p><strong>DDIF</strong> (12)</p></dt>
<dt><p><strong>Interpress</strong> (13)</p></dt>
<dt><p><strong>ISO6429</strong> (14)</p></dt>
<dt><p><strong>Line Data</strong> (15)</p></dt>
<dd><p>LineData</p></dd>
<dt><p><strong>MODCA</strong> (16)</p></dt>
<dd><p>DODCA</p></dd>
<dt><p><strong>REGIS</strong> (17)</p></dt>
<dt><p><strong>SCS</strong> (18)</p></dt>
<dt><p><strong>SPDL</strong> (19)</p></dt>
<dt><p><strong>TEK4014</strong> (20)</p></dt>
<dt><p><strong>PDS</strong> (21)</p></dt>
<dt><p><strong>IGP</strong> (22)</p></dt>
<dt><p><strong>CodeV</strong> (23)</p></dt>
<dt><p><strong>DSCDSE</strong> (24)</p></dt>
<dt><p><strong>WPS</strong> (25)</p></dt>
<dt><p><strong>LN03</strong> (26)</p></dt>
<dt><p><strong>CCITT</strong> (27)</p></dt>
<dt><p><strong>QUIC</strong> (28)</p></dt>
<dt><p><strong>CPAP</strong> (29)</p></dt>
<dt><p><strong>DecPPL</strong> (30)</p></dt>
<dt><p><strong>Simple Text</strong> (31)</p></dt>
<dd><p>SimpleText</p></dd>
<dt><p><strong>NPAP</strong> (32)</p></dt>
<dt><p><strong>DOC</strong> (33)</p></dt>
<dt><p><strong>imPress</strong> (34)</p></dt>
<dt><p><strong>Pinwriter</strong> (35)</p></dt>
<dt><p><strong>NPDL</strong> (36)</p></dt>
<dt><p><strong>NEC201PL</strong> (37)</p></dt>
<dt><p><strong>Automatic</strong> (38)</p></dt>
<dt><p><strong>Pages</strong> (39)</p></dt>
<dt><p><strong>LIPS</strong> (40)</p></dt>
<dt><p><strong>TIFF</strong> (41)</p></dt>
<dt><p><strong>Diagnostic</strong> (42)</p></dt>
<dt><p><strong>CaPSL</strong> (43)</p></dt>
<dt><p><strong>EXCL</strong> (44)</p></dt>
<dt><p><strong>LCDS</strong> (45)</p></dt>
<dt><p><strong>XES</strong> (46)</p></dt>
<dt><p><strong>MIME</strong> (47)</p></dt>
<dt><p><strong>XPS</strong> (48)</p></dt>
<dt><p><strong>HPGL2</strong> (49)</p></dt>
<dt><p><strong>PCLXL</strong> (50)</p></dt>
</dl>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code that  the logical device reports.</p>
</dd>
<dt><strong>Local</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the printer is not attached to a network. If both the <strong>Local</strong> and <strong>Network</strong> properties are set to <strong>TRUE</strong>, then the printer is a network printer.</p>
</dd>
<dt><strong>Location</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Physical location of the printer.</p>
<p>Example: Bldg. 38, Room 1164</p>
</dd>
<dt><strong>MarkingTechnology</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Marking technology the printer uses.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Electrophotographic LED</strong> (3)</p></dt>
<dt><p><strong>Electrophotographic Laser</strong> (4)</p></dt>
<dt><p><strong>Electrophotographic Other</strong> (5)</p></dt>
<dt><p><strong>Impact Moving Head Dot Matrix 9pin</strong> (6)</p></dt>
<dt><p><strong>Impact Moving Head Dot Matrix 24pin</strong> (7)</p></dt>
<dt><p><strong>Impact Moving Head Dot Matrix Other</strong> (8)</p></dt>
<dt><p><strong>Impact Moving Head Fully Formed</strong> (9)</p></dt>
<dt><p><strong>Impact Band</strong> (10)</p></dt>
<dt><p><strong>Impact Other</strong> (11)</p></dt>
<dt><p><strong>Inkjet Aqueous</strong> (12)</p></dt>
<dt><p><strong>Inkjet Solid</strong> (13)</p></dt>
<dt><p><strong>Inkjet Other</strong> (14)</p></dt>
<dt><p><strong>Pen</strong> (15)</p></dt>
<dt><p><strong>Thermal Transfer</strong> (16)</p></dt>
<dt><p><strong>Thermal Sensitive</strong> (17)</p></dt>
<dt><p><strong>Thermal Diffusion</strong> (18)</p></dt>
<dt><p><strong>Thermal Other</strong> (19)</p></dt>
<dt><p><strong>Electroerosion</strong> (20)</p></dt>
<dt><p><strong>Electrostatic</strong> (21)</p></dt>
<dt><p><strong>Photographic Microfiche</strong> (22)</p></dt>
<dt><p><strong>Photographic Imagesetter</strong> (23)</p></dt>
<dt><p><strong>Photographic Other</strong> (24)</p></dt>
<dt><p><strong>Ion Deposition</strong> (25)</p></dt>
<dt><p><strong>eBeam</strong> (26)</p></dt>
<dt><p><strong>Typesetter</strong> (27)</p></dt>
</dl>
</dd>
<dt><strong>MaxCopies</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of copies the printer can  produce for one  job.</p>
</dd>
<dt><strong>MaxNumberUp</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of print-stream pages the printer can  render on  one  media sheet, such as paper.</p>
</dd>
<dt><strong>MaxSizeSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Largest job as a byte stream, in kilobytes, that the printer can  accept. A value of 0 (zero) indicates that no limit is  set.</p>
</dd>
<dt><strong>MimeTypesSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of detailed MIME-type explanations  that  the printer supports. If data is provided, then the value 47 ("MIME") must be included in the <strong>LanguagesSupported</strong> property.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the printer.</p>
</dd>
<dt><strong>NaturalLanguagesSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>Network</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the printer is a network printer. If both the <strong>Local</strong> and <strong>Network</strong> properties are set to <strong>TRUE</strong>, then the printer is a network printer.</p>
</dd>
<dt><strong>PaperSizesSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the paper  types that the printer supports.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>A</strong> (2)</p></dt>
<dt><p><strong>B</strong> (3)</p></dt>
<dt><p><strong>C</strong> (4)</p></dt>
<dt><p><strong>D</strong> (5)</p></dt>
<dt><p><strong>E</strong> (6)</p></dt>
<dt><p><strong>Letter</strong> (7)</p></dt>
<dt><p><strong>Legal</strong> (8)</p></dt>
<dt><p><strong>NA-10x13-Envelope</strong> (9)</p></dt>
<dt><p><strong>NA-9x12-Envelope</strong> (10)</p></dt>
<dt><p><strong>NA-Number-10-Envelope</strong> (11)</p></dt>
<dt><p><strong>NA-7x9-Envelope</strong> (12)</p></dt>
<dt><p><strong>NA-9x11-Envelope</strong> (13)</p></dt>
<dt><p><strong>NA-10x14-Envelope</strong> (14)</p></dt>
<dt><p><strong>NA-Number-9-Envelope</strong> (15)</p></dt>
<dt><p><strong>NA-6x9-Envelope</strong> (16)</p></dt>
<dt><p><strong>NA-10x15-Envelope</strong> (17)</p></dt>
<dt><p><strong>A0</strong> (18)</p></dt>
<dt><p><strong>A1</strong> (19)</p></dt>
<dt><p><strong>A2</strong> (20)</p></dt>
<dt><p><strong>A3</strong> (21)</p></dt>
<dt><p><strong>A4</strong> (22)</p></dt>
<dt><p><strong>A5</strong> (23)</p></dt>
<dt><p><strong>A6</strong> (24)</p></dt>
<dt><p><strong>A7</strong> (25)</p></dt>
<dt><p><strong>A8</strong> (26)</p></dt>
<dt><p><strong>A9A10</strong> (27)</p></dt>
<dt><p><strong>B0</strong> (28)</p></dt>
<dt><p><strong>B1</strong> (29)</p></dt>
<dt><p><strong>B2</strong> (30)</p></dt>
<dt><p><strong>B3</strong> (31)</p></dt>
<dt><p><strong>B4</strong> (32)</p></dt>
<dt><p><strong>B5</strong> (33)</p></dt>
<dt><p><strong>B6</strong> (34)</p></dt>
<dt><p><strong>B7</strong> (35)</p></dt>
<dt><p><strong>B8</strong> (36)</p></dt>
<dt><p><strong>B9</strong> (37)</p></dt>
<dt><p><strong>B10</strong> (38)</p></dt>
<dt><p><strong>C0</strong> (39)</p></dt>
<dt><p><strong>C1</strong> (40)</p></dt>
<dt><p><strong>C2C3</strong> (41)</p></dt>
<dd><p>C2</p></dd>
<dt><p><strong>C4</strong> (42)</p></dt>
<dd><p>C3</p></dd>
<dt><p><strong>C5</strong> (43)</p></dt>
<dd><p>C4</p></dd>
<dt><p><strong>C6</strong> (44)</p></dt>
<dd><p>C5</p></dd>
<dt><p><strong>C7</strong> (45)</p></dt>
<dd><p>C6</p></dd>
<dt><p><strong>C8</strong> (46)</p></dt>
<dd><p>C7</p></dd>
<dt><p><strong>ISO-Designated</strong> (47)</p></dt>
<dd><p>C8</p></dd>
<dt><p><strong>JIS B0</strong> (48)</p></dt>
<dd><p>ISO-Designated</p></dd>
<dt><p><strong>JIS B1</strong> (49)</p></dt>
<dd><p>JIS B0</p></dd>
<dt><p><strong>JIS B2</strong> (50)</p></dt>
<dd><p>JIS B1</p></dd>
<dt><p><strong>JIS B3</strong> (51)</p></dt>
<dd><p>JIS B2</p></dd>
<dt><p><strong>JIS B4</strong> (52)</p></dt>
<dd><p>JIS B3</p></dd>
<dt><p><strong>JIS B5</strong> (53)</p></dt>
<dd><p>JIS B4</p></dd>
<dt><p><strong>JIS B6</strong> (54)</p></dt>
<dd><p>JIS B5</p></dd>
<dt><p><strong>JIS B7</strong> (55)</p></dt>
<dd><p>JIS B6</p></dd>
<dt><p><strong>JIS B8</strong> (56)</p></dt>
<dd><p>JIS B7</p></dd>
<dt><p><strong>JIS B9</strong> (57)</p></dt>
<dd><p>JIS B8</p></dd>
<dt><p><strong>JIS B10</strong> (58)</p></dt>
<dd><p>JIS B9</p></dd>
<dt><p><strong>NA-Letter</strong> (59)</p></dt>
<dd><p>JIS B10</p></dd>
<dt><p><strong>NA-Legal</strong> (60)</p></dt>
<dt><p><strong>B4-Envelope</strong> (61)</p></dt>
<dt><p><strong>B5-Envelope</strong> (62)</p></dt>
<dt><p><strong>C3-Envelope</strong> (63)</p></dt>
<dt><p><strong>C4-Envelope</strong> (64)</p></dt>
<dt><p><strong>C5-Envelope</strong> (65)</p></dt>
<dt><p><strong>C6-Envelope</strong> (66)</p></dt>
<dt><p><strong>Designated-Long-Envelope</strong> (67)</p></dt>
<dt><p><strong>Monarch-Envelope</strong> (68)</p></dt>
<dt><p><strong>Executive</strong> (69)</p></dt>
<dt><p><strong>Folio</strong> (70)</p></dt>
<dt><p><strong>Invoice</strong> (71)</p></dt>
<dt><p><strong>Ledger</strong> (72)</p></dt>
<dt><p><strong>Quarto</strong> (73)</p></dt>
</dl>
</dd>
<dt><strong>PaperTypesAvailable</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
<p>Example: iso-a4-colored</p>
</dd>
<dt><strong>Parameters</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Optional parameters for the print processor.</p>
<p>Example: "Copies=2"</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: *PNP030b</p>
</dd>
<dt><strong>PortName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Port that is  used to transmit data to a printer. If a printer is connected to more than one port, the names of each port are separated by commas.</p>
<p>Example: LPT1:, LPT2:, LPT3:</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled, but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the power of the device can be managed, which means that it can be put into suspend mode. The property does not indicate that power management features are  enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>PrinterPaperNames</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of paper sizes supported by the printer. The printer-specified names are used to represent supported paper sizes.</p>
<p>Example: B5 (JIS)</p>
</dd>
<dt><strong>PrinterState</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>One of the possible states relating to this printer. This property is obsolete. In place of this property,  use <strong>PrinterStatus</strong>.</p>
<dl class="indent">
<dt>0</dt>
<dd><p>Idle - for more information, see the Remarks section below.</p></dd>
<dt>1</dt>
<dd><p>Paused</p></dd>
<dt>2</dt>
<dd><p>Error</p></dd>
<dt>3</dt>
<dd><p>Pending Deletion</p></dd>
<dt>4</dt>
<dd><p>Paper Jam</p></dd>
<dt>5</dt>
<dd><p>Paper Out</p></dd>
<dt>6</dt>
<dd><p>Manual Feed</p></dd>
<dt>7</dt>
<dd><p>Paper Problem</p></dd>
<dt>8</dt>
<dd><p>Offline</p></dd>
<dt>9</dt>
<dd><p>I/O Active</p></dd>
<dt>10</dt>
<dd><p>Busy</p></dd>
<dt>11</dt>
<dd><p>Printing</p></dd>
<dt>12</dt>
<dd><p>Output Bin Full</p></dd>
<dt>13</dt>
<dd><p>Not Available</p></dd>
<dt>14</dt>
<dd><p>Waiting</p></dd>
<dt>15</dt>
<dd><p>Processing</p></dd>
<dt>16</dt>
<dd><p>Initialization</p></dd>
<dt>17</dt>
<dd><p>Warming Up</p></dd>
<dt>18</dt>
<dd><p>Toner Low</p></dd>
<dt>19</dt>
<dd><p>No Toner</p></dd>
<dt>20</dt>
<dd><p>Page Punt</p></dd>
<dt>21</dt>
<dd><p>User Intervention Required</p></dd>
<dt>22</dt>
<dd><p>Out of Memory</p></dd>
<dt>23</dt>
<dd><p>Door Open</p></dd>
<dt>24</dt>
<dd><p>Server_Unknown</p></dd>
<dt>25</dt>
<dd><p>Power Save</p></dd>
</dl>
</dd>
<dt><strong>PrinterStatus</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Status information for a printer  that is different from information  specified in the logical device <strong>Availability</strong> property.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Idle</strong> (3)</p></dt>
<dd><p>Idle - for more information, see the Remarks section below.</p></dd>
<dt><p><strong>Printing</strong> (4)</p></dt>
<dt><p><strong>Warmup</strong> (5)</p></dt>
<dd><p>Warming Up</p></dd>
<dt><p><strong>Stopped Printing</strong> (6)</p></dt>
<dt><p><strong>Offline</strong> (7)</p></dt>
</dl>
</dd>
<dt><strong>PrintJobDataType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Data type of a print job waiting for  the Windows-based printing device.</p>
</dd>
<dt><strong>PrintProcessor</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Name of the print spooler that handles print jobs.</p>
<p>Example: SPOOLSS.DLL</p>
</dd>
<dt><strong>Priority</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Priority of the printer. Jobs on a higher priority printer are scheduled first.</p>
</dd>
<dt><strong>Published</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the printer is published in the network directory service.</p>
</dd>
<dt><strong>Queued</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the printer buffers and queues print jobs.</p>
</dd>
<dt><strong>RawOnly</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the printer accepts only raw data to be spooled.</p>
</dd>
<dt><strong>SeparatorFile</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Name of the file used to create a separator page. This page is used to separate print jobs sent to the printer.</p>
</dd>
<dt><strong>ServerName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the server that controls  the printer. If this string is <strong>NULL</strong>, the printer is controlled locally.</p>
</dd>
<dt><strong>Shared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the printer is available as a shared network resource.</p>
</dd>
<dt><strong>ShareName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Share name of the Windows-based printing device.</p>
<p>Example: "\\PRINTSERVER1\PRINTER2"</p>
</dd>
<dt><strong>SpoolEnabled</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>This property is obsolete; do not use. If <strong>TRUE</strong>, spooling is enabled for  printer.</p>
</dd>
<dt><strong>StartTime</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Date and time that  a  printer can  start to print a job—if the printer is limited to print at specific times. This value is expressed as the time elapsed since  12:00 AM GMT (Greenwich Mean Time).</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: <strong>OK</strong>, <strong>Degraded</strong>, and <strong>Pred Fail</strong> (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: <strong>Error</strong>, <strong>Starting</strong>, <strong>Stopping</strong>, and <strong>Service</strong>. The latter, <strong>Service</strong>, could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither <strong>OK</strong> nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (<strong>Not Applicable</strong>) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the  printer was last reset.</p>
</dd>
<dt><strong>UntilTime</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>Date and time that a  printer can print the last  job—if the printer is  limited to print  at specific  times. This value is expressed as  the time elapsed since  12:00 AM GMT (Greenwich Mean Time).</p>
</dd>
<dt><strong>VerticalResolution</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Vertical resolution, in pixels-per-inch,  of the printer.</p>
</dd>
<dt><strong>WorkOffline</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read/write</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, you can  queue print jobs on the computer when  the printer is offline.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394365(v=vs.85).aspx
PRINTERCONTROLLER = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394365(v=vs.85).aspx" />
    <title>Win32_PrinterController class (Windows)</title>
<h3> Printer Controller</h3>
<p>The <strong>Win32_PrinterController</strong> class has these properties.</p>
<dl>
<dt><strong>AccessState</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the controller access to the device. This information is necessary when a logical device can be commanded by, or accessed through, multiple controllers.</p>
<dl class="indent">
<dt><p><strong>0</strong></p></dt>
<dd><p>Unknown</p></dd>
<dt><p><strong>1</strong></p></dt>
<dd><p>Active</p></dd>
<dt><p><strong>2</strong></p></dt>
<dd><p>Inactive</p></dd>
</dl>
</dd>
<dt><strong>Antecedent</strong></dt>
<dd><dl>
<dt>Data type: <strong>CIM_Controller</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</dd>
<dt><strong>Dependent</strong></dt>
<dd><dl>
<dt>Data type: <strong>Win32_Printer</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Reference to the
</dd>
<dt><strong>NegotiatedDataWidth</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Data width in use between devices (when several bus or connection data widths are possible). Data width is specified in bits. If data width is not negotiated, or if this information is not available or important to device management, the property should be set to 0 (zero).</p>
</dd>
<dt><strong>NegotiatedSpeed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Speed in use between devices (when several bus or connection speeds are possible). Speed is specified in bits per second. If connection or bus speeds are not negotiated, or if this information is not available or important to device management, the property should be set to 0 (zero).</p>
</dd>
<dt><strong>NumberOfHardResets</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of hard resets issued by the controller.</p>
</dd>
<dt><strong>NumberOfSoftResets</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of soft resets issued by the controller.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394373(v=vs.85).aspx
PROCESSOR = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394373(v=vs.85).aspx" />
    <title>Win32_Processor class (Windows)</title>
<h3> Processor</h3>
<p>The <strong>Win32_Processor</strong> class has these properties.</p>
<dl>
<dt><strong>AddressWidth</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>On a 32-bit operating system, the value is 32 and on a 64-bit operating system it is 64.</p>
</dd>
<dt><strong>Architecture</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Processor architecture used by the  platform.</p>
<dl class="indent">
<dt><p><strong>x86</strong> (0)</p></dt>
<dt><p><strong>MIPS</strong> (1)</p></dt>
<dt><p><strong>Alpha</strong> (2)</p></dt>
<dt><p><strong>PowerPC</strong> (3)</p></dt>
<dt>5</dt>
<dd><p>ARM</p></dd>
<dt><p><strong>ia64</strong> (6)</p></dt>
<dd><p>Itanium-based systems</p></dd>
<dt><p><strong>x64</strong> (9)</p></dt>
</dl>
</dd>
<dt><strong>AssetTag</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Represents the asset tag of this processor.</p>
<p>This value comes from the <strong>Asset Tag</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save state, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state, but is still functioning, and may exhibit decreased performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but can be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save state.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of an  object (a one-line string).</p>
</dd>
<dt><strong>Characteristics</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Defines which functions the processor supports.</p>
<p>This value comes from the <strong>Processor Characteristics</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows API Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must  be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a configuration that the user defines.</p>
</dd>
<dt><strong>CpuStatus</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the processor. Status changes indicate  processor usage, but not the physical condition of the processor.</p>
<p>This value comes from the <strong>Status</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>CPU Enabled</strong> (1)</p></dt>
<dt><p><strong>CPU Disabled by User via BIOS Setup</strong> (2)</p></dt>
<dt><p><strong>CPU Disabled By BIOS (POST Error)</strong> (3)</p></dt>
<dt><p><strong>CPU is Idle</strong> (4)</p></dt>
<dt><p><strong>Reserved</strong> (5)</p></dt>
<dt><p><strong>Reserved</strong> (6)</p></dt>
<dt><p><strong>Other</strong> (7)</p></dt>
</dl>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used to create  an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>CurrentClockSpeed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current speed of the processor, in MHz.</p>
<p>This value comes from the <strong>Current Speed</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>CurrentVoltage</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Voltage of the processor. If the eighth bit is set,  bits  0-6 contain the voltage multiplied by 10. If the eighth bit is not set, then the bit setting in <strong>VoltageCaps</strong> represents the voltage value. <strong>CurrentVoltage</strong> is only set when SMBIOS designates a voltage value.</p>
<p>Example: Value for a processor voltage of 1.8 volts is 0x12 (1.8 x 10).</p>
<p>This value comes from the <strong>Voltage</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>DataWidth</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>On a 32-bit processor, the value is 32 and on a 64-bit processor it is 64.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of a processor  on the system.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is  clear.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information about corrective actions that can be taken.</p>
</dd>
<dt><strong>ExtClock</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>External clock frequency, in MHz. If the frequency is unknown, this property is set to <strong>NULL</strong>.</p>
<p>This value comes from the <strong>External Clock</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>Family</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Processor family type.</p>
<p>This value comes from the <strong>Processor Information</strong> structure in the SMBIOS version information. For SMBIOS versions 2.0 thru 2.5 the value comes from the <strong>Processor Family</strong> member. For SMBIOS version 2.6+ the value comes from the <strong>Processor Family 2</strong> member.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>8086</strong> (3)</p></dt>
<dt><p><strong>80286</strong> (4)</p></dt>
<dt><p><strong>80386</strong> (5)</p></dt>
<dd><p>Intel386™ Processor</p></dd>
<dt><p><strong>80486</strong> (6)</p></dt>
<dd><p>Intel486™ Processor</p></dd>
<dt><p><strong>8087</strong> (7)</p></dt>
<dt><p><strong>80287</strong> (8)</p></dt>
<dt><p><strong>80387</strong> (9)</p></dt>
<dt><p><strong>80487</strong> (10)</p></dt>
<dt><p><strong>Pentium(R) brand</strong> (11)</p></dt>
<dd><p>Pentium Brand</p></dd>
<dt><p><strong>Pentium(R) Pro</strong> (12)</p></dt>
<dd><p>Pentium Pro</p></dd>
<dt><p><strong>Pentium(R) II</strong> (13)</p></dt>
<dd><p>Pentium II</p></dd>
<dt><p><strong>Pentium(R) processor with MMX(TM) technology</strong> (14)</p></dt>
<dd><p>Pentium Processor with MMX™ Technology</p></dd>
<dt><p><strong>Celeron(TM)</strong> (15)</p></dt>
<dd><p>Celeron™</p></dd>
<dt><p><strong>Pentium(R) II Xeon(TM)</strong> (16)</p></dt>
<dd><p>Pentium II Xeon™</p></dd>
<dt><p><strong>Pentium(R) III</strong> (17)</p></dt>
<dd><p>Pentium III</p></dd>
<dt><p><strong>M1 Family</strong> (18)</p></dt>
<dt><p><strong>M2 Family</strong> (19)</p></dt>
<dt><p><strong>K5 Family</strong> (24)</p></dt>
<dd><p>AMD Duron™ Processor Family</p></dd>
<dt><p><strong>K6 Family</strong> (25)</p></dt>
<dd><p>K5 Family</p></dd>
<dt><p><strong>K6-2</strong> (26)</p></dt>
<dd><p>K6 Family</p></dd>
<dt><p><strong>K6-3</strong> (27)</p></dt>
<dd><p>K6-2</p></dd>
<dt><p><strong>AMD Athlon(TM) Processor Family</strong> (28)</p></dt>
<dd><p>K6-3</p></dd>
<dt><p><strong>AMD(R) Duron(TM) Processor</strong> (29)</p></dt>
<dd><p>AMD Athlon™ Processor Family</p></dd>
<dt><p><strong>AMD29000 Family</strong> (30)</p></dt>
<dd><p>AMD2900 Family</p></dd>
<dt><p><strong>K6-2+</strong> (31)</p></dt>
<dt><p><strong>Power PC Family</strong> (32)</p></dt>
<dt><p><strong>Power PC 601</strong> (33)</p></dt>
<dt><p><strong>Power PC 603</strong> (34)</p></dt>
<dt><p><strong>Power PC 603+</strong> (35)</p></dt>
<dt><p><strong>Power PC 604</strong> (36)</p></dt>
<dt><p><strong>Power PC 620</strong> (37)</p></dt>
<dt><p><strong>Power PC X704</strong> (38)</p></dt>
<dt><p><strong>Power PC 750</strong> (39)</p></dt>
<dt><p><strong>Alpha Family</strong> (48)</p></dt>
<dt><p><strong>Alpha 21064</strong> (49)</p></dt>
<dt><p><strong>Alpha 21066</strong> (50)</p></dt>
<dt><p><strong>Alpha 21164</strong> (51)</p></dt>
<dt><p><strong>Alpha 21164PC</strong> (52)</p></dt>
<dt><p><strong>Alpha 21164a</strong> (53)</p></dt>
<dt><p><strong>Alpha 21264</strong> (54)</p></dt>
<dt><p><strong>Alpha 21364</strong> (55)</p></dt>
<dt><p><strong>MIPS Family</strong> (64)</p></dt>
<dt><p><strong>MIPS R4000</strong> (65)</p></dt>
<dt><p><strong>MIPS R4200</strong> (66)</p></dt>
<dt><p><strong>MIPS R4400</strong> (67)</p></dt>
<dt><p><strong>MIPS R4600</strong> (68)</p></dt>
<dt><p><strong>MIPS R10000</strong> (69)</p></dt>
<dt><p><strong>SPARC Family</strong> (80)</p></dt>
<dt><p><strong>SuperSPARC</strong> (81)</p></dt>
<dt><p><strong>microSPARC II</strong> (82)</p></dt>
<dt><p><strong>microSPARC IIep</strong> (83)</p></dt>
<dt><p><strong>UltraSPARC</strong> (84)</p></dt>
<dt><p><strong>UltraSPARC II</strong> (85)</p></dt>
<dt><p><strong>UltraSPARC IIi</strong> (86)</p></dt>
<dt><p><strong>UltraSPARC III</strong> (87)</p></dt>
<dt><p><strong>UltraSPARC IIIi</strong> (88)</p></dt>
<dt><p><strong>68040</strong> (96)</p></dt>
<dt><p><strong>68xxx Family</strong> (97)</p></dt>
<dt><p><strong>68000</strong> (98)</p></dt>
<dt><p><strong>68010</strong> (99)</p></dt>
<dt><p><strong>68020</strong> (100)</p></dt>
<dt><p><strong>68030</strong> (101)</p></dt>
<dt><p><strong>Hobbit Family</strong> (112)</p></dt>
<dt><p><strong>Crusoe(TM) TM5000 Family</strong> (120)</p></dt>
<dd><p>Crusoe™ TM5000 Family</p></dd>
<dt><p><strong>Crusoe(TM) TM3000 Family</strong> (121)</p></dt>
<dd><p>Crusoe™ TM3000 Family</p></dd>
<dt><p><strong>Efficeon(TM) TM8000 Family</strong> (122)</p></dt>
<dd><p>Efficeon™ TM8000 Family</p></dd>
<dt><p><strong>Weitek</strong> (128)</p></dt>
<dt><p><strong>Itanium(TM) Processor</strong> (130)</p></dt>
<dd><p>Itanium™ Processor</p></dd>
<dt><p><strong>AMD Athlon(TM) 64 Processor Family</strong> (131)</p></dt>
<dd><p>AMD Athlon™ 64 Processor Family</p></dd>
<dt><p><strong>AMD Opteron(TM) Family</strong> (132)</p></dt>
<dd><p>AMD Opteron™ Processor Family</p></dd>
<dt><p><strong>PA-RISC Family</strong> (144)</p></dt>
<dt><p><strong>PA-RISC 8500</strong> (145)</p></dt>
<dt><p><strong>PA-RISC 8000</strong> (146)</p></dt>
<dt><p><strong>PA-RISC 7300LC</strong> (147)</p></dt>
<dt><p><strong>PA-RISC 7200</strong> (148)</p></dt>
<dt><p><strong>PA-RISC 7100LC</strong> (149)</p></dt>
<dt><p><strong>PA-RISC 7100</strong> (150)</p></dt>
<dt><p><strong>V30 Family</strong> (160)</p></dt>
<dt><p><strong>Pentium(R) III Xeon(TM)</strong> (176)</p></dt>
<dd><p>Pentium III Xeon™ Processor</p></dd>
<dt><p><strong>Pentium(R) III Processor with Intel(R) SpeedStep(TM) Technology</strong> (177)</p></dt>
<dd><p>Pentium III Processor with Intel SpeedStep™ Technology</p></dd>
<dt><p><strong>Pentium(R) 4</strong> (178)</p></dt>
<dd><p>Pentium 4</p></dd>
<dt><p><strong>Intel(R) Xeon(TM)</strong> (179)</p></dt>
<dd><p>Intel Xeon™</p></dd>
<dt><p><strong>AS400 Family</strong> (180)</p></dt>
<dt><p><strong>Intel(R) Xeon(TM) processor MP</strong> (181)</p></dt>
<dd><p>Intel Xeon™ Processor MP</p></dd>
<dt><p><strong>AMD AthlonXP(TM) Family</strong> (182)</p></dt>
<dd><p>AMD Athlon™ XP Family</p></dd>
<dt><p><strong>AMD AthlonMP(TM) Family</strong> (183)</p></dt>
<dd><p>AMD Athlon™ MP Family</p></dd>
<dt><p><strong>Intel(R) Itanium(R) 2</strong> (184)</p></dt>
<dd><p>Intel Itanium 2</p></dd>
<dt><p><strong>Intel Pentium M Processor</strong> (185)</p></dt>
<dt><p><strong>K7</strong> (190)</p></dt>
<dt>198</dt>
<dd><p>Intel Core™ i7-2760QM</p></dd>
<dt><p><strong>IBM390 Family</strong> (200)</p></dt>
<dt><p><strong>G4</strong> (201)</p></dt>
<dt><p><strong>G5</strong> (202)</p></dt>
<dt><p><strong>G6</strong> (203)</p></dt>
<dt><p><strong>z/Architecture base</strong> (204)</p></dt>
<dt><p><strong>i860</strong> (250)</p></dt>
<dt><p><strong>i960</strong> (251)</p></dt>
<dt><p><strong>SH-3</strong> (260)</p></dt>
<dt><p><strong>SH-4</strong> (261)</p></dt>
<dt><p><strong>ARM</strong> (280)</p></dt>
<dt><p><strong>StrongARM</strong> (281)</p></dt>
<dt><p><strong>6x86</strong> (300)</p></dt>
<dt><p><strong>MediaGX</strong> (301)</p></dt>
<dt><p><strong>MII</strong> (302)</p></dt>
<dt><p><strong>WinChip</strong> (320)</p></dt>
<dt><p><strong>DSP</strong> (350)</p></dt>
<dt><p><strong>Video Processor</strong> (500)</p></dt>
</dl>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>L2CacheSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Size of the  Level 2  processor cache. A Level 2 cache is an external memory area that has a faster access time than the main RAM memory.</p>
<p>This value comes from the <strong>L2 Cache Handle</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>L2CacheSpeed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Clock speed of the Level 2 processor cache. A Level 2 cache is an external memory area that has a faster access time than the main RAM memory.</p>
<p>This value comes from the <strong>L2 Cache Handle</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>L3CacheSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Size of the Level 3 processor cache. A Level 3 cache is an external memory area that has a faster access time than the main RAM memory.</p>
<p>This value comes from the <strong>L3 Cache Handle</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>L3CacheSpeed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Clockspeed of the Level 3 property cache. A Level 3 cache is an external memory area that has a faster access time than the main RAM memory.</p>
<p>This value comes from the <strong>L3 Cache Handle</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Level</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Definition of the processor type. The value depends on the architecture of the processor.</p>
</dd>
<dt><strong>LoadPercentage</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Load capacity of each processor, averaged  to  the last second. Processor  loading refers to the total computing burden for each processor  at one time.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the processor manufacturer.</p>
<p>Example: A. Datum Corporation</p>
<p>This value comes from the <strong>Processor Manufacturer</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>MaxClockSpeed</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum speed  of the  processor, in MHz.</p>
<p>This value comes from the <strong>Max Speed</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When this property is a subclass,  it can be overridden to be a key property.</p>
<p>This value comes from the <strong>Processor Version</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>NumberOfCores</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of cores for the current instance of the processor. A core is a physical processor on the integrated circuit. For example, in a dual-core processor this property has a value of 2. For more information, see Remarks.</p>
<p>This value comes from the <strong>Processor Information</strong> structure in the SMBIOS version information. For SMBIOS versions 2.5 thru 2.9 the value comes from the <strong>Core Count</strong> member. For SMBIOS version 3.0+ the value comes from the <strong>Core Count 2</strong> member.</p>
</dd>
<dt><strong>NumberOfEnabledCore</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The number of enabled cores per processor socket.</p>
<p>This value comes from the <strong>Processor Information</strong> structure in the SMBIOS version information. For SMBIOS versions 2.5 thru 2.9 the value comes from the <strong>Core Enabled</strong> member. For SMBIOS version 3.0+ the value comes from the <strong>Core Enabled 2</strong> member.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>NumberOfLogicalProcessors</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of logical processors for the current instance of the processor. For processors capable of hyperthreading, this value includes only the processors which have hyperthreading enabled. For more information, see Remarks.</p>
</dd>
<dt><strong>OtherFamilyDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Processor family type. Used when the <strong>Family</strong> property is set to 1, which means Other. This string should be set to <strong>NULL</strong> when the <strong>Family</strong> property is a value that is not  1.</p>
</dd>
<dt><strong>PartNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The part number of this processor as set by the manufacturer.</p>
<p>This value comes from the <strong>Part Number</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: *PNP030b</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the power of the device can be managed, which means that it can be put into suspend mode, and so on. The property does not indicate that power management features are enabled, but it does indicate  that the logical device power can be  managed.</p>
</dd>
<dt><strong>ProcessorId</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Processor information that describes the processor features. For  an x86 class CPU, the field format depends on the processor support of the CPUID instruction. If the instruction is supported, the property contains 2 (two)  <strong>DWORD</strong> formatted values. The first is an offset of  08h-0Bh, which  is the EAX value that  a CPUID instruction returns with input EAX set to 1. The second is an offset of  0Ch-0Fh, which  is the EDX value  that the instruction returns. Only the first two bytes of the property are significant  and contain  the contents of the DX register at CPU reset—all others are set to 0 (zero), and the contents are in <strong>DWORD</strong> format.</p>
<p>This value comes from the <strong>Processor ID</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>ProcessorType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Primary function of the processor.</p>
<p>This value comes from the <strong>Processor Type</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Central Processor</strong> (3)</p></dt>
<dt><p><strong>Math Processor</strong> (4)</p></dt>
<dt><p><strong>DSP Processor</strong> (5)</p></dt>
<dt><p><strong>Video Processor</strong> (6)</p></dt>
</dl>
</dd>
<dt><strong>Revision</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>System revision level that depends on the architecture.  The system revision level  contains the same values as the <strong>Version</strong> property, but in a numerical format.</p>
</dd>
<dt><strong>Role</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Role of the processor.</p>
<p>Examples: Central Processor or Math Processor</p>
</dd>
<dt><strong>SecondLevelAddressTranslationExtensions</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>,  the processor supports address translation extensions used for virtualization.</p>
<p><strong>Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows 8 and Windows Server 2012.</p>
</dd>
<dt><strong>SerialNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The serial number of this processor This value is set by the manufacturer and normally not changeable.</p>
<p>This value comes from the <strong>Serial Number</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>SocketDesignation</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of chip socket used on the circuit.</p>
<p>Example: J202</p>
<p>This value comes from the <strong>Socket Designation</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, use the value 5, which means Not Applicable.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>Stepping</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Revision level of the processor in the processor family.</p>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the <strong>CreationClassName</strong> property for the scoping computer.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>ThreadCount</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The number of threads per processor socket.</p>
<p>This value comes from the <strong>Processor Information</strong> structure in the SMBIOS version information. For SMBIOS versions 2.5 thru 2.9 the value comes from the <strong>Thread Count</strong> member. For SMBIOS version 3.0+ the value comes from the <strong>Thread Count 2</strong> member.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows Server 2016 Technical Preview and
        Windows 10.</p>
</dd>
<dt><strong>UniqueId</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Globally unique identifier for the processor. This identifier may only be unique within a processor family.</p>
</dd>
<dt><strong>UpgradeMethod</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>CPU socket information, including the method by which this processor can be upgraded, if upgrades are supported. This property is an integer enumeration.</p>
<p>This value comes from the <strong>Processor Upgrade</strong> member of the <strong>Processor Information</strong> structure in the SMBIOS information.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Daughter Board</strong> (3)</p></dt>
<dt><p><strong>ZIF Socket</strong> (4)</p></dt>
<dt><p><strong>Replacement/Piggy Back</strong> (5)</p></dt>
<dd><p>Replacement or Piggy Back</p></dd>
<dt><p><strong>None</strong> (6)</p></dt>
<dt><p><strong>LIF Socket</strong> (7)</p></dt>
<dt><p><strong>Slot 1</strong> (8)</p></dt>
<dt><p><strong>Slot 2</strong> (9)</p></dt>
<dt><p><strong>370 Pin Socket</strong> (10)</p></dt>
<dt><p><strong>Slot A</strong> (11)</p></dt>
<dt><p><strong>Slot M</strong> (12)</p></dt>
<dt><p><strong>Socket 423</strong> (13)</p></dt>
<dt><p><strong>Socket A (Socket 462)</strong> (14)</p></dt>
<dt><p><strong>Socket 478</strong> (15)</p></dt>
<dt><p><strong>Socket 754</strong> (16)</p></dt>
<dt><p><strong>Socket 940</strong> (17)</p></dt>
<dt><p><strong>Socket 939</strong> (18)</p></dt>
</dl>
</dd>
<dt><strong>Version</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Processor  revision number that depends on the architecture.</p>
<p>Example: Model 2, Stepping 12</p>
</dd>
<dt><strong>VirtualizationFirmwareEnabled</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the Firmware has enabled virtualization extensions.</p>
<p><strong>Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows 8 and Windows Server 2012.</p>
</dd>
<dt><strong>VMMonitorModeExtensions</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>True</strong>, the processor supports Intel or AMD Virtual Machine Monitor extensions.</p>
<p><strong>Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows 8 and Windows Server 2012.</p>
</dd>
<dt><strong>VoltageCaps</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Voltage capabilities of the processor. Bits 0-3 of the field represent specific voltages that the processor socket can accept. All other bits should be set to 0 (zero). The socket is configurable if multiple bits are  set. For more information about the actual voltage at which the processor is running, see <strong>CurrentVoltage</strong>. If the property is <strong>NULL</strong>, then the voltage capabilities are unknown.</p>
<dl class="indent">
<dt><p><strong>5</strong> (1)</p></dt>
<dd><p>5 volts</p></dd>
<dt><p><strong>3.3</strong> (2)</p></dt>
<dd><p>3.3 volts</p></dd>
<dt><p><strong>2.9</strong> (4)</p></dt>
<dd><p>2.9 volts</p></dd>
</dl>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394393(v=vs.85).aspx
REFRIGERATION = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394393(v=vs.85).aspx" />
    <title>Win32_Refrigeration class (Windows)</title>
<h3> Refrigeration</h3>
<p>The <strong>Win32_Refrigeration</strong> class has these properties.</p>
<dl>
<dt><strong>ActiveCooling</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the cooling device provides active  cooling—not passive cooling.</p>
</dd>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the refrigeration device.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dd><p>Power-related capacities are not supported for this device.</p></dd>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value for the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394400(v=vs.85).aspx
SCSICONTROLLER = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394400(v=vs.85).aspx" />
    <title>Win32_SCSIController class (Windows)</title>
<h3>SCSI Controller</h3>
<p>The <strong>Win32_SCSIController</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>ControllerTimeouts</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of time-outs that have occurred after the <strong>TimeOfLastReset</strong> value.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the SCSI controller with other devices on the system.</p>
</dd>
<dt><strong>DeviceMap</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Order in which the devices are listed with this SCSI controller.</p>
</dd>
<dt><strong>DriverName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Driver file name of the SCSI controller.</p>
<p>Example: "Adaptec"</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string supplying more information about the error recorded in <strong>LastErrorCode</strong>, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>HardwareVersion</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Hardware version number of the SCSI controller.</p>
<p>Example: "1.25"</p>
</dd>
<dt><strong>Index</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Index number of the SCSI controller in the system registry.</p>
<p>Example: 0</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the SCSI controller manufacturer.</p>
<p>Example: "Adaptec"</p>
</dd>
<dt><strong>MaxDataWidth</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum data width (in bits) supported by the SCSI controller.</p>
</dd>
<dt><strong>MaxNumberControlled</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.</p>
</dd>
<dt><strong>MaxTransferRate</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum transfer rate (in bits per second) supported by the SCSI controller.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProtectionManagement</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Support of the SCSI controller for redundancy or protection against device failures.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Unprotected</strong> (3)</p></dt>
<dt><p><strong>Protected</strong> (4)</p></dt>
<dt><p><strong>Protected through SCC (SCSI-3 Controller Command)</strong> (5)</p></dt>
<dt><p><strong>Protected through SCC-2 (SCSI-3 Controller Command)</strong> (6)</p></dt>
</dl>
</dd>
<dt><strong>ProtocolSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Protocol used by the controller to access "controlled" devices.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>EISA</strong> (3)</p></dt>
<dt><p><strong>ISA</strong> (4)</p></dt>
<dt><p><strong>PCI</strong> (5)</p></dt>
<dt><p><strong>ATA/ATAPI</strong> (6)</p></dt>
<dt><p><strong>Flexible Diskette</strong> (7)</p></dt>
<dt><p><strong>1496</strong> (8)</p></dt>
<dt><p><strong>SCSI Parallel Interface</strong> (9)</p></dt>
<dt><p><strong>SCSI Fibre Channel Protocol</strong> (10)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol</strong> (11)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol-2 (1394)</strong> (12)</p></dt>
<dt><p><strong>SCSI Serial Storage Architecture</strong> (13)</p></dt>
<dt><p><strong>VESA</strong> (14)</p></dt>
<dt><p><strong>PCMCIA</strong> (15)</p></dt>
<dt><p><strong>Universal Serial Bus</strong> (16)</p></dt>
<dt><p><strong>Parallel Protocol</strong> (17)</p></dt>
<dt><p><strong>ESCON</strong> (18)</p></dt>
<dt><p><strong>Diagnostic</strong> (19)</p></dt>
<dt><p><strong>I2C</strong> (20)</p></dt>
<dt><p><strong>Power</strong> (21)</p></dt>
<dt><p><strong>HIPPI</strong> (22)</p></dt>
<dt><p><strong>MultiBus</strong> (23)</p></dt>
<dt><p><strong>VME</strong> (24)</p></dt>
<dt><p><strong>IPI</strong> (25)</p></dt>
<dt><p><strong>IEEE-488</strong> (26)</p></dt>
<dt><p><strong>RS232</strong> (27)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE5</strong> (28)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE2</strong> (29)</p></dt>
<dt><p><strong>IEEE 802.3 1BASE5</strong> (30)</p></dt>
<dt><p><strong>IEEE 802.3 10BROAD36</strong> (31)</p></dt>
<dt><p><strong>IEEE 802.3 100BASEVG</strong> (32)</p></dt>
<dt><p><strong>IEEE 802.5 Token-Ring</strong> (33)</p></dt>
<dt><p><strong>ANSI X3T9.5 FDDI</strong> (34)</p></dt>
<dt><p><strong>MCA</strong> (35)</p></dt>
<dt><p><strong>ESDI</strong> (36)</p></dt>
<dt><p><strong>IDE</strong> (37)</p></dt>
<dt><p><strong>CMD</strong> (38)</p></dt>
<dt><p><strong>ST506</strong> (39)</p></dt>
<dt><p><strong>DSSI</strong> (40)</p></dt>
<dt><p><strong>QIC2</strong> (41)</p></dt>
<dt><p><strong>Enhanced ATA/IDE</strong> (42)</p></dt>
<dt><p><strong>AGP</strong> (43)</p></dt>
<dt><p><strong>TWIRP (two-way infrared)</strong> (44)</p></dt>
<dt><p><strong>FIR (fast infrared)</strong> (45)</p></dt>
<dt><p><strong>SIR (serial infrared)</strong> (46)</p></dt>
<dt><p><strong>IrBus</strong> (47)</p></dt>
</dl>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time this controller was last reset. This could mean the controller was powered down, or reinitialized.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394413(v=vs.85).aspx
SERIALPORT = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394413(v=vs.85).aspx" />
    <title>Win32_SerialPort class (Windows)</title>
<h3> Serial Port</h3>
<p>The <strong>Win32_SerialPort</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Binary</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the serial port is configured for binary data transfer. Because the Windows API does not support nonbinary mode transfers, this property must be <strong>TRUE</strong>.</p>
</dd>
<dt><strong>Capabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of chip-level compatibility for the serial controller. This property describes the buffering and other capabilities of the serial controller that may be inherent in the chip hardware. The property is an enumerated integer.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>XT/AT Compatible</strong> (3)</p></dt>
<dt><p><strong>16450 Compatible</strong> (4)</p></dt>
<dt><p><strong>16550 Compatible</strong> (5)</p></dt>
<dt><p><strong>16550A Compatible</strong> (6)</p></dt>
<dt><p><strong>8251 Compatible</strong> (160)</p></dt>
<dt><p><strong>8251FIFO Compatible</strong> (161)</p></dt>
</dl>
</dd>
<dt><strong>CapabilityDescriptions</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of free-form strings providing more detailed explanations for any of the serial controller features indicated in the <strong>Capabilities</strong> array. Note, each entry of this array is related to the entry in the <strong>Capabilities</strong> array that is located at the same index.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the serial port with other devices on the system.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string supplying more information about the error recorded in <strong>LastErrorCode</strong>, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>MaxBaudRate</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum baud rate (in bits per second) supported by the serial controller.</p>
</dd>
<dt><strong>MaximumInputBufferSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum size of the serial port driver's internal input buffer. A value of 0 (zero) indicates that no maximum value is imposed by the serial provider.</p>
</dd>
<dt><strong>MaximumOutputBufferSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum size of the serial port driver's internal output buffer. A value of 0 (zero) indicates that no maximum value is imposed by the serial provider.</p>
</dd>
<dt><strong>MaxNumberControlled</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>OSAutoDiscovered</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the instances of this class were automatically discovered by the operating system. If, for example, hardware was added through Control Panel, the operating system finds instances of this class by querying hardware from the instances of this class.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProtocolSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Protocol used by the controller to access "controlled" devices.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>EISA</strong> (3)</p></dt>
<dt><p><strong>ISA</strong> (4)</p></dt>
<dt><p><strong>PCI</strong> (5)</p></dt>
<dt><p><strong>ATA/ATAPI</strong> (6)</p></dt>
<dd><p>ATA or ATAPI</p></dd>
<dt><p><strong>Flexible Diskette</strong> (7)</p></dt>
<dt><p><strong>1496</strong> (8)</p></dt>
<dt><p><strong>SCSI Parallel Interface</strong> (9)</p></dt>
<dt><p><strong>SCSI Fibre Channel Protocol</strong> (10)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol</strong> (11)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol-2 (1394)</strong> (12)</p></dt>
<dt><p><strong>SCSI Serial Storage Architecture</strong> (13)</p></dt>
<dt><p><strong>VESA</strong> (14)</p></dt>
<dt><p><strong>PCMCIA</strong> (15)</p></dt>
<dt><p><strong>Universal Serial Bus</strong> (16)</p></dt>
<dt><p><strong>Parallel Protocol</strong> (17)</p></dt>
<dt><p><strong>ESCON</strong> (18)</p></dt>
<dt><p><strong>Diagnostic</strong> (19)</p></dt>
<dt><p><strong>I2C</strong> (20)</p></dt>
<dt><p><strong>Power</strong> (21)</p></dt>
<dt><p><strong>HIPPI</strong> (22)</p></dt>
<dt><p><strong>MultiBus</strong> (23)</p></dt>
<dt><p><strong>VME</strong> (24)</p></dt>
<dt><p><strong>IPI</strong> (25)</p></dt>
<dt><p><strong>IEEE-488</strong> (26)</p></dt>
<dt><p><strong>RS232</strong> (27)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE5</strong> (28)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE2</strong> (29)</p></dt>
<dt><p><strong>IEEE 802.3 1BASE5</strong> (30)</p></dt>
<dt><p><strong>IEEE 802.3 10BROAD36</strong> (31)</p></dt>
<dt><p><strong>IEEE 802.3 100BASEVG</strong> (32)</p></dt>
<dt><p><strong>IEEE 802.5 Token-Ring</strong> (33)</p></dt>
<dt><p><strong>ANSI X3T9.5 FDDI</strong> (34)</p></dt>
<dt><p><strong>MCA</strong> (35)</p></dt>
<dt><p><strong>ESDI</strong> (36)</p></dt>
<dt><p><strong>IDE</strong> (37)</p></dt>
<dt><p><strong>CMD</strong> (38)</p></dt>
<dt><p><strong>ST506</strong> (39)</p></dt>
<dt><p><strong>DSSI</strong> (40)</p></dt>
<dt><p><strong>QIC2</strong> (41)</p></dt>
<dt><p><strong>Enhanced ATA/IDE</strong> (42)</p></dt>
<dt><p><strong>AGP</strong> (43)</p></dt>
<dt><p><strong>TWIRP (two-way infrared)</strong> (44)</p></dt>
<dt><p><strong>FIR (fast infrared)</strong> (45)</p></dt>
<dt><p><strong>SIR (serial infrared)</strong> (46)</p></dt>
<dt><p><strong>IrBus</strong> (47)</p></dt>
</dl>
</dd>
<dt><strong>ProviderType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Communications provider type.</p>
<p>The values are:</p>
<dl>
<dd>"FAX Device"</dd>
<dd>"LAT Protocol"</dd>
<dd>"Modem Device"</dd>
<dd>"Network Bridge"</dd>
<dd>"Parallel Port"</dd>
<dd>"RS232 Serial Port"</dd>
<dd>"RS422 Port"</dd>
<dd>"RS423 Port"</dd>
<dd>"RS449 Port"</dd>
<dd>"Scanner Device"</dd>
<dd>"TCP/IP TelNet"</dd>
<dd>"X.25"</dd>
<dd>"Unspecified"</dd>
</dl>
<dl class="indent">
<dt><p><strong>FAX Device</strong> ("FAX Device")</p></dt>
<dt><p><strong>LAT Protocol</strong> ("LAT Protocol")</p></dt>
<dt><p><strong>Modem Device</strong> ("Modem Device")</p></dt>
<dt><p><strong>Network Bridge</strong> ("Network Bridge")</p></dt>
<dt><p><strong>Parallel Port</strong> ("Parallel Port")</p></dt>
<dt><p><strong>RS232 Serial Port</strong> ("RS232 Serial Port")</p></dt>
<dt><p><strong>RS422 Port</strong> ("RS422 Port")</p></dt>
<dt><p><strong>RS423 Port</strong> ("RS423 Port")</p></dt>
<dt><p><strong>RS449 Port</strong> ("RS449 Port")</p></dt>
<dt><p><strong>Scanner Device</strong> ("Scanner Device")</p></dt>
<dt><p><strong>TCP/IP TelNet</strong> ("TCP/IP TelNet")</p></dt>
<dt><p><strong>X.25</strong> ("X.25")</p></dt>
<dt><p><strong>Unspecified</strong> ("Unspecified")</p></dt>
</dl>
</dd>
<dt><strong>SettableBaudRate</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the baud rate can be changed for this serial port.</p>
</dd>
<dt><strong>SettableDataBits</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, data bits can be set for this serial port.</p>
</dd>
<dt><strong>SettableFlowControl</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, flow control can be set for this serial port.</p>
</dd>
<dt><strong>SettableParity</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, parity can be set for this serial port.</p>
</dd>
<dt><strong>SettableParityCheck</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, parity checking can be set for this serial port (if parity checking is supported).</p>
</dd>
<dt><strong>SettableRLSD</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, Received Line Signal Detect (RLSD) can be set for this serial port (if RLSD is supported).</p>
</dd>
<dt><strong>SettableStopBits</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, stop bits can be set for this serial port.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>Supports16BitMode</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, 16-bit mode is supported on this serial port.</p>
</dd>
<dt><strong>SupportsDTRDSR</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, data terminal ready (DTR) and data set ready (DSR) signals are supported on this serial port.</p>
</dd>
<dt><strong>SupportsElapsedTimeouts</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, elapsed time-outs are supported on this serial port. Elapsed timeouts track the total amount of time between data transmissions.</p>
</dd>
<dt><strong>SupportsIntTimeouts</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, interval time-outs are supported. An interval timeout is the amount of time allowed to elapse between the arrival of each piece of data.</p>
</dd>
<dt><strong>SupportsParityCheck</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, parity checking is supported on this serial port.</p>
</dd>
<dt><strong>SupportsRLSD</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, Received Line Signal Detect (RLSD) is supported on this serial port.</p>
</dd>
<dt><strong>SupportsRTSCTS</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, ready to send (RTS) and clear to send (CTS) signals are supported on this serial port.</p>
</dd>
<dt><strong>SupportsSpecialCharacters</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, serial port control characters are supported. These characters signal events rather than data. These characters are not displayable and are set by the driver. They include EofChar, ErrorChar, BreakChar, EventChar, XonChar, and XoffChar.</p>
<p></p>
</dd>
<dt><strong>SupportsXOnXOff</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, XON or XOFF flow-control is supported on this serial port.</p>
</dd>
<dt><strong>SupportsXOnXOffSet</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the communications provider supports configuration of the XONor XOFF flow-control setting.</p>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time this controller was last reset. This could mean the controller was powered down, or reinitialized.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394463(v=vs.85).aspx
SOUNDDEVICE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394463(v=vs.85).aspx" />
    <title>Win32_SoundDevice class (Windows)</title>
<h3> Sound Device</h3>
<p>The <strong>Win32_SoundDevice</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, the property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the sound device.</p>
</dd>
<dt><strong>DMABufferSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Size of the Direct Memory Access buffer.</p>
<p>Example: 4</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string supplying more information about the error recorded in <strong>LastErrorCode</strong>, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer of the sound device.</p>
<p>Example: "Creative Labs"</p>
</dd>
<dt><strong>MPU401Address</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Starting I/O address assigned to the MPU-401 port of the sound device.</p>
<p>Example: 300</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProductName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Product name of the sound device.</p>
<p>Example: "Creative Labs SoundBlaster AWE64PNP"</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394486(v=vs.85).aspx
SYSTEMSLOT = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394486(v=vs.85).aspx" />
    <title>Win32_SystemSlot class (Windows)</title>
<h3> System Slot</h3>
<p>The <strong>Win32_SystemSlot</strong> class has these properties.</p>
<dl>
<dt><strong>BusNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SMBIOS Bus Number.</p>
<p>This value comes from the <strong>Bus Number</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows 10 and Windows Server 2016 Technical Preview.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of an object—a one-line string.</p>
</dd>
<dt><strong>ConnectorPinout</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string that describes the pin configuration and signal usage of a physical connector.</p>
</dd>
<dt><strong>ConnectorType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of physical attributes of the connector that this slot uses.</p>
<p>This value comes from the <strong>Slot Type</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
<p>
</p><p>The possible values are.</p>

<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Male</strong> (2)</p></dt>
<dt><p><strong>Female</strong> (3)</p></dt>
<dt><p><strong>Shielded</strong> (4)</p></dt>
<dt><p><strong>Unshielded</strong> (5)</p></dt>
<dt><p><strong>SCSI (A) High-Density (50 pins)</strong> (6)</p></dt>
<dt><p><strong>SCSI (A) Low-Density (50 pins)</strong> (7)</p></dt>
<dt><p><strong>SCSI (P) High-Density (68 pins)</strong> (8)</p></dt>
<dt><p><strong>SCSI SCA-I (80 pins)</strong> (9)</p></dt>
<dt><p><strong>SCSI SCA-II (80 pins)</strong> (10)</p></dt>
<dt><p><strong>SCSI Fibre Channel (DB-9, Copper)</strong> (11)</p></dt>
<dt><p><strong>SCSI Fibre Channel (Fibre)</strong> (12)</p></dt>
<dt><p><strong>SCSI Fibre Channel SCA-II (40 pins)</strong> (13)</p></dt>
<dt><p><strong>SCSI Fibre Channel SCA-II (20 pins)</strong> (14)</p></dt>
<dt><p><strong>SCSI Fibre Channel BNC</strong> (15)</p></dt>
<dt><p><strong>ATA 3-1/2 Inch (40 pins)</strong> (16)</p></dt>
<dt><p><strong>ATA 2-1/2 Inch (44 pins)</strong> (17)</p></dt>
<dt><p><strong>ATA-2</strong> (18)</p></dt>
<dt><p><strong>ATA-3</strong> (19)</p></dt>
<dt><p><strong>ATA/66</strong> (20)</p></dt>
<dt><p><strong>DB-9</strong> (21)</p></dt>
<dt><p><strong>DB-15</strong> (22)</p></dt>
<dt><p><strong>DB-25</strong> (23)</p></dt>
<dt><p><strong>DB-36</strong> (24)</p></dt>
<dt><p><strong>RS-232C</strong> (25)</p></dt>
<dt><p><strong>RS-422</strong> (26)</p></dt>
<dt><p><strong>RS-423</strong> (27)</p></dt>
<dt><p><strong>RS-485</strong> (28)</p></dt>
<dt><p><strong>RS-449</strong> (29)</p></dt>
<dt><p><strong>V.35</strong> (30)</p></dt>
<dt><p><strong>X.21</strong> (31)</p></dt>
<dt><p><strong>IEEE-488</strong> (32)</p></dt>
<dt><p><strong>AUI</strong> (33)</p></dt>
<dt><p><strong>UTP Category 3</strong> (34)</p></dt>
<dt><p><strong>UTP Category 4</strong> (35)</p></dt>
<dt><p><strong>UTP Category 5</strong> (36)</p></dt>
<dt><p><strong>BNC</strong> (37)</p></dt>
<dt><p><strong>RJ11</strong> (38)</p></dt>
<dt><p><strong>RJ45</strong> (39)</p></dt>
<dt><p><strong>Fiber MIC</strong> (40)</p></dt>
<dt><p><strong>Apple AUI</strong> (41)</p></dt>
<dt><p><strong>Apple GeoPort</strong> (42)</p></dt>
<dt><p><strong>PCI</strong> (43)</p></dt>
<dt><p><strong>ISA</strong> (44)</p></dt>
<dt><p><strong>EISA</strong> (45)</p></dt>
<dt><p><strong>VESA</strong> (46)</p></dt>
<dt><p><strong>PCMCIA</strong> (47)</p></dt>
<dt><p><strong>PCMCIA Type I</strong> (48)</p></dt>
<dt><p><strong>PCMCIA Type II</strong> (49)</p></dt>
<dt><p><strong>PCMCIA Type III</strong> (50)</p></dt>
<dt><p><strong>ZV Port</strong> (51)</p></dt>
<dt><p><strong>CardBus</strong> (52)</p></dt>
<dt><p><strong>USB</strong> (53)</p></dt>
<dt><p><strong>IEEE 1394</strong> (54)</p></dt>
<dt><p><strong>HIPPI</strong> (55)</p></dt>
<dt><p><strong>HSSDC (6 pins)</strong> (56)</p></dt>
<dt><p><strong>GBIC</strong> (57)</p></dt>
<dt><p><strong>DIN</strong> (58)</p></dt>
<dt><p><strong>Mini-DIN</strong> (59)</p></dt>
<dt><p><strong>Micro-DIN</strong> (60)</p></dt>
<dt><p><strong>PS/2</strong> (61)</p></dt>
<dt><p><strong>Infrared</strong> (62)</p></dt>
<dt><p><strong>HP-HIL</strong> (63)</p></dt>
<dt><p><strong>Access.bus</strong> (64)</p></dt>
<dt><p><strong>NuBus</strong> (65)</p></dt>
<dt><p><strong>Centronics</strong> (66)</p></dt>
<dt><p><strong>Mini-Centronics</strong> (67)</p></dt>
<dt><p><strong>Mini-Centronics Type-14</strong> (68)</p></dt>
<dt><p><strong>Mini-Centronics Type-20</strong> (69)</p></dt>
<dt><p><strong>Mini-Centronics Type-26</strong> (70)</p></dt>
<dt><p><strong>Bus Mouse</strong> (71)</p></dt>
<dt><p><strong>ADB</strong> (72)</p></dt>
<dt><p><strong>AGP</strong> (73)</p></dt>
<dt><p><strong>VME Bus</strong> (74)</p></dt>
<dt><p><strong>VME64</strong> (75)</p></dt>
<dt><p><strong>Proprietary</strong> (76)</p></dt>
<dt><p><strong>Proprietary Processor Card Slot</strong> (77)</p></dt>
<dt><p><strong>Proprietary Memory Card Slot</strong> (78)</p></dt>
<dt><p><strong>Proprietary I/O Riser Slot</strong> (79)</p></dt>
<dt><p><strong>PCI-66MHZ</strong> (80)</p></dt>
<dt><p><strong>AGP2X</strong> (81)</p></dt>
<dt><p><strong>AGP4X</strong> (82)</p></dt>
<dt><p><strong>PC-98</strong> (83)</p></dt>
<dt><p><strong>PC-98-Hireso</strong> (84)</p></dt>
<dt><p><strong>PC-H98</strong> (85)</p></dt>
<dt><p><strong>PC-98Note</strong> (86)</p></dt>
<dt><p><strong>PC-98Full</strong> (87)</p></dt>
<dt><p><strong>PCI-X</strong> (88)</p></dt>
<dt><p><strong>Sbus IEEE 1396-1993 32 bit</strong> (89)</p></dt>
<dt><p><strong>Sbus IEEE 1396-1993 64 bit</strong> (90)</p></dt>
<dt><p><strong>MCA</strong> (91)</p></dt>
<dt><p><strong>GIO</strong> (92)</p></dt>
<dt><p><strong>XIO</strong> (93)</p></dt>
<dt><p><strong>HIO</strong> (94)</p></dt>
<dt><p><strong>NGIO</strong> (95)</p></dt>
<dt><p><strong>PMC</strong> (96)</p></dt>
<dt><p><strong>Future I/O</strong> (97)</p></dt>
<dt><p><strong>InfiniBand</strong> (98)</p></dt>
<dt><p><strong>AGP8X</strong> (99)</p></dt>
<dt><p><strong>PCI-E</strong> (100)</p></dt>
</dl>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of a class, this property allows all instances of this class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>CurrentUsage</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Status of system slot use.</p>
<p>This value comes from the <strong>Current Usage</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
<p>
</p><p>The possible values are.</p>

<dl class="indent">
<dt><p><strong>Reserved</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Available</strong> (3)</p></dt>
<dt><p><strong>In use</strong> (4)</p></dt>
</dl>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SMBIOS Device Number.</p>
<p>This value comes from the <strong>Device/Function Number</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows 10 and Windows Server 2016 Technical Preview.</p>
</dd>
<dt><strong>FunctionNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SMBIOS Function Number.</p>
<p>This value comes from the <strong>Device/Function Number</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows 10 and Windows Server 2016 Technical Preview.</p>
</dd>
<dt><strong>HeightAllowed</strong></dt>
<dd><dl>
<dt>Data type: <strong>real32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum height of an adapter card that can be inserted into the slot—in inches.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object is installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LengthAllowed</strong></dt>
<dd><dl>
<dt>Data type: <strong>real32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum length of an adapter card that can be inserted into the slot—in inches.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the organization that produces the physical element.</p>
</dd>
<dt><strong>MaxDataWidth</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum bus width of adapter cards that can be inserted into this slot—in bits.  This can be one of the following values.</p>
<p>This value comes from the <strong>Slot Data Bus Width</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
<p>
</p><p>The possible values are.</p>

<dl class="indent">
<dt><p><strong>8</strong> (0)</p></dt>
<dd><p>Maximum data width (bits): 8</p></dd>
<dt><p><strong>16</strong> (1)</p></dt>
<dd><p>Maximum data width (bits): 16</p></dd>
<dt><p><strong>32</strong> (2)</p></dt>
<dd><p>Maximum data width (bits): 32</p></dd>
<dt><p><strong>64</strong> (3)</p></dt>
<dd><p>Maximum data width (bits): 64</p></dd>
<dt><p><strong>128</strong> (4)</p></dt>
<dd><p>Maximum data width (bits): 128</p></dd>
</dl>
</dd>
<dt><strong>Model</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name for the physical element.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label for the object. When subclassed, this property can be overridden to be a key property.</p>
</dd>
<dt><strong>Number</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Physical slot number that can be used as an index into a system slot table, whether or not that slot is physically empty.</p>
<p>This value comes from the <strong>Slot ID</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>OtherIdentifyingInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Additional data (that is, more than the asset tag information), that can be used to identify a physical element. One example is bar code data associated with an element that also has an asset tag. Note that if only bar code data is available, and it is unique or can be used as an element key, this property is <strong>NULL</strong>, and the bar code data is used as the class key in the <strong>Tag</strong> property.</p>
</dd>
<dt><strong>PartNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Part number that the producer or manufacturer assigns to the physical element.</p>
</dd>
<dt><strong>PMESignal</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the PCI bus Power Management Enabled (PME) signal is supported by this slot.</p>
<p>This value comes from the <strong>Slot Characteristics 2</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>PoweredOn</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the physical element is powered on.</p>
</dd>
<dt><strong>PurposeDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string that describes how this slot is physically unique and may hold special types of hardware. This property only has meaning when the corresponding property <strong>SpecialPurpose</strong> is <strong>TRUE</strong>.</p>
</dd>
<dt><strong>SegmentGroupNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SMBIOS Segment Group Number.</p>
<p>This value comes from the <strong>Segment Group Number</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
<p><strong>Windows Server 2012 R2, Windows 8.1, Windows Server 2012, Windows 8, Windows Server 2008 R2, Windows 7, Windows Server 2008, and Windows Vista:  </strong>This property is not supported before Windows 10 and Windows Server 2016 Technical Preview.</p>
</dd>
<dt><strong>SerialNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer-allocated number used to identify the physical element.</p>
</dd>
<dt><strong>Shared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, two or more slots share a location on the baseboard, such as a PCI/EISA shared slot.</p>
<p>This value comes from the <strong>Slot Characteristics 1</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>SKU</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Stockkeeping unit number for the physical element.</p>
</dd>
<dt><strong>SlotDesignation</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SMBIOS string that identifies the system slot designation of the slot on the motherboard.</p>
<p>Example: "PCI-1"</p>
<p>This value comes from the <strong>Slot Designation</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>SpecialPurpose</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, this slot is physically unique and may hold special types of hardware, such as a graphics processor slot. If <strong>TRUE</strong>, then <strong>PurposeDescription</strong> should specify the nature of the uniqueness or purpose of the slot.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>The possible values are.</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>SupportsHotPlug</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the slot supports hot-plugging of adapter cards.</p>
<p>This value comes from the <strong>Slot Characteristics 2</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
</dd>
<dt><strong>Tag</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>System slot represented by an instance of this class.</p>
<p>Example: "System Slot 1"</p>
</dd>
<dt><strong>ThermalRating</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum thermal dissipation of the slot in milliwatts.</p>
</dd>
<dt><strong>VccMixedVoltageSupport</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of enumerated integers indicating the Vcc voltage supported by this slot.</p>
<p>This value comes from the <strong>Slot Characteristics 1</strong> member of the <strong>System Slots</strong> structure in the SMBIOS information.</p>
<p>
</p><p>The possible values are.</p>

<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>3.3V</strong> (2)</p></dt>
<dt><p><strong>5V</strong> (3)</p></dt>
</dl>
</dd>
<dt><strong>Version</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Version of the physical element.</p>
</dd>
<dt><strong>VppMixedVoltageSupport</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of enumerated integers indicating the Vpp voltage supported by this slot.</p>
<p>
</p><p>The possible values are.</p>

<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>3.3V</strong> (2)</p></dt>
<dt><p><strong>5V</strong> (3)</p></dt>
<dt><p><strong>12V</strong> (4)</p></dt>
</dl>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394492(v=vs.85).aspx
TCPIPPRINTERPORT = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394492(v=vs.85).aspx" />
    <title>Win32_TCPIPPrinterPort class (Windows)</title>
<h3>TCPIP Printer Port</h3>
<p>The <strong>Win32_TCPIPPrinterPort</strong> class has these properties.</p>
<dl>
<dt><strong>ByteCount</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the computer counts the bytes in a document before sending them to the printer and the printer reports back the number of bytes actually read. This capability is used for diagnostics when missing bytes are detected in the print output.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>A short textual description of the object.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the class or  subclass used in the creation of an instance. When used with  other key properties of the class, this property allows all instances of the class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>A textual description of the object.</p>
</dd>
<dt><strong>HostAddress</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Address of the device or print server.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Indicates when the object was installed. Lack of a value does not indicate that the object is not
      installed.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Uniquely identifies the service access point and provides an indication of the functionality that is managed.  This functionality is described in more detail in the object's Description property.</p>
</dd>
<dt><strong>PortNumber</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of the TCP ports used by the port monitor to communicate with the device.</p>
</dd>
<dt><strong>Protocol</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Printing protocol used. Some printers support only LPR.</p>
<dl class="indent">
<dt><p><strong>1</strong></p></dt>
<dd><p>RAW</p>
<p>Printing directly to a device or print server.</p></dd>
<dt><p><strong>2</strong></p></dt>
<dd><p>LPR</p>
<p>Legacy protocol, which is eventually replaced by RAW.</p></dd>
</dl>
</dd>
<dt><strong>Queue</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the print queue on the server when used with the LPR protocol.</p>
</dd>
<dt><strong>SNMPCommunity</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Security level value for the device.</p>
<p>Example: "public'"</p>
</dd>
<dt><strong>SNMPDevIndex</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>SNMP index number of this device for the SNMP agent.</p>
</dd>
<dt><strong>SNMPEnabled</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>String that indicates the current status of the object. Operational and non-operational status can be
       defined. Operational status can include "OK", "Degraded", and "Pred Fail". "Pred Fail" indicates that an
       element is functioning properly, but is predicting a failure (for example, a SMART-enabled hard disk drive).</p>
<p>Non-operational status can include "Error", "Starting", "Stopping", and "Service". "Service" can apply during
       disk mirror-resilvering, reloading a user permissions list, or other administrative work. Not all such work is
       online, but the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The scoping system's creation class name.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>The scoping system's name.</p>
</dd>
<dt><strong>Type</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of SAP, such as attached or redirected.</p>
<dl class="indent">
<dt><p><strong>Write</strong> (1)</p></dt>
<dt><p><strong>Read</strong> (2)</p></dt>
<dt><p><strong>Redirected</strong> (4)</p></dt>
<dt><p><strong>Net_Attached</strong> (8)</p></dt>
<dt><p><strong>unknown</strong> (16)</p></dt>
</dl>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394491(v=vs.85).aspx
TAPEDRIVE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394491(v=vs.85).aspx" />
    <title>Win32_TapeDrive class (Windows)</title>
<h3> Tape Drive</h3>
<p>The <strong>Win32_TapeDrive</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Capabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of capabilities of the media access device. For example, the device may support Random Access, removable media and Automatic Cleaning. In this case, the values 3, 7, and 9 would be written to the array.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Sequential Access</strong> (2)</p></dt>
<dt><p><strong>Random Access</strong> (3)</p></dt>
<dt><p><strong>Supports Writing</strong> (4)</p></dt>
<dt><p><strong>Encryption</strong> (5)</p></dt>
<dt><p><strong>Compression</strong> (6)</p></dt>
<dt><p><strong>Supports Removeable Media</strong> (7)</p></dt>
<dd><p>Supports Removable Media</p></dd>
<dt><p><strong>Manual Cleaning</strong> (8)</p></dt>
<dt><p><strong>Automatic Cleaning</strong> (9)</p></dt>
<dt><p><strong>SMART Notification</strong> (10)</p></dt>
<dt><p><strong>Supports Dual Sided Media</strong> (11)</p></dt>
<dd><p>Supports Dual-Sided Media</p></dd>
<dt><p><strong>Predismount Eject Not Required</strong> (12)</p></dt>
</dl>
</dd>
<dt><strong>CapabilityDescriptions</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of free-form strings providing more detailed explanations for any of the access device features indicated in the <strong>Capabilities</strong> array. Note that each entry of this array is related to the entry in the <strong>Capabilities</strong> array that is located at the same index.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>Compression</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, hardware data compression is enabled.</p>
<dl class="indent">
<dt><p><strong>0</strong></p></dt>
<dd><p>FALSE</p></dd>
<dt><p><strong>1</strong></p></dt>
<dd><p>TRUE</p></dd>
</dl>
</dd>
<dt><strong>CompressionMethod</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string indicating the algorithm or tool used by the device to support compression. If it is not possible or not desired to describe the compression scheme (perhaps because it is not known), use the following words: "Unknown" to represent that it is not known whether the device supports compression capabilities or not; "Compressed" to represent that the device supports compression capabilities but either its compression scheme is not known or not disclosed; and "Not Compressed" to represent that the device does not support compression capabilities.</p>
<dl class="indent">
<dt><p><strong></strong> ("Unknown")</p></dt>
<dd><p>The compression scheme is unknown or not described.</p></dd>
<dt><p><strong></strong> ("Compressed")</p></dt>
<dd><p>The logical file is compressed, but the compression scheme is unknown or not described</p></dd>
<dt><p><strong></strong> ("Not Compressed")</p></dt>
<dd><p>If the logical file is not compressed</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, this property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>DefaultBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Default block size, in bytes, for this device.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the tape drive with other devices on the system.</p>
</dd>
<dt><strong>ECC</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device supports hardware error correction.</p>
<dl class="indent">
<dt><p><strong>False</strong> (0)</p></dt>
<dt><p><strong>True</strong> (1)</p></dt>
</dl>
</dd>
<dt><strong>EOTWarningZoneSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Zone size for the end of tape (EOT) warning.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string supplying more information about the error recorded in <strong>LastErrorCode</strong>, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>ErrorMethodology</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string describing the type of error detection and correction supported by this device.</p>
</dd>
<dt><strong>FeaturesHigh</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>High-order 32 bits of the device features flag.</p>
</dd>
<dt><strong>FeaturesLow</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Low-order 32 bits of the device features flag.</p>
</dd>
<dt><strong>Id</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer's identifying name of the Windows CD ROM drive.</p>
<p>Example: "PLEXTOR CD-ROM PX-12CS 1.01"</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer of the Windows CD-ROM drive.</p>
<p>Example: "PLEXTOR"</p>
</dd>
<dt><strong>MaxBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum block size, in bytes, for media accessed by this device.</p>
</dd>
<dt><strong>MaxMediaSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum size, in kilobytes, of media supported by this device.</p>
</dd>
<dt><strong>MaxPartitionCount</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum partition count for the tape drive.</p>
</dd>
<dt><strong>MediaType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Media type used by (or accessed by) this device. In this case, it is set to "Tape Drive".</p>
</dd>
<dt><strong>MinBlockSize</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Minimum block size, in bytes, for media accessed by this device.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>NeedsCleaning</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the media access device needs cleaning. Whether manual or automatic cleaning is possible is indicated in the <strong>Capabilities</strong> property.</p>
</dd>
<dt><strong>NumberOfMediaSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of individual media which can be supported or inserted in the media access device (when supported).</p>
</dd>
<dt><strong>Padding</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of bytes inserted between blocks on a tape media.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from
       <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dd><p>Power-related capacities are not supported for this device.</p></dd>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ReportSetMarks</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, setmark reporting is enabled. Setmark reporting makes use of a specialized recorded element that does not contain user data. This recorded element is used to provide a segmentation scheme that is hierarchically superior to filemarks. Setmarks provide faster positioning on high-capacity tapes.</p>
<dl class="indent">
<dt><p><strong>0</strong></p></dt>
<dd><p>FALSE</p></dd>
<dt><p><strong>1</strong></p></dt>
<dd><p>TRUE</p></dd>
</dl>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394493(v=vs.85).aspx
TEMPERATUREPROBE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394493(v=vs.85).aspx" />
    <title>Win32_TemperatureProbe class (Windows)</title>
<h3> Temperature Probe</h3>
<p>The <strong>Win32_TemperatureProbe</strong> class has these properties.</p>
<dl>
<dt><strong>Accuracy</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Accuracy of the sensor for the measured property. Its value is recorded as plus or minus hundredths of a percent. Accuracy,  resolution, and tolerance are used to calculate the actual value of the measured physical property. Accuracy may vary and depends on whether or not the device is linear over its dynamic range.</p>
</dd>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dd><p>Offline</p></dd>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description  of an object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class that appears in the inheritance chain used in the creation of an instance. When used with the other key properties of a class, this property allows all instances of the class and its subclasses to be  identified uniquely.</p>
</dd>
<dt><strong>CurrentReading</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current value indicated by the sensor.</p>
<p>Current implementations of WMI do not populate the <strong>CurrentReading</strong> property. The <strong>CurrentReading</strong> property's presence is reserved for future use.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the current probe.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information about any corrective actions that you can take.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object is installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>IsLinear</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the sensor is linear over its dynamic range.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>LowerThresholdCritical</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor threshold value to specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is between <strong>LowerThresholdCritical</strong> and <strong>LowerThresholdFatal</strong>, the current state is critical.</p>
</dd>
<dt><strong>LowerThresholdFatal</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor threshold value to specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is below <strong>LowerThresholdFatal</strong>, the current state is fatal.</p>
</dd>
<dt><strong>LowerThresholdNonCritical</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor threshold value to specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is between <strong>LowerThresholdNonCritical</strong> and <strong>UpperThresholdNonCritical</strong>, the sensor is reporting a normal value. If <strong>CurrentReading</strong> is between <strong>LowerThresholdNonCritical</strong> and <strong>LowerThresholdCritical</strong>, the current state is noncritical.</p>
</dd>
<dt><strong>MaxReadable</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Largest value of the measured property that can be read by the numeric sensor.</p>
</dd>
<dt><strong>MinReadable</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Smallest value of the measured property that can be read by the numeric sensor.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label for the object. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>NominalReading</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Normal or expected value for the numeric sensor.</p>
</dd>
<dt><strong>NormalMax</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Normal or expected value for the numeric sensor.</p>
</dd>
<dt><strong>NormalMin</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Guidance for the user as to the normal minimum range for the numeric sensor.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState</em> parameter set to 5 (Power Cycle) and <em>Time</em> set to a specific date and time, or interval, for power-on.</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>Resolution</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Ability of the sensor to resolve differences in the measured property. This value may vary depending on whether the device is linear over its dynamic range.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value for the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>Tolerance</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Tolerance of the sensor for the measured property. Tolerance, along with resolution and accuracy, is used to calculate the actual value of the measured physical property. Tolerance may vary depending on whether the device is linear over its dynamic range.</p>
</dd>
<dt><strong>UpperThresholdCritical</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor's threshold values specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is between <strong>UpperThresholdCritical</strong> and <strong>UpperThresholdFatal</strong>, the current state is critical.</p>
</dd>
<dt><strong>UpperThresholdFatal</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor's threshold values specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is above <strong>UpperThresholdFatal</strong>, the current state is fatal.</p>
</dd>
<dt><strong>UpperThresholdNonCritical</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor's threshold values specify the ranges (minimum and maximum values) that identify the sensor operating conditions, which can be normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is between <strong>LowerThresholdNonCritical</strong> and <strong>UpperThresholdNonCritical</strong>, the sensor is reporting a normal value. If <strong>CurrentReading</strong> is between <strong>UpperThresholdNonCritical</strong> and <strong>UpperThresholdCritical</strong>, the current state is noncritical.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394504(v=vs.85).aspx
USBCONTROLLER = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394504(v=vs.85).aspx" />
    <title>Win32_USBController class (Windows)</title>
<h3>USB Controller</h3>
<p>The <strong>Win32_USBController</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dd><p>Offline</p></dd>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, this property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the USB controller.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Manufacturer</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Manufacturer of the controller.</p>
</dd>
<dt><strong>MaxNumberControlled</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProtocolSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Protocol used by the controller to access "controlled" devices.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>EISA</strong> (3)</p></dt>
<dt><p><strong>ISA</strong> (4)</p></dt>
<dt><p><strong>PCI</strong> (5)</p></dt>
<dt><p><strong>ATA/ATAPI</strong> (6)</p></dt>
<dd><p>ATA or ATAPI</p></dd>
<dt><p><strong>Flexible Diskette</strong> (7)</p></dt>
<dt><p><strong>1496</strong> (8)</p></dt>
<dt><p><strong>SCSI Parallel Interface</strong> (9)</p></dt>
<dt><p><strong>SCSI Fibre Channel Protocol</strong> (10)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol</strong> (11)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol-2 (1394)</strong> (12)</p></dt>
<dt><p><strong>SCSI Serial Storage Architecture</strong> (13)</p></dt>
<dt><p><strong>VESA</strong> (14)</p></dt>
<dt><p><strong>PCMCIA</strong> (15)</p></dt>
<dt><p><strong>Universal Serial Bus</strong> (16)</p></dt>
<dt><p><strong>Parallel Protocol</strong> (17)</p></dt>
<dt><p><strong>ESCON</strong> (18)</p></dt>
<dt><p><strong>Diagnostic</strong> (19)</p></dt>
<dt><p><strong>I2C</strong> (20)</p></dt>
<dt><p><strong>Power</strong> (21)</p></dt>
<dt><p><strong>HIPPI</strong> (22)</p></dt>
<dt><p><strong>MultiBus</strong> (23)</p></dt>
<dt><p><strong>VME</strong> (24)</p></dt>
<dt><p><strong>IPI</strong> (25)</p></dt>
<dt><p><strong>IEEE-488</strong> (26)</p></dt>
<dt><p><strong>RS232</strong> (27)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE5</strong> (28)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE2</strong> (29)</p></dt>
<dt><p><strong>IEEE 802.3 1BASE5</strong> (30)</p></dt>
<dt><p><strong>IEEE 802.3 10BROAD36</strong> (31)</p></dt>
<dt><p><strong>IEEE 802.3 100BASEVG</strong> (32)</p></dt>
<dt><p><strong>IEEE 802.5 Token-Ring</strong> (33)</p></dt>
<dt><p><strong>ANSI X3T9.5 FDDI</strong> (34)</p></dt>
<dt><p><strong>MCA</strong> (35)</p></dt>
<dt><p><strong>ESDI</strong> (36)</p></dt>
<dt><p><strong>IDE</strong> (37)</p></dt>
<dt><p><strong>CMD</strong> (38)</p></dt>
<dt><p><strong>ST506</strong> (39)</p></dt>
<dt><p><strong>DSSI</strong> (40)</p></dt>
<dt><p><strong>QIC2</strong> (41)</p></dt>
<dt><p><strong>Enhanced ATA/IDE</strong> (42)</p></dt>
<dt><p><strong>AGP</strong> (43)</p></dt>
<dt><p><strong>TWIRP (two-way infrared)</strong> (44)</p></dt>
<dt><p><strong>FIR (fast infrared)</strong> (45)</p></dt>
<dt><p><strong>SIR (serial infrared)</strong> (46)</p></dt>
<dt><p><strong>IrBus</strong> (47)</p></dt>
</dl>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value for the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the controller was last reset. This could mean the controller was powered down or reinitialized.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394506(v=vs.85).aspx
USBHUB = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394506(v=vs.85).aspx" />
    <title>Win32_USBHub class (Windows)</title>
<h3>USB Hub</h3>
<p>The <strong>Win32_USBHub</strong> class has these properties.</p>
<dl>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt>1 (0x1)</dt>
<dd><p>Other</p></dd>
<dt>2 (0x2)</dt>
<dd><p>Unknown</p></dd>
<dt>3 (0x3)</dt>
<dd><p>Running or Full Power</p></dd>
<dt>4 (0x4)</dt>
<dd><p>Warning</p></dd>
<dt>5 (0x5)</dt>
<dd><p>In Test</p></dd>
<dt>6 (0x6)</dt>
<dd><p>Not Applicable</p></dd>
<dt>7 (0x7)</dt>
<dd><p>Power Off</p></dd>
<dt>8 (0x8)</dt>
<dd><p>Off Line</p></dd>
<dt>9 (0x9)</dt>
<dd><p>Off Duty</p></dd>
<dt>10 (0xA)</dt>
<dd><p>Degraded</p></dd>
<dt>11 (0xB)</dt>
<dd><p>Not Installed</p></dd>
<dt>12 (0xC)</dt>
<dd><p>Install Error</p></dd>
<dt>13 (0xD)</dt>
<dd><p>Power Save - Unknown</p>
<p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt>14 (0xE)</dt>
<dd><p>Power Save - Low Power Mode</p>
<p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt>15 (0xF)</dt>
<dd><p>Power Save - Standby</p>
<p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt>16 (0x10)</dt>
<dd><p>Power Cycle</p></dd>
<dt>17 (0x11)</dt>
<dd><p>Power Save - Warning</p>
<p>The device is in a warning state, though also in a power save mode.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>ClassCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>CurrentAlternateSettings</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>CurrentConfigValue</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>An address or other identifying information which uniquely identifies the USBHub.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>GangSwitched</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, power is switched to all ports on the hub simultaneously. If <strong>FALSE</strong>, power is switched individually for each port.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Indicates the name of the USB Hub.</p>
</dd>
<dt><strong>NumberOfConfigs</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of device configurations that are defined for the device.</p>
</dd>
<dt><strong>NumberOfPorts</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of downstream ports on the hub, including those embedded in the hub's silicon.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Plug and Play device identifier  of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt>0 (0x0)</dt>
<dd><p>Unknown</p></dd>
<dt>1 (0x1)</dt>
<dd><p>Not Supported</p></dd>
<dt>2 (0x2)</dt>
<dd><p>Disabled</p></dd>
<dt>3 (0x3)</dt>
<dd><p>Enabled</p>
<p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt>4 (0x4)</dt>
<dd><p>Power Saving Modes Entered Automatically</p>
<p>The device can change its power state based on usage or other criteria.</p></dd>
<dt>5 (0x5)</dt>
<dd><p>Power State Settable</p></dd>
<dt>6 (0x6)</dt>
<dd><p>Power Cycling Supported</p></dd>
<dt>7 (0x7)</dt>
<dd><p>Timed Power On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power managed, that is, put into a power-save state. If <strong>FALSE</strong>, the integer value 1 ("Not Supported") should be the only entry in the <strong>PowerManagementCapabilities</strong> array.</p>
</dd>
<dt><strong>ProtocolCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
<dl class="indent">
<dt>1 (0x1)</dt>
<dd><p>Other</p></dd>
<dt>2 (0x2)</dt>
<dd><p>Unknown</p></dd>
<dt>3 (0x3)</dt>
<dd><p>Enabled</p></dd>
<dt>4 (0x4)</dt>
<dd><p>Disabled</p></dd>
<dt>5 (0x5)</dt>
<dd><p>Not Applicable</p></dd>
</dl>
</dd>
<dt><strong>SubclassCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint8</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
<dt><strong>USBVersion</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</dd>
</dl>
<h2>Requirements</h2>
<table summary="table">
<tr><th scope="row">
<p>Minimum supported client</p>
</th><td>
<p>Windows Vista</p>
</td></tr>
<tr><th scope="row">
<p>Minimum supported server</p>
</th><td>
<p>Windows Server 2008</p>
</td></tr>
<tr><th scope="row">
<p>Namespace</p>
</th><td>
<p>Root\CIMV2</p>
</td></tr>
<tr><th scope="row">
<p>MOF</p>
</th><td>
<dl>
<dt>Wmipcima.mof</dt>
</dl>
</td></tr>
<tr><th scope="row">
<p>DLL</p>
</th><td>
<dl>
<dt>Wmipcima.dll</dt>
</dl>
</td></tr>
</table>
<h2>See also</h2>
<dl>
<dt></dt>
<dt></dt>
</dl>
<p> </p>
<p> </p>
</div>
</div>






<div class="libraryMemberFilter">
    <div class="filterContainer">
        <span>Show:</span>
        <label>
            <input type="checkbox" class="libraryFilterInherited" checked="checked" value="Inherit" />Inherited
        </label>
        <label>
            <input type="checkbox" class="libraryFilterProtected" checked="checked" value="Protected" />Protected
        </label>
    </div>
</div>

<input type="hidden" id="libraryMemberFilterEmptyWarning" value="There are no members available with your current filter settings." />



    </div>
<div id="rightNavigationMenu" ms.cmpgrp="right nav">
    <div id="mobileButtons">
        <div id="navigationButtons">

            <a id="isd_printABook" href="/en-us/library/export/help/?returnurl=%2fen-us%2flibrary%2faa394506(v%3dvs.85).aspx">
                <ins class="export"></ins>Export (<span class="count">0</span>)
            </a>
        </div>
    </div>
    <div id="navMain">
        <div id="closeNavigation">
            <a class="tocCloseSmall" id="closeButton"></a>
        </div>
        <div id="navigationButtons">

            <a id="isd_printABook2" href="/en-us/library/export/help/?returnurl=%2fen-us%2flibrary%2faa394506(v%3dvs.85).aspx">
                <ins class="export"></ins>Export (<span class="count">0</span>)
            </a>
            <a id="isdShare" href="#" role="button" aria-expanded="false">
                <ins class="share"></ins>Share
            </a>
            <div id="socials" style="display: none">
                <a class="isdFacebook" href="#" aria-label="Share on Facebook">
                    <ins class="facebook"></ins>
                </a>
                <a class="isdTwitter" href="#" aria-label="Share on Twitter">
                    <ins class="twitter"></ins>
                </a>
                <a class="isdGooglePlus" href="#" aria-label="Share on Google+">
                    <ins class="googlePlus"></ins>
                </a>
            </div>
        </div>
        <div id="indoc_toc" style="display: none" ms.cmpgrp="indoc toc">
            <div id="indoc_title">IN THIS ARTICLE</div>
            <ul id="indoc_toclist"></ul>
        </div>
    </div>
</div>
<div id="rightNavigationMenuThumbnail" class="rightNavigationMenuThumbnail">
</div>





        </div>
        <div class="clear"></div>



<input name="__RequestVerificationToken" type="hidden" value="pWfOEuWxHcVZS43Wa7mfiMNoxvRMR7YlEAYNpybi2Osvwk1iADsB9MK1aRZbSnYGlIahr_yRMo_ddH-i8AzWQpciDDU1" />
<input id="ratingValueSubmitUrl" type="hidden" value="https://msdn.microsoft.com/en-us/library/feedback/rate/aa394506(v=vs.85).aspx" />
<input id="ratingAdditionalSubmitUrl" type="hidden" value="https://msdn.microsoft.com/en-us/library/feedback/additional/aa394506(v=vs.85).aspx" />
<input id="isTopicRated" type="hidden" value="false" />




    <div id="lib-footer">



    <link type="text/css" rel="stylesheet" />


    <div id="ux-footer" class="" style="" dir="ltr" ms.pgarea="footer">


    <div id="standardRatingBefore" class="clear stdr-container-before"></div>
    <div id="standardRating" class="stdr-container" ms.pgarea="body">
        <div class="stdr-close"></div>
        <div class="stdr-vote stdr-content">
            <div class="stdr-content">
                <span class="stdr-votetitle">Is this page helpful?</span>
                <button class="stdr-yes" aria-label="Yes, this page was helpful">Yes</button>
                <button class="stdr-no" aria-label="No, this page was not helpful">No</button>
                <input id="s_ratingValue" type="hidden" value="" />
            </div>
        </div>
        <div class="stdr-feedback" style="display: none">
            <div class="stdr-form">
                <div class="stdr-fieldtitle">Additional feedback?</div>
                <textarea class="stdr-detail" rows="6" maxlength="1500"></textarea>
                <div>
                    <span class="stdr-count"><span class="stdr-charcnt">1500</span> characters remaining</span>
                    <div class="stdr-buttons">
                        <button class="stdr-provide" aria-label="Submit my additional feedback">Submit</button>
                        <button class="stdr-skip" aria-label="Skip additional feedback">Skip this</button>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="stdr-thanks" style="display: none">
            <div class="stdr-content">
                <span class="stdr-thankyou">Thank you!</span>
                <span class="stdr-appreciate">We appreciate your feedback.</span>
            </div>
        </div>


        <div id="contentFeedbackQAContainer" style="display: none;"></div>
    </div>
    <div id="standardRatingPlaceholder" style="display: none"></div>


        <footer class="top" role="navigation" aria-label="footer">
            <div data-fragmentName="LeftLinks" id="Fragment_LeftLinks" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <h4 class="linkListTitle">Dev centers</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            <div id="rightLinks">
                <div data-fragmentName="CenterLinks1" id="Fragment_CenterLinks1" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <h4 class="linkListTitle">Learning resources</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks2" id="Fragment_CenterLinks2" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <h4 class="linkListTitle">Community</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks3" id="Fragment_CenterLinks3" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <h4 class="linkListTitle">Support</h4>
    <ul class="links">
      <li>
      </li>
    </ul>
  </div>
</div>
                <div data-fragmentName="CenterLinks4" id="Fragment_CenterLinks4" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <h4 class="linkListTitle">Programs</h4>
    <ul class="links">
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            </div>
        </footer>

        <footer class="bottom" role="contentinfo">
            <span class="localeContainer">

    <form class="selectLocale" id="selectLocaleForm" action="https://msdn.microsoft.com/en-us/selectlocale-dmc">
        <input type="hidden" name="fromPage" value="https%3a%2f%2fmsdn.microsoft.com%2fen-us%2flibrary%2faa394506(v%3dvs.85).aspx" />
    </form>


            </span>

            <div data-fragmentName="BottomLinks" id="Fragment_BottomLinks" xmlns="http://www.w3.org/1999/xhtml">

  <div class="linkList">
    <ul class="links horizontal">
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
      <li>
      </li>
    </ul>
  </div>
</div>
            <span class="logoLegal">
                <span class="logoSpan clip67x13" role="img" tabindex="0" aria-label="microsoft logo">
                    <img alt="logo" class="logo" src="https://i-msdn.sec.s-msft.com/Areas/Centers/Themes/StandardDevCenter/Content/HeaderFooterSprite.png?v=636221982560760644" />
                </span>
                <span class="copyright">© 2017 Microsoft</span>
            </span>
        </footer>
    </div>


    </div>


        <div class="footerPrintView">
            <div class="footerCopyrightPrintView">© 2017 Microsoft</div>
        </div>








    <input id="tocPaddingPerLevel" type="hidden" value="17" />



        <input id="MtpsDevice" type="hidden" value="Default" />


<![CDATA[ Third party scripts and code linked to or referenced from this website are licensed to you by the parties that own such code, not by Microsoft.  See ASP.NET Ajax CDN Terms of Use – http://www.asp.net/ajaxlibrary/CDN.ashx. ]]>







<![CDATA[ WebTrends view model not available or IncludeLegacyWebTrendsScriptInGlobal feature flag is off]]>




<div id="globalRequestVerification">
    <input name="__RequestVerificationToken" type="hidden" value="enJNMf_530QG45Kz6EFGaKRfufJpoBWYJYRX-eSGueoiZeansmqVNo_ADc8rM8eykTRGv8UPzOZB2571F-btJjwikr81" />
</div>


    </div>







<script type="text/javascript" class="mtps-injected">
/*<![CDATA[*/
(function(window,document){"use strict";function preload(scripts){for(var result=[],script,e,i=0;i<scripts.length;i++)script=scripts[i],script.hasOwnProperty("url")&&(e=document.createElement("script"),e.src=script.url,script.throwaway=e),result.push(script);return result}function inject(scripts,index){var script,elem;if(index>=scripts.length){delete mtps.injectScripts;return}script=scripts[index];elem=document.createElement("script");elem.className="mtps-injected";elem.async=!1;var isLoaded=!1,timeoutId=0,injectNextFnName="",injectNext=elem.onerror=function(){isLoaded||(isLoaded=!0,inject(scripts,index+1),window.clearTimeout(timeoutId),elem.onload=elem.onerror=elem.onreadystatechange=null,injectNextFnName&&delete mtps[injectNextFnName],elem.removeEventListener&&elem.removeEventListener("load",injectNext,!1))};elem.addEventListener?elem.addEventListener("load",injectNext,!1):elem.readyState==="uninitialized"?elem.onreadystatechange=function(){(this.readyState==="loaded"||this.readyState==="complete")&&injectNext()}:elem.onload=injectNext;script.hasOwnProperty("url")?(timeoutId=window.setTimeout(injectNext,12e4),elem.src=script.url):(injectNextFnName="_injectNextScript_"+index,mtps[injectNextFnName]=injectNext,timeoutId=window.setTimeout(injectNext,2e3),elem.text="try {\n"+script.txt+"\n} finally { MTPS."+injectNextFnName+" && MTPS."+injectNextFnName+"(); }");parent.appendChild(elem)}var mtps=window.MTPS||(window.MTPS={}),parent=document.getElementsByTagName("head")[0];mtps.injectScripts=function(scripts){inject(preload(scripts),0)}})(window,document);
MTPS.injectScripts([
	{ txt: "/**/\r\n(window.MTPS || (window.MTPS = {})).cdnDomains || (window.MTPS.cdnDomains = { \r\n\t\"image\": \"https://i-msdn.sec.s-msft.com\", \r\n\t\"js\": \"https://i2-msdn.sec.s-msft.com\", \r\n\t\"css\": \"https://i-msdn.sec.s-msft.com\", \r\n\t\"ttf\": \"https://i-msdn.sec.s-msft.com\"\r\n});\r\n/**/" },
	{ txt: "//\n\n        window.appInsightsId = \u00275eb1b2eb-c47a-497a-a7ac-a1c230b2882f\u0027;\n        //" },
	{ url: "https://i2-msdn.sec.s-msft.com/Combined.js?resources=0:Utilities,1:Layout,2:Header,3:Breadcrumbs,4:LibraryRightNavigationMenu,4:PrintExportButton,5:StandardRating,2:Footer,0:Topic,3:ResponsiveSupport,0:AppInsightsPerf,3:ResponsiveToc,0:ABTestControl,4:WEDCS,3:CmpgrpForHeader,1:SearchBox;/Areas/Epx/Content/Scripts:0,/Areas/Epx/Themes/Base/Content:1,/Areas/Centers/Themes/StandardDevCenter/Content:2,/Areas/Library/Content:3,/Areas/Library/Themes/Base/Content:4,/Areas/Global/Content:5\u0026amp;hashKey=380CB181B38C487101990C8F514C8659\u0026amp;v=F314B163E8B6FD251181E3EA43E44BD3" },
	{ url: "https://i1.services.social.microsoft.com/search/Widgets/SearchBox.jss?boxid=HeaderSearchTextBox\u0026btnid=HeaderSearchButton\u0026minimumTermLength=2\u0026pgArea=header\u0026brand=Msdn\u0026loc=en-us\u0026focusOnInit=false\u0026emptyWatermark=true\u0026searchButtonTooltip=Search MSDN" },
	{ url: "https://i2-msdn.sec.s-msft.com/Combined.js?resources=0:JumpRedirect,1:LibraryMemberFilter,2:Toc_Fixed,2:CodeSnippet,2:TopicNotInScope,2:VersionSelector,2:SurveyBroker;/Areas/Epx/Themes/Base/Content:0,/Areas/Library/Content:1,/Areas/Epx/Content/Scripts:2\u0026amp;hashKey=8B88EB517137869CDE8F8A6DFD775854\u0026amp;v=F314B163E8B6FD251181E3EA43E44BD3" },
	{ txt: "$(document).ready(function() {\n        try {\n            var token = $(\"#globalRequestVerification input[name=\u0027__RequestVerificationToken\u0027]\").clone();\n            $(\"#siteFeedbackForm\").append(token);\n        } catch(err) {\n            \n        }\n    });" }
]);

/*]]>*/
</script></body>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394512(v=vs.85).aspx
VIDEOCONTROLLER = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394512(v=vs.85).aspx" />
    <title>Win32_VideoController class (Windows)</title>
<h3> Video Controller</h3>
<p>The <strong>Win32_VideoController</strong> class has these properties.</p>
<dl>
<dt><strong>AcceleratorCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of graphics and 3-D capabilities of the video controller.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Graphics Accelerator</strong> (2)</p></dt>
<dt><p><strong>3D Accelerator</strong> (3)</p></dt>
<dd><p>3-D Accelerator</p></dd>
</dl>
</dd>
<dt><strong>AdapterCompatibility</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>General chipset used for this controller to compare compatibilities with the system.</p>
</dd>
<dt><strong>AdapterDACType</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name or identifier of the digital-to-analog converter (DAC) chip. The character set of this property is
       alphanumeric.</p>
</dd>
<dt><strong>AdapterRAM</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Memory size of the video adapter.</p>
<p>Example: 64000</p>
</dd>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dd><p>Running or Full Power</p></dd>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dd><p>Offline</p></dd>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>CapabilityDescriptions</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form strings providing more detailed explanations for any of the video accelerator features indicated in the <strong>AcceleratorCapabilities</strong> array. Note, each entry of this array is related to the entry in the <strong>AcceleratorCapabilities</strong> array that is located at the same index.</p>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object.</p>
</dd>
<dt><strong>ColorTableEntries</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Size of the system's color table. The device must have a color depth of no more than 8 bits per pixel; otherwise, this property is not set.</p>
<p>Example: 256</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, this property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>CurrentBitsPerPixel</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of bits used to display each pixel.</p>
</dd>
<dt><strong>CurrentHorizontalResolution</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current number of horizontal pixels.</p>
</dd>
<dt><strong>CurrentNumberOfColors</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint64</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of colors supported at the current resolution.</p>
</dd>
<dt><strong>CurrentNumberOfColumns</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of columns for this video controller (if in character mode). Otherwise, enter 0 (zero).</p>
</dd>
<dt><strong>CurrentNumberOfRows</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of rows for this video controller (if in character mode). Otherwise, enter 0 (zero).</p>
</dd>
<dt><strong>CurrentRefreshRate</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Frequency at which the video controller refreshes the image for the monitor. A value of 0 (zero) indicates the default rate is being used, while 0xFFFFFFFF indicates the optimal rate is being used.</p>
</dd>
<dt><strong>CurrentScanMode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current scan mode.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Interlaced</strong> (3)</p></dt>
<dt><p><strong>Non Interlaced</strong> (4)</p></dt>
<dd><p>Noninterlaced</p></dd>
</dl>
</dd>
<dt><strong>CurrentVerticalResolution</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current number of vertical pixels.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Identifier (unique to the computer system) for this video controller.</p>
</dd>
<dt><strong>DeviceSpecificPens</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current number of device-specific pens. A value of 0xffff means that the device does not support pens.</p>
<p>Example: 3</p>
</dd>
<dt><strong>DitherType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Dither type of the video controller. The property can be one of the predefined values, or a driver-defined value greater than or equal to 256. If line art dithering is chosen, the controller uses a dithering method that produces well-defined borders between black, white, and gray scalings. Line art dithering is not suitable for images that include continuous graduations in intensity and hue such as scanned photographs.</p>
<dl class="indent">
<dt><p><strong>No dithering</strong> (1)</p></dt>
<dt><p><strong>Dithering with a coarse brush</strong> (2)</p></dt>
<dt><p><strong>Dithering with a fine brush</strong> (3)</p></dt>
<dt><p><strong>Line art dithering</strong> (4)</p></dt>
<dt><p><strong>Device does gray scaling</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>DriverDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last modification date and time of the currently installed video driver.</p>
</dd>
<dt><strong>DriverVersion</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Version number of the video driver.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> property is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string supplying more information about the error recorded in <strong>LastErrorCode</strong> property, and information on any corrective actions that may be taken.</p>
</dd>
<dt><strong>ICMIntent</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Specific value of one of the three possible color-matching methods or intents that should be used by default. This property is used primarily for non-ICM applications. ICM applications establish intents by using the ICM functions. This property can be a predefined value or a driver defined value greater than or equal to 256. Color matching based on saturation is the most appropriate choice for business graphs when dithering is not desired. Color matching based on contrast is the most appropriate choice for scanned or photographic images when dithering is desired. Color matching optimized to match the exact color requested is most appropriate for use with business logos or other images when an exact color match is desired.</p>
<dl class="indent">
<dt><p><strong>Saturation</strong> (1)</p></dt>
<dt><p><strong>Contrast</strong> (2)</p></dt>
<dt><p><strong>Exact Color</strong> (3)</p></dt>
</dl>
</dd>
<dt><strong>ICMMethod</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Method of handling ICM. For non-ICM applications, this property determines if ICM is enabled. For ICM applications, the system examines this property to determine how to handle ICM support. This property can be a predefined value or a driver-defined value greater than or equal to 256. The value determines which system handles image color matching.</p>
<dl class="indent">
<dt><p><strong>Disabled</strong> (1)</p></dt>
<dt><p><strong>Windows</strong> (2)</p></dt>
<dt><p><strong>Device Driver</strong> (3)</p></dt>
<dt><p><strong>Destination Device</strong> (4)</p></dt>
</dl>
</dd>
<dt><strong>InfFilename</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Path to the video adapter's .inf file.</p>
<p>Example: "C:\Windows\SYSTEM32\DRIVERS"</p>
</dd>
<dt><strong>InfSection</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Section of the .inf file where the Windows video information resides.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object was installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>InstalledDisplayDrivers</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Name of the installed display device driver.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>MaxMemorySupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum amount of memory supported in bytes.</p>
</dd>
<dt><strong>MaxNumberControlled</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum number of directly addressable entities supportable by this controller. A value of 0 (zero) should be used if the number is unknown.</p>
</dd>
<dt><strong>MaxRefreshRate</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Maximum refresh rate of the video controller in hertz.</p>
</dd>
<dt><strong>MinRefreshRate</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Minimum refresh rate of the video controller in hertz.</p>
</dd>
<dt><strong>Monochrome</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, gray scale is used to display images.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label by which the object is known. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>NumberOfColorPlanes</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current number of color planes. If this value is not applicable for the current video configuration, enter 0 (zero).</p>
</dd>
<dt><strong>NumberOfVideoPages</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of video pages supported given the current resolutions and available memory.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <a href="https://msdn.microsoft.com/en-us/library/aa387884(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CIM_LogicalDevice</strong></a> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>Timed Power-On Supported</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed (can be put into suspend mode, and so on). The property does not indicate that power management features are currently enabled, only that the logical device is capable of power management.</p>
</dd>
<dt><strong>ProtocolSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Protocol used by the controller to access "controlled" devices.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>EISA</strong> (3)</p></dt>
<dt><p><strong>ISA</strong> (4)</p></dt>
<dt><p><strong>PCI</strong> (5)</p></dt>
<dt><p><strong>ATA/ATAPI</strong> (6)</p></dt>
<dd><p>ATA or ATAPI</p></dd>
<dt><p><strong>Flexible Diskette</strong> (7)</p></dt>
<dt><p><strong>1496</strong> (8)</p></dt>
<dt><p><strong>SCSI Parallel Interface</strong> (9)</p></dt>
<dt><p><strong>SCSI Fibre Channel Protocol</strong> (10)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol</strong> (11)</p></dt>
<dt><p><strong>SCSI Serial Bus Protocol-2 (1394)</strong> (12)</p></dt>
<dt><p><strong>SCSI Serial Storage Architecture</strong> (13)</p></dt>
<dt><p><strong>VESA</strong> (14)</p></dt>
<dt><p><strong>PCMCIA</strong> (15)</p></dt>
<dt><p><strong>Universal Serial Bus</strong> (16)</p></dt>
<dt><p><strong>Parallel Protocol</strong> (17)</p></dt>
<dt><p><strong>ESCON</strong> (18)</p></dt>
<dt><p><strong>Diagnostic</strong> (19)</p></dt>
<dt><p><strong>I2C</strong> (20)</p></dt>
<dt><p><strong>Power</strong> (21)</p></dt>
<dt><p><strong>HIPPI</strong> (22)</p></dt>
<dt><p><strong>MultiBus</strong> (23)</p></dt>
<dt><p><strong>VME</strong> (24)</p></dt>
<dt><p><strong>IPI</strong> (25)</p></dt>
<dt><p><strong>IEEE-488</strong> (26)</p></dt>
<dt><p><strong>RS232</strong> (27)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE5</strong> (28)</p></dt>
<dt><p><strong>IEEE 802.3 10BASE2</strong> (29)</p></dt>
<dt><p><strong>IEEE 802.3 1BASE5</strong> (30)</p></dt>
<dt><p><strong>IEEE 802.3 10BROAD36</strong> (31)</p></dt>
<dt><p><strong>IEEE 802.3 100BASEVG</strong> (32)</p></dt>
<dt><p><strong>IEEE 802.5 Token-Ring</strong> (33)</p></dt>
<dt><p><strong>ANSI X3T9.5 FDDI</strong> (34)</p></dt>
<dt><p><strong>MCA</strong> (35)</p></dt>
<dt><p><strong>ESDI</strong> (36)</p></dt>
<dt><p><strong>IDE</strong> (37)</p></dt>
<dt><p><strong>CMD</strong> (38)</p></dt>
<dt><p><strong>ST506</strong> (39)</p></dt>
<dt><p><strong>DSSI</strong> (40)</p></dt>
<dt><p><strong>QIC2</strong> (41)</p></dt>
<dt><p><strong>Enhanced ATA/IDE</strong> (42)</p></dt>
<dt><p><strong>AGP</strong> (43)</p></dt>
<dt><p><strong>TWIRP (two-way infrared)</strong> (44)</p></dt>
<dt><p><strong>FIR (fast infrared)</strong> (45)</p></dt>
<dt><p><strong>SIR (serial infrared)</strong> (46)</p></dt>
<dt><p><strong>IrBus</strong> (47)</p></dt>
</dl>
</dd>
<dt><strong>ReservedSystemPaletteEntries</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Number of reserved entries in the system palette. The operating system may reserve entries to support standard colors for task bars and other desktop display items. This index is valid only if the device driver sets the <strong>RC_PALETTE</strong> bit in the RASTERCAPS index, and is available only if the driver is compatible with 16-bit Windows. If the system is not using a palette, <strong>ReservedSystemPaletteEntries</strong> is not set.</p>
<p>Example: 20</p>
</dd>
<dt><strong>SpecificationVersion</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Version number of the initialization data specification (upon which the structure is based).</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value of the scoping computer's <strong>CreationClassName</strong> property.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>SystemPaletteEntries</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current number of color index entries in the system palette. This index is valid only if the device driver sets the <strong>RC_PALETTE</strong> bit in the RASTERCAPS index, and is available only if the driver is compatible with 16-bit Windows. If the system is not using a palette, <strong>SystemPaletteEntries</strong> is not set.</p>
<p>Example: 20</p>
</dd>
<dt><strong>TimeOfLastReset</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time this controller was last reset. This could mean the controller was powered down or reinitialized.</p>
</dd>
<dt><strong>VideoArchitecture</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of video architecture.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>CGA</strong> (3)</p></dt>
<dt><p><strong>EGA</strong> (4)</p></dt>
<dt><p><strong>VGA</strong> (5)</p></dt>
<dt><p><strong>SVGA</strong> (6)</p></dt>
<dt><p><strong>MDA</strong> (7)</p></dt>
<dt><p><strong>HGC</strong> (8)</p></dt>
<dt><p><strong>MCGA</strong> (9)</p></dt>
<dt><p><strong>8514A</strong> (10)</p></dt>
<dt><p><strong>XGA</strong> (11)</p></dt>
<dt><p><strong>Linear Frame Buffer</strong> (12)</p></dt>
<dt><p><strong>PC-98</strong> (160)</p></dt>
</dl>
</dd>
<dt><strong>VideoMemoryType</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Type of video memory.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>VRAM</strong> (3)</p></dt>
<dt><p><strong>DRAM</strong> (4)</p></dt>
<dt><p><strong>SRAM</strong> (5)</p></dt>
<dt><p><strong>WRAM</strong> (6)</p></dt>
<dt><p><strong>EDO RAM</strong> (7)</p></dt>
<dt><p><strong>Burst Synchronous DRAM</strong> (8)</p></dt>
<dt><p><strong>Pipelined Burst SRAM</strong> (9)</p></dt>
<dt><p><strong>CDRAM</strong> (10)</p></dt>
<dt><p><strong>3DRAM</strong> (11)</p></dt>
<dt><p><strong>SDRAM</strong> (12)</p></dt>
<dt><p><strong>SGRAM</strong> (13)</p></dt>
</dl>
</dd>
<dt><strong>VideoMode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current video mode.</p>
</dd>
<dt><strong>VideoModeDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current resolution, color, and scan mode settings of the video controller.</p>
<p>Example: "1024 x 768 x 256 colors"</p>
</dd>
<dt><strong>VideoProcessor</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Free-form string describing the video processor.</p>
</dd>
</html>
'''

# https://msdn.microsoft.com/en-us/library/aa394514(v=vs.85).aspx
VOLTAGEPROBE = u'''
<!DOCTYPE html>


<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><link rel="canonical" href="https://msdn.microsoft.com/en-us/library/aa394514(v=vs.85).aspx" />
    <title>Win32_VoltageProbe class (Windows)</title>
<h3> Voltage Probe</h3>
<p>The <strong>Win32_VoltageProbe</strong> class has these properties.</p>
<dl>
<dt><strong>Accuracy</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Accuracy of the sensor for the measured property. The accuracy  value is recorded as plus or minus hundredths of a percent. Accuracy, along with resolution and tolerance, is used to calculate the actual value of the measured physical property. The accuracy may vary and depends on whether or not the device is linear in its dynamic range.</p>
</dd>
<dt><strong>Availability</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Availability and status of the device.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Running/Full Power</strong> (3)</p></dt>
<dt><p><strong>Warning</strong> (4)</p></dt>
<dt><p><strong>In Test</strong> (5)</p></dt>
<dt><p><strong>Not Applicable</strong> (6)</p></dt>
<dt><p><strong>Power Off</strong> (7)</p></dt>
<dt><p><strong>Off Line</strong> (8)</p></dt>
<dt><p><strong>Off Duty</strong> (9)</p></dt>
<dt><p><strong>Degraded</strong> (10)</p></dt>
<dt><p><strong>Not Installed</strong> (11)</p></dt>
<dt><p><strong>Install Error</strong> (12)</p></dt>
<dt><p><strong>Power Save - Unknown</strong> (13)</p></dt>
<dd><p>The device is known to be in a power save mode, but its exact status is unknown.</p></dd>
<dt><p><strong>Power Save - Low Power Mode</strong> (14)</p></dt>
<dd><p>The device is in a power save state but still functioning, and may exhibit degraded performance.</p></dd>
<dt><p><strong>Power Save - Standby</strong> (15)</p></dt>
<dd><p>The device is not functioning, but could be brought to full power quickly.</p></dd>
<dt><p><strong>Power Cycle</strong> (16)</p></dt>
<dt><p><strong>Power Save - Warning</strong> (17)</p></dt>
<dd><p>The device is in a warning state, though also in a power save mode.</p></dd>
<dt><p><strong>Paused</strong> (18)</p></dt>
<dd><p>The device is paused.</p></dd>
<dt><p><strong>Not Ready</strong> (19)</p></dt>
<dd><p>The device is not ready.</p></dd>
<dt><p><strong>Not Configured</strong> (20)</p></dt>
<dd><p>The device is not configured.</p></dd>
<dt><p><strong>Quiesced</strong> (21)</p></dt>
<dd><p>The device is quiet.</p></dd>
</dl>
</dd>
<dt><strong>Caption</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Short description of the object—a one-line string.</p>
</dd>
<dt><strong>ConfigManagerErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Win32 Configuration Manager error code.</p>
<dl class="indent">
<dt><p><strong>This device is working properly.</strong> (0)</p></dt>
<dd><p>Device is working properly.</p></dd>
<dt><p><strong>This device is not configured correctly.</strong> (1)</p></dt>
<dd><p>Device is not configured correctly.</p></dd>
<dt><p><strong>Windows cannot load the driver for this device.</strong> (2)</p></dt>
<dt><p><strong>The driver for this device might be corrupted, or your system may be running low on memory or other resources.</strong> (3)</p></dt>
<dd><p>Driver for this device might be corrupted, or the  system may be  low on memory or other resources.</p></dd>
<dt><p><strong>This device is not working properly. One of its drivers or your registry might be corrupted.</strong> (4)</p></dt>
<dd><p>Device is not working properly. One of its drivers or the  registry might be corrupted.</p></dd>
<dt><p><strong>The driver for this device needs a resource that Windows cannot manage.</strong> (5)</p></dt>
<dd><p>Driver for the device requires a resource that Windows cannot manage.</p></dd>
<dt><p><strong>The boot configuration for this device conflicts with other devices.</strong> (6)</p></dt>
<dd><p>Boot configuration for the device conflicts with other devices.</p></dd>
<dt><p><strong>Cannot filter.</strong> (7)</p></dt>
<dt><p><strong>The driver loader for the device is missing.</strong> (8)</p></dt>
<dd><p>Driver loader for the device is missing.</p></dd>
<dt><p><strong>This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.</strong> (9)</p></dt>
<dd><p>Device is not working properly.  The controlling firmware is incorrectly reporting the resources for the device.</p></dd>
<dt><p><strong>This device cannot start.</strong> (10)</p></dt>
<dd><p>Device cannot start.</p></dd>
<dt><p><strong>This device failed.</strong> (11)</p></dt>
<dd><p>Device failed.</p></dd>
<dt><p><strong>This device cannot find enough free resources that it can use.</strong> (12)</p></dt>
<dd><p>Device cannot find enough free resources to use.</p></dd>
<dt><p><strong>Windows cannot verify this device's resources.</strong> (13)</p></dt>
<dd><p>Windows cannot verify the device's resources.</p></dd>
<dt><p><strong>This device cannot work properly until you restart your computer.</strong> (14)</p></dt>
<dd><p>Device cannot work properly until the computer is restarted.</p></dd>
<dt><p><strong>This device is not working properly because there is probably a re-enumeration problem.</strong> (15)</p></dt>
<dd><p>Device is not working properly due to a possible re-enumeration problem.</p></dd>
<dt><p><strong>Windows cannot identify all the resources this device uses.</strong> (16)</p></dt>
<dd><p>Windows cannot identify all of the resources that the device uses.</p></dd>
<dt><p><strong>This device is asking for an unknown resource type.</strong> (17)</p></dt>
<dd><p>Device is requesting  an unknown resource type.</p></dd>
<dt><p><strong>Reinstall the drivers for this device.</strong> (18)</p></dt>
<dd><p>Device drivers must be reinstalled.</p></dd>
<dt><p><strong>Failure using the VxD loader.</strong> (19)</p></dt>
<dt><p><strong>Your registry might be corrupted.</strong> (20)</p></dt>
<dd><p>Registry might be corrupted.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that does not work, see your hardware documentation. Windows is removing this device.</strong> (21)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.</p></dd>
<dt><p><strong>This device is disabled.</strong> (22)</p></dt>
<dd><p>Device is disabled.</p></dd>
<dt><p><strong>System failure: Try changing the driver for this device. If that doesn't work, see your hardware documentation.</strong> (23)</p></dt>
<dd><p>System failure. If changing the device driver is ineffective, see the hardware documentation.</p></dd>
<dt><p><strong>This device is not present, is not working properly, or does not have all its drivers installed.</strong> (24)</p></dt>
<dd><p>Device is not present,  not working properly, or does not have all of its drivers installed.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (25)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>Windows is still setting up this device.</strong> (26)</p></dt>
<dd><p>Windows is still setting up the device.</p></dd>
<dt><p><strong>This device does not have valid log configuration.</strong> (27)</p></dt>
<dd><p>Device does not have valid log configuration.</p></dd>
<dt><p><strong>The drivers for this device are not installed.</strong> (28)</p></dt>
<dd><p>Device drivers   are not installed.</p></dd>
<dt><p><strong>This device is disabled because the firmware of the device did not give it the required resources.</strong> (29)</p></dt>
<dd><p>Device is disabled.  The device firmware   did not provide  the required resources.</p></dd>
<dt><p><strong>This device is using an Interrupt Request (IRQ) resource that another device is using.</strong> (30)</p></dt>
<dd><p>Device is using an IRQ resource that another device is using.</p></dd>
<dt><p><strong>This device is not working properly because Windows cannot load the drivers required for this device.</strong> (31)</p></dt>
<dd><p>Device is not working properly.  Windows cannot load the  required device drivers.</p></dd>
</dl>
</dd>
<dt><strong>ConfigManagerUserConfig</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device is using a user-defined configuration.</p>
</dd>
<dt><strong>CreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the first concrete class to appear in the inheritance chain used in the creation of an instance. When used with the other key properties of the class, this property allows all instances of this class and its subclasses to be uniquely identified.</p>
</dd>
<dt><strong>CurrentReading</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current value indicated by the sensor.</p>
</dd>
<dt><strong>Description</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Description of the object.</p>
</dd>
<dt><strong>DeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Unique identifier of the voltage probe.</p>
</dd>
<dt><strong>ErrorCleared</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the error reported in <strong>LastErrorCode</strong> is now cleared.</p>
</dd>
<dt><strong>ErrorDescription</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>More information about the error recorded in <strong>LastErrorCode</strong>, and information about any corrective actions that may be taken.</p>
</dd>
<dt><strong>InstallDate</strong></dt>
<dd><dl>
<dt>Data type: <strong>datetime</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Date and time the object is installed. This property does not need a value to indicate that the object is installed.</p>
</dd>
<dt><strong>IsLinear</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the sensor is linear over its dynamic range.</p>
</dd>
<dt><strong>LastErrorCode</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Last error code reported by the logical device.</p>
</dd>
<dt><strong>LowerThresholdCritical</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor threshold values specify the ranges (minimum and maximum values) to determine if the sensor is operating under normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is between <strong>LowerThresholdCritical</strong> and <strong>LowerThresholdFatal</strong>, the current state is critical.</p>
</dd>
<dt><strong>LowerThresholdFatal</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor threshold values specify the ranges (minimum and maximum values) to determine if the sensor is operating under normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is below <strong>LowerThresholdFatal</strong>, the current state is fatal.</p>
</dd>
<dt><strong>LowerThresholdNonCritical</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor threshold values specify the ranges (minimum and maximum values) to determine if the sensor is operating under normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is between <strong>LowerThresholdNonCritical</strong> and <strong>UpperThresholdNonCritical</strong>, the sensor is reporting a normal value. If <strong>CurrentReading</strong> is between <strong>LowerThresholdNonCritical</strong> and <strong>LowerThresholdCritical</strong>, the current state is noncritical.</p>
</dd>
<dt><strong>MaxReadable</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Largest value of the measured property that the numeric sensor can read.</p>
</dd>
<dt><strong>MinReadable</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Smallest value of the measured property that the numeric sensor can read.</p>
</dd>
<dt><strong>Name</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Label for an object. When subclassed, the property can be overridden to be a key property.</p>
</dd>
<dt><strong>NominalReading</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Normal or expected value for the numeric sensor.</p>
</dd>
<dt><strong>NormalMax</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Normal or expected value for the numeric sensor.</p>
</dd>
<dt><strong>NormalMin</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Guidance for the user to indicate the normal minimum range for the numeric sensor.</p>
</dd>
<dt><strong>PNPDeviceID</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Windows Plug and Play device identifier of the logical device.</p>
<p>Example: "*PNP030b"</p>
</dd>
<dt><strong>PowerManagementCapabilities</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong> array</dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Array of the specific power-related capabilities of a logical device.</p>
<p>This property is inherited from <strong>CIM_LogicalDevice</strong>.</p>
<dl class="indent">
<dt><p><strong>Unknown</strong> (0)</p></dt>
<dt><p><strong>Not Supported</strong> (1)</p></dt>
<dt><p><strong>Disabled</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dd><p>The power management features are currently enabled but the exact feature set is unknown or the information is unavailable.</p></dd>
<dt><p><strong>Power Saving Modes Entered Automatically</strong> (4)</p></dt>
<dd><p>The device can change its power state based on usage or other criteria.</p></dd>
<dt><p><strong>Power State Settable</strong> (5)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method is supported. This method is found on the parent <strong>CIM_LogicalDevice</strong> class and can be implemented. For more information, see <a href="https://msdn.microsoft.com/en-us/library/aa390351(v=vs.85).aspx">Designing Managed Object Format (MOF) Classes</a>.</p></dd>
<dt><p><strong>Power Cycling Supported</strong> (6)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState </em>parameter set to 5 (Power Cycle).</p></dd>
<dt><p><strong>Timed Power On Supported</strong> (7)</p></dt>
<dd><p>The <a href="https://msdn.microsoft.com/en-us/library/aa393485(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetPowerState</strong></a> method can be invoked with the <em>PowerState</em> parameter set to 5 (Power Cycle) and <em>Time</em> set to a specific date and time, or interval, for power-on.</p></dd>
</dl>
</dd>
<dt><strong>PowerManagementSupported</strong></dt>
<dd><dl>
<dt>Data type: <strong>boolean</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>If <strong>TRUE</strong>, the device can be power-managed, which means that it can be put into suspend mode, and so on. The property does not indicate that power management features are currently enabled, but it does indicate that the logical device is capable of power management.</p>
</dd>
<dt><strong>Resolution</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Ability of the sensor to resolve differences in the measured property. This value may vary and depends on whether the device is linear in its dynamic range.</p>
</dd>
<dt><strong>Status</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Current status of the object. Various operational and nonoperational statuses can be defined. Operational statuses include: "OK", "Degraded", and "Pred Fail" (an element, such as a SMART-enabled hard disk drive, may be functioning properly but predicting a failure in the near future). Nonoperational statuses include: "Error", "Starting", "Stopping", and "Service". The latter, "Service", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is online, yet the managed element is neither "OK" nor in one of the other states.</p>
<p>
</p><p>Values include the following:</p>

<dl class="indent">
<dt><p><strong>OK</strong> ("OK")</p></dt>
<dt><p><strong>Error</strong> ("Error")</p></dt>
<dt><p><strong>Degraded</strong> ("Degraded")</p></dt>
<dt><p><strong>Unknown</strong> ("Unknown")</p></dt>
<dt><p><strong>Pred Fail</strong> ("Pred Fail")</p></dt>
<dt><p><strong>Starting</strong> ("Starting")</p></dt>
<dt><p><strong>Stopping</strong> ("Stopping")</p></dt>
<dt><p><strong>Service</strong> ("Service")</p></dt>
<dt><p><strong>Stressed</strong> ("Stressed")</p></dt>
<dt><p><strong>NonRecover</strong> ("NonRecover")</p></dt>
<dt><p><strong>No Contact</strong> ("No Contact")</p></dt>
<dt><p><strong>Lost Comm</strong> ("Lost Comm")</p></dt>
</dl>
</dd>
<dt><strong>StatusInfo</strong></dt>
<dd><dl>
<dt>Data type: <strong>uint16</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>State of the logical device. If this property does not apply to the logical device, the value 5 (Not Applicable) should be used.</p>
<dl class="indent">
<dt><p><strong>Other</strong> (1)</p></dt>
<dt><p><strong>Unknown</strong> (2)</p></dt>
<dt><p><strong>Enabled</strong> (3)</p></dt>
<dt><p><strong>Disabled</strong> (4)</p></dt>
<dt><p><strong>Not Applicable</strong> (5)</p></dt>
</dl>
</dd>
<dt><strong>SystemCreationClassName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Value for the  <strong>CreationClassName</strong> property of the scoping computer.</p>
</dd>
<dt><strong>SystemName</strong></dt>
<dd><dl>
<dt>Data type: <strong>string</strong></dt>
<dt>Access type: Read-only</dt></dt>
</dl>
<p>
</p><p>Name of the scoping system.</p>
</dd>
<dt><strong>Tolerance</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Tolerance of the sensor for the measured property. Tolerance, along with resolution and accuracy, is used to calculate the actual value of the measured physical property. Tolerance may vary, and  depends on whether the device is linear in its dynamic range.</p>
</dd>
<dt><strong>UpperThresholdCritical</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor threshold values specify the ranges (minimum and maximum values) to determine whether the sensor is operating under normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is between <strong>UpperThresholdCritical</strong> and <strong>UpperThresholdFatal</strong>, the current state is critical.</p>
</dd>
<dt><strong>UpperThresholdFatal</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor threshold values specify the ranges (minimum and maximum values) to determine whether the sensor is operating under normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is above <strong>UpperThresholdFatal</strong>, the current state is fatal.</p>
</dd>
<dt><strong>UpperThresholdNonCritical</strong></dt>
<dd><dl>
<dt>Data type: <strong>sint32</strong></dt>
<dt>Access type: Read-only</dt>
</dl>
<p>
</p><p>Sensor threshold values specify the ranges (minimum and maximum values) to determine whether the sensor is operating under normal, noncritical, critical, or fatal conditions. If <strong>CurrentReading</strong> is between  <strong>LowerThresholdNonCritical</strong>and <strong>UpperThresholdNonCritical</strong>, the sensor is reporting a normal value. If <strong>CurrentReading</strong> is between <strong>UpperThresholdNonCritical</strong> and <strong>UpperThresholdCritical</strong>, the current state is noncritical.</p>
</dd>
</html>
'''

